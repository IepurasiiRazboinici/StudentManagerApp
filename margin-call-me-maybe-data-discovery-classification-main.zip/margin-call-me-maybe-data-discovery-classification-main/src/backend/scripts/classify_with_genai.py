"""
Sends one or more data files (plus optional analyst notes) to the internal
GenAI Service Builder "agentclassification" endpoint for AI-based data
sensitivity classification, per the hackathon's classification rules.

Usage:
    python classify_with_genai.py FILE [FILE ...] [--notes NOTES_FILE] [--max-tokens N]

Requires the GENAI_SERVICE_API_KEY environment variable to be set (bearer token).
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path

import requests

API_URL = (
    "https://genai-service-builder.int.refinitiv.com/api/v1/services/"
    "margincallmemaybeai/agentclassification"
)
DEFAULT_MAX_TOKENS = 128000

# The actual system prompt sent to the model lives in
# DATA_CLASSIFICATION_SYSTEM_PROMPT.md at the repo root (single source of
# truth shared with src/backend/api/genaiClient.js) - it defines the full
# discovery/profiling/classification rules AND the exact JSON response
# schema (one entry per file under `assets`, each with a nested
# `classification` object).
SYSTEM_PROMPT_PATH = Path(__file__).resolve().parents[3] / "DATA_CLASSIFICATION_SYSTEM_PROMPT.md"
SYSTEM_PROMPT = SYSTEM_PROMPT_PATH.read_text(encoding="utf-8")

USER_INSTRUCTION = (
    "Analyze each attached file (and any additional analyst notes) according to "
    "the system prompt's instructions and return only the single JSON object it "
    "describes - no Markdown fences, no text before or after it."
)


def build_prompt(file_paths: list[Path], notes_path: Path | None) -> str:
    """Combine the system prompt, optional notes, and file contents into one input."""
    parts = [SYSTEM_PROMPT]

    if notes_path is not None:
        notes_text = notes_path.read_text(encoding="utf-8")
        parts.append(f"## Additional Analyst Notes\n{notes_text}")

    for path in file_paths:
        file_text = path.read_text(encoding="utf-8", errors="replace")
        parts.append(f"## Attached File: {path.name}\n```\n{file_text}\n```")

    parts.append(USER_INSTRUCTION)
    return "\n\n".join(parts)


def extract_json(reply_text: str) -> dict:
    text = reply_text.strip()
    # Tolerate replies wrapped in ```json ... ``` fences, just in case.
    fenced = re.match(r"^```(?:json)?\s*(.*?)\s*```$", text, flags=re.DOTALL)
    if fenced:
        text = fenced.group(1)
    return json.loads(text)


def classify(
    file_paths: list[Path],
    notes_path: Path | None = None,
    max_tokens: int = DEFAULT_MAX_TOKENS,
) -> dict:
    api_key = os.environ.get("GENAI_SERVICE_API_KEY")
    if not api_key:
        sys.exit("GENAI_SERVICE_API_KEY environment variable is not set.")

    prompt = build_prompt(file_paths, notes_path)

    response = requests.post(
        url=API_URL,
        headers={
            "Content-type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        json={"max_tokens": max_tokens, "input1": prompt},
        timeout=120,
    )
    response.raise_for_status()
    payload = response.json()

    if payload.get("status") != "Success":
        sys.exit(f"API call did not succeed: {payload}")

    return extract_json(payload["response"])


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("files", nargs="+", help="One or more files to classify (mandatory).")
    parser.add_argument("--notes", help="Optional file of analyst notes appended to the system prompt.")
    parser.add_argument(
        "--max-tokens",
        type=int,
        default=DEFAULT_MAX_TOKENS,
        help=f"Max output tokens for the reply (default: {DEFAULT_MAX_TOKENS}).",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    file_paths = [Path(f) for f in args.files]
    for path in file_paths:
        if not path.is_file():
            sys.exit(f"File not found: {path}")

    notes_path = Path(args.notes) if args.notes else None
    if notes_path is not None and not notes_path.is_file():
        sys.exit(f"Notes file not found: {notes_path}")

    result = classify(file_paths, notes_path=notes_path, max_tokens=args.max_tokens)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

