#!/usr/bin/env node
// Minimal test harness wiring data-discovery (Node) -> classify_with_genai.py (Python).
//
// For each input file:
//   1. Run data-discovery to get metadata + a small sample.
//   2. If the file is "large" (discovery had to truncate it, i.e. rowCount > the
//      sample size), send only the condensed discovery summary (columns + sample
//      rows + rowCount) to the classifier instead of the raw file.
//   3. Otherwise (small file, or a format discovery doesn't parse), send the
//      original file as-is.
//   4. Run classify_with_genai.py once over all the resulting inputs and merge
//      each classification result back with its discovery metadata.
//
// Usage:
//   node scripts/run-pipeline.js FILE [FILE ...] [--notes NOTES_FILE] [--sample-size N]
//
// Requires GENAI_SERVICE_API_KEY to be set in the environment (passed through to
// the Python subprocess).

const fs = require("fs");
const os = require("os");
const path = require("path");
const { spawnSync } = require("child_process");

const { discoverDataAssets } = require("../data-discovery/data-discovery");

const CLASSIFY_SCRIPT = path.join(__dirname, "classify_with_genai.py");

function parseArgs(argv) {
  const files = [];
  let notes = null;
  let sampleSize = 3;

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--notes") {
      notes = argv[++i];
    } else if (arg === "--sample-size") {
      sampleSize = Number(argv[++i]);
    } else {
      files.push(arg);
    }
  }

  if (files.length === 0) {
    console.error("Usage: node scripts/run-pipeline.js FILE [FILE ...] [--notes NOTES_FILE] [--sample-size N]");
    process.exit(1);
  }

  return { files, notes, sampleSize };
}

// Builds a small condensed JSON summary from a discovery asset, used in place of
// the raw file when the file was too large for discovery to fully sample.
function buildDiscoverySummary(asset) {
  return {
    asset: asset.sourceName,
    sourceType: asset.sourceType,
    rowCount: asset.rowCount,
    columnCount: asset.columnCount,
    columns: asset.columns,
    sampleRecords: asset.sampleRecords,
  };
}

async function main() {
  const { files, notes, sampleSize } = parseArgs(process.argv.slice(2));
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "classify-pipeline-"));

  try {
    // sentPathToOriginal maps the path we actually hand to the classifier back to
    // the original input file, so results can be merged after classification.
    const sentPathToOriginal = new Map();
    const effectivePaths = [];
    const discoveryByFile = new Map();

    for (const file of files) {
      const absolute = path.resolve(file);
      if (!fs.existsSync(absolute)) {
        console.error(`File not found: ${file}`);
        process.exit(1);
      }

      const discovery = await discoverDataAssets({ inputs: [absolute], sampleSize });
      const asset = discovery.files[0];
      discoveryByFile.set(file, asset);

      const wasTruncated = !asset.error && asset.rowCount > asset.sampleRecords.length;

      let sendPath;
      if (wasTruncated) {
        // Large/parsed file: send only the condensed discovery summary.
        const summary = buildDiscoverySummary(asset);
        sendPath = path.join(tmpDir, `${path.basename(file)}.discovery-summary.json`);
        fs.writeFileSync(sendPath, JSON.stringify(summary, null, 2), "utf8");
      } else {
        // Small file, or a format discovery doesn't parse (e.g. .md/.txt): send as-is.
        sendPath = absolute;
      }

      sentPathToOriginal.set(path.basename(sendPath), file);
      effectivePaths.push(sendPath);
    }

    const pythonArgs = [CLASSIFY_SCRIPT, ...effectivePaths];
    if (notes) {
      pythonArgs.push("--notes", path.resolve(notes));
    }

    const result = spawnSync("python", pythonArgs, {
      encoding: "utf8",
      env: process.env,
    });

    if (result.error) {
      console.error(`Failed to run classify_with_genai.py: ${result.error.message}`);
      process.exit(1);
    }
    if (result.status !== 0) {
      console.error(result.stderr || `classify_with_genai.py exited with code ${result.status}`);
      process.exit(result.status || 1);
    }

    const classification = JSON.parse(result.stdout);

    // Merge each classification result with the discovery metadata for its
    // original file.
    const merged = classification.results.map((entry) => {
      const originalFile = sentPathToOriginal.get(entry.asset) || entry.asset;
      const asset = discoveryByFile.get(originalFile);
      return {
        file: originalFile,
        sentAs: asset && !asset.error && asset.rowCount > asset.sampleRecords.length
          ? "discovery-summary"
          : "raw-file",
        discovery: asset,
        classification: entry,
      };
    });

    console.log(JSON.stringify({ results: merged }, null, 2));
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
