#!/usr/bin/env node
// Minimal test harness wiring data-discovery (Node) -> classify_with_genai.py (Python).
//
// Routing rules:
//   - Structured data sources (CSV / TSV / JSON, SQLite, PostgreSQL tables)
//     go through data-discovery first, then a condensed discovery summary is sent
//     to AI for classification.
//   - Unstructured files (e.g. Markdown / text / mock wiki pages) are passed
//     directly to AI unchanged.
//   - All classifications are merged back with any available discovery metadata.
//
// Usage:
//   node src/backend/scripts/file_to_ai_judgement.js [FILE ...] [--sqlite DB_PATH ...]
//     [--pg CONNECTION_STRING] [--schema SCHEMA] [--notes NOTES_FILE] [--sample-size N]
//
// Requires GENAI_SERVICE_API_KEY to be set in the environment (passed through to
// the Python subprocess).

const fs = require("fs");
const os = require("os");
const path = require("path");
const { spawnSync } = require("child_process");

const { runDataDiscovery } = require("../data-discovery/data-discovery");
const { runDataProfiling } = require("../data-profiling/data-profiling");
const { sourceTypeFromPath } = require("../data-discovery/file-input");

const CLASSIFY_SCRIPT = path.resolve(__dirname, "../../../classify_with_genai.py");

function parseArgs(argv) {
  const files = [];
  const sqlite = [];
  let notes = null;
  let pg = "";
  let schema = "public";
  let sampleSize = 3;

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--notes") {
      notes = argv[++i];
    } else if (arg === "--sqlite") {
      sqlite.push(argv[++i]);
    } else if (arg === "--pg") {
      pg = argv[++i] || "";
    } else if (arg === "--schema") {
      schema = argv[++i] || "public";
    } else if (arg === "--sample-size") {
      sampleSize = Number(argv[++i]);
    } else {
      files.push(arg);
    }
  }

  if (files.length === 0 && sqlite.length === 0 && !pg) {
    console.error(
      "Usage: node src/backend/scripts/file_to_ai_judgement.js [FILE ...] [--sqlite DB_PATH ...] "
      + "[--pg CONNECTION_STRING] [--schema SCHEMA] [--notes NOTES_FILE] [--sample-size N]"
    );
    process.exit(1);
  }

  return { files, sqlite, notes, pg, schema, sampleSize };
}

// Builds a small condensed JSON summary from a discovery asset, used in place of
// the raw file when the file was too large for discovery to fully sample.
function buildDiscoverySummary(asset, sourceId) {
  return {
    asset: sourceId || asset.sourceName,
    sourceType: asset.sourceType,
    table: asset.table || null,
    exists: asset.exists,
    error: asset.error || "",
    rowCount: asset.rowCount,
    columnCount: asset.columnCount,
    columns: asset.columns,
    sampleRecords: asset.sampleRecords,
  };
}

function isStructuredSourceType(sourceType) {
  return sourceType === "csv" || sourceType === "tsv" || sourceType === "json";
}

function writeTempPayload(tmpDir, prefix, index, originalName, payload) {
  const safeName = path.basename(originalName).replace(/[^a-zA-Z0-9._-]/g, "_");
  const fileName = `${prefix}-${index}-${safeName}.json`;
  const fullPath = path.join(tmpDir, fileName);
  fs.writeFileSync(fullPath, JSON.stringify(payload, null, 2), "utf8");
  return fullPath;
}

function copyTempInput(tmpDir, prefix, index, originalPath) {
  const safeName = path.basename(originalPath).replace(/[^a-zA-Z0-9._-]/g, "_");
  const fileName = `${prefix}-${index}-${safeName}`;
  const fullPath = path.join(tmpDir, fileName);
  fs.copyFileSync(originalPath, fullPath);
  return fullPath;
}

function mapOrAliasRawInput({
  originalFile,
  absolutePath,
  sentAssetToMeta,
  effectivePaths,
  tmpDir,
  index,
  sourceType,
  discovery,
}) {
  const sendName = path.basename(absolutePath);
  const resolvedSourceType = sourceType || sourceTypeFromPath(absolutePath);

  // Avoid creating duplicate temp files unless basename collisions force aliasing.
  if (!sentAssetToMeta.has(sendName)) {
    sentAssetToMeta.set(sendName, {
      source: originalFile,
      sourceType: resolvedSourceType,
      sentAs: "raw-file",
      discovery: discovery || null,
    });
    effectivePaths.push(absolutePath);
    return;
  }

  const aliasedPath = copyTempInput(tmpDir, "raw-aliased", index, absolutePath);
  const aliasedName = path.basename(aliasedPath);
  sentAssetToMeta.set(aliasedName, {
    source: originalFile,
    sourceType: resolvedSourceType,
    sentAs: "raw-file",
    discovery: discovery || null,
  });
  effectivePaths.push(aliasedPath);
}

function addDiscoverySummaryInput({
  sentAssetToMeta,
  effectivePaths,
  tmpDir,
  summaryIndex,
  prefix,
  source,
  sourceType,
  discovery,
  payload,
}) {
  const sendPath = writeTempPayload(tmpDir, prefix, summaryIndex, source, payload);
  const sendName = path.basename(sendPath);
  sentAssetToMeta.set(sendName, {
    source,
    sourceType,
    sentAs: "discovery-summary",
    discovery,
  });
  effectivePaths.push(sendPath);
}

function normalizeFileInput(file, cwd) {
  if (typeof file === "string") {
    const absolutePath = path.isAbsolute(file) ? file : path.resolve(cwd, file);
    return {
      source: file,
      absolutePath,
      displayName: path.basename(file),
    };
  }

  if (file && typeof file === "object" && typeof file.path === "string") {
    const absolutePath = path.isAbsolute(file.path) ? file.path : path.resolve(cwd, file.path);
    return {
      source: file.source || file.name || file.path,
      absolutePath,
      displayName: file.name || path.basename(file.path),
    };
  }

  throw new Error("Unsupported file input. Expected a path string or { path, name } object.");
}

async function main() {
  const {
    files,
    sqlite,
    notes,
    pg,
    schema,
    sampleSize,
  } = parseArgs(process.argv.slice(2));
  try {
    const result = await classifyWithRouting({
      files,
      sqlite,
      pg,
      schema,
      sampleSize,
      notesPath: notes ? path.resolve(notes) : null,
    });
    console.log(JSON.stringify(result, null, 2));
  } catch (error) {
    console.error(error.message || String(error));
    process.exit(1);
  }
}

async function classifyWithRouting({
  files,
  sqlite = [],
  pg = "",
  schema = "public",
  sampleSize = 3,
  notesPath = null,
  cwd = process.cwd(),
}) {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "classify-pipeline-"));

  try {
    // sentAssetToMeta maps classifier-visible file names to source metadata.
    const sentAssetToMeta = new Map();
    const effectivePaths = [];

    const absoluteFiles = [];

    for (const file of files || []) {
      const normalizedFile = normalizeFileInput(file, cwd);

      if (!fs.existsSync(normalizedFile.absolutePath)) {
        throw new Error(`File not found: ${normalizedFile.source}`);
      }

      absoluteFiles.push({
        original: normalizedFile.source,
        absolute: normalizedFile.absolutePath,
        displayName: normalizedFile.displayName,
      });
    }

    const discovery = await runDataDiscovery({
      inputs: absoluteFiles.map((f) => f.absolute),
      sqlite,
      pg,
      schema,
      sampleSize,
      cwd,
      autoDiscoverInputs: false,
      suppressUnsupportedFiles: false,
    });

    let summaryIndex = 0;
    let rawAliasIndex = 0;

    // Route all file inputs from discovery results in one pass.
    // Structured parsed files -> discovery summary.
    // Unstructured/unsupported (or parse-failed) files -> raw content to AI.
    for (const asset of discovery.files || []) {
      const matchingFile = absoluteFiles.find((file) => file.absolute === asset.asset);
      const sourceId = matchingFile ? matchingFile.displayName : asset.sourceName;
      const parseable = isStructuredSourceType(asset.sourceType);

      if (!parseable || asset.error) {
        rawAliasIndex += 1;
        mapOrAliasRawInput({
          originalFile: sourceId,
          absolutePath: asset.asset,
          sentAssetToMeta,
          effectivePaths,
          tmpDir,
          index: rawAliasIndex,
          sourceType: asset.sourceType,
          discovery: asset,
        });
        continue;
      }

      summaryIndex += 1;
      const summary = buildDiscoverySummary(asset, sourceId);
      addDiscoverySummaryInput({
        sentAssetToMeta,
        effectivePaths,
        tmpDir,
        summaryIndex,
        prefix: "discovery-file",
        source: sourceId,
        sourceType: asset.sourceType,
        discovery: asset,
        payload: summary,
      });
    }

    // SQLite discovery output (one summary per discovered table).
    for (const asset of discovery.sqlite || []) {
      const sqliteTables = asset.tables || [];
      if (sqliteTables.length === 0) {
        summaryIndex += 1;
        const sourceId = asset.sourceName;
        const summary = buildDiscoverySummary(asset, sourceId);
        addDiscoverySummaryInput({
          sentAssetToMeta,
          effectivePaths,
          tmpDir,
          summaryIndex,
          prefix: "discovery-sqlite",
          source: sourceId,
          sourceType: "sqlite",
          discovery: asset,
          payload: summary,
        });
        continue;
      }

      for (const table of sqliteTables) {
        summaryIndex += 1;
        const sourceId = `${asset.sourceName}:${table.table}`;
        const summary = {
          asset: sourceId,
          sourceType: "sqlite",
          table: table.table,
          exists: asset.exists,
          error: asset.error || "",
          rowCount: table.rowCount,
          columnCount: table.columnCount,
          columns: table.columns,
          sampleRecords: table.sampleRecords,
        };
        addDiscoverySummaryInput({
          sentAssetToMeta,
          effectivePaths,
          tmpDir,
          summaryIndex,
          prefix: "discovery-sqlite",
          source: sourceId,
          sourceType: "sqlite",
          discovery: table,
          payload: summary,
        });
      }
    }

    // PostgreSQL discovery output may include multiple tables; summarize each table.
    if (discovery.postgres) {
      const pgTables = discovery.postgres.tables || [];
      for (const table of pgTables) {
        summaryIndex += 1;
        const sourceId = `${table.table}`;
        const summary = {
          asset: sourceId,
          sourceType: "postgres",
          schema,
          table: table.table,
          rowCount: table.rowCount,
          columnCount: table.columnCount,
          columns: table.columns,
          sampleRecords: table.sampleRecords,
        };
        addDiscoverySummaryInput({
          sentAssetToMeta,
          effectivePaths,
          tmpDir,
          summaryIndex,
          prefix: "discovery-postgres",
          source: sourceId,
          sourceType: "postgres",
          discovery: table,
          payload: summary,
        });
      }
    }

    if (effectivePaths.length === 0) {
      throw new Error("No valid inputs were prepared for classification.");
    }

    const pythonArgs = [CLASSIFY_SCRIPT, ...effectivePaths];
    if (notesPath) {
      pythonArgs.push("--notes", notesPath);
    }

    const pythonCandidates = [process.env.PYTHON_BIN, "python3", "python"].filter(Boolean);
    let result = null;
    let lastSpawnError = null;

    for (const cmd of pythonCandidates) {
      result = spawnSync(cmd, pythonArgs, {
        encoding: "utf8",
        env: process.env,
      });

      if (!result.error) {
        break;
      }

      lastSpawnError = result.error;
    }

    if (!result || result.error) {
      const message = lastSpawnError ? lastSpawnError.message : "Unknown process start error";
      throw new Error(`Failed to run classify_with_genai.py: ${message}`);
    }
    if (result.status !== 0) {
      throw new Error(result.stderr || `classify_with_genai.py exited with code ${result.status}`);
    }

    const classification = JSON.parse(result.stdout);
    const profiling = await runDataProfiling(discovery, {
      sampleSize,
      pg,
      schema,
    });

    // Merge each classification result with the discovery metadata for its
    // original file.
    const merged = classification.results.map((entry) => {
      const sourceMeta = sentAssetToMeta.get(entry.asset);
      return {
        source: sourceMeta ? sourceMeta.source : entry.asset,
        sourceType: sourceMeta ? sourceMeta.sourceType : "unknown",
        sentAs: sourceMeta ? sourceMeta.sentAs : "unknown",
        discovery: sourceMeta ? sourceMeta.discovery : null,
        classification: entry,
      };
    });

    return {
      discovery,
      profiling,
      results: merged,
    };
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
}

if (require.main === module) {
  main().catch((error) => {
    console.error(error);
    process.exit(1);
  });
}

module.exports = {
  classifyWithRouting,
};
