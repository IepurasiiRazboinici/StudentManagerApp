// Data access functions for ReviewAction rows.
//
// The key safeguard here is addReviewAction(): when a reviewer overrides a
// classification, we need to (a) record the review action itself and
// (b) change the classification's level - and both of those either both
// succeed or both fail together. Otherwise you could end up with a
// ReviewAction saying "overridden to CONFIDENTIAL" while the
// Classification row still shows the old level (or vice versa).
const { prisma } = require("./client");
const { updateClassificationWithLock } = require("./classifications");

// Records a reviewer's action (APPROVE / OVERRIDE / COMMENT).
//
// - APPROVE / COMMENT: just inserts a ReviewAction row. Nothing else
//   changes, so no version check is needed.
// - OVERRIDE: inserts the ReviewAction row AND updates the parent
//   Classification's level, using optimistic locking (`expectedVersion`)
//   to make sure the reviewer was looking at the latest version of the
//   classification when they decided to override it.
//
// Everything runs inside a single `$transaction`, so if the optimistic
// lock check fails (stale version -> OptimisticLockError thrown), Prisma
// automatically rolls back the ReviewAction insert too - we never persist
// a review comment for a level change that didn't actually happen.
async function addReviewAction({ classificationId, userId, action, newLevel, comment, expectedVersion }) {
  if (action === "OVERRIDE" && !newLevel) {
    throw new Error("newLevel is required when action is OVERRIDE");
  }
  if (action === "OVERRIDE" && expectedVersion === undefined) {
    throw new Error("expectedVersion is required when action is OVERRIDE (optimistic locking check)");
  }

  return prisma.$transaction(async (tx) => {
    // Step 1: always record the review action as an audit trail entry.
    const reviewAction = await tx.reviewAction.create({
      data: {
        classificationId,
        userId,
        action,
        newLevel: action === "OVERRIDE" ? newLevel : null,
        comment: comment ?? null,
      },
    });

    // Step 2: only an OVERRIDE actually changes the classification level.
    let classification = null;
    if (action === "OVERRIDE") {
      classification = await updateClassificationWithLock(
        classificationId,
        expectedVersion,
        { classificationLevel: newLevel },
        tx // reuse the same transaction client, not the global prisma instance
      );
    }

    return { reviewAction, classification };
  });
}

module.exports = { addReviewAction };

