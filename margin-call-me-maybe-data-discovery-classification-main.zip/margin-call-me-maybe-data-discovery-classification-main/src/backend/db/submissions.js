// Data access functions for Submission rows.
//
// The interesting function here is claimNextPendingSubmission(), which
// implements the "job claiming" safeguard described in the README: two
// worker processes (or two runs of the same cron/queue handler) must never
// both start classifying the same submission.
const { prisma } = require("./client");

// Create a new submission from an upload. Always starts life as PENDING -
// a worker picks it up later via claimNextPendingSubmission().
async function createSubmission({ uploadedById, fileName, fileType, rawContent, userNotes, sourceMetadata }) {
  return prisma.submission.create({
    data: {
      uploadedById,
      fileName,
      fileType,
      rawContent,
      userNotes: userNotes ?? null,
      sourceMetadata,
      // status defaults to PENDING via the schema
    },
  });
}

async function getSubmissionById(id) {
  return prisma.submission.findUnique({
    where: { id },
    include: {
      classification: {
        include: { reviewActions: { orderBy: { createdAt: "desc" } } },
      },
    },
  });
}

async function listSubmissions({ status } = {}) {
  return prisma.submission.findMany({
    where: status ? { status } : undefined,
    orderBy: { uploadedAt: "asc" },
  });
}

// Atomically claims the oldest PENDING submission and flips it to
// PROCESSING, in one round-trip to the database.
//
// Why raw SQL: Prisma's query builder has no "UPDATE ... WHERE ...
// RETURNING *" that also picks "the next available row" safely under
// concurrency. A plain `findFirst` followed by `update` is a classic
// check-then-act race: two workers could both `findFirst` the same row
// before either one updates it.
//
// This query instead:
//   1. Picks one PENDING row with `FOR UPDATE SKIP LOCKED` - if another
//      transaction already has that row locked (because it's claiming it
//      right now), Postgres skips it instead of waiting/blocking.
//   2. Updates that exact row to PROCESSING and returns it, in the same
//      statement, so there's no gap between "check" and "act".
//
// Returns the claimed submission row, or `null` if there was nothing left
// to claim (either the queue is empty, or another worker just took the
// last available row).
async function claimNextPendingSubmission() {
  const rows = await prisma.$queryRaw`
    UPDATE "submissions"
    SET "status" = 'PROCESSING'
    WHERE "id" = (
      SELECT "id"
      FROM "submissions"
      WHERE "status" = 'PENDING'
      ORDER BY "uploadedAt" ASC
      FOR UPDATE SKIP LOCKED
      LIMIT 1
    )
    RETURNING *;
  `;

  return rows[0] ?? null;
}

// Claims one *specific* submission (by id) instead of "whichever PENDING
// row happens to be oldest". This matters for POST /api/classify: it
// creates a submission and immediately wants to claim *that exact row*,
// not just any pending row - if some other request is claiming
// submissions at the same time (which the UI explicitly allows: uploads
// are non-blocking, so a user can start a second batch while the first is
// still processing), claimNextPendingSubmission() could hand back a
// completely different file's submission. That mismatch is what used to
// cause a classification (and its AI explanation) to get attached to the
// wrong fileName/rawContent.
//
// Still uses the same atomic "UPDATE ... WHERE status = 'PENDING' RETURNING"
// pattern, so it's safe even if two requests somehow raced on the same id.
async function claimSubmissionById(id) {
  const rows = await prisma.$queryRaw`
    UPDATE "submissions"
    SET "status" = 'PROCESSING'
    WHERE "id" = ${id} AND "status" = 'PENDING'
    RETURNING *;
  `;

  return rows[0] ?? null;
}

// Marks a submission as FAILED, e.g. when the LLM call errors out after
// it was claimed. Kept separate from claiming so a worker can call this
// from a catch block regardless of why the job failed.
async function markSubmissionFailed(id) {
  return prisma.submission.update({
    where: { id },
    data: { status: "FAILED" },
  });
}

// Summary counts backing the dashboard's stat cards.
//   - totalSubmissions: every submission ever uploaded.
//   - classifiedToday: classifications produced since local midnight.
//   - pendingReview: classifications that no reviewer has acted on yet
//     (no APPROVE/OVERRIDE/COMMENT row against them).
//   - aiDecisionsPending: submissions still waiting on the AI itself
//     (PENDING in the queue, or PROCESSING right now) - distinct from
//     pendingReview, which is about *human* review, not the AI job.
async function getSubmissionStats() {
  const startOfToday = new Date();
  startOfToday.setHours(0, 0, 0, 0);

  const [totalSubmissions, classifiedToday, pendingReview, aiDecisionsPending] = await Promise.all([
    prisma.submission.count(),
    prisma.classification.count({ where: { classifiedAt: { gte: startOfToday } } }),
    prisma.classification.count({ where: { reviewActions: { none: {} } } }),
    prisma.submission.count({ where: { status: { in: ["PENDING", "PROCESSING"] } } }),
  ]);

  return { totalSubmissions, classifiedToday, pendingReview, aiDecisionsPending };
}

// Counts backing the dashboard's "Files by type" chart - how many
// submissions (regardless of status) came in as each file type.
async function getFileTypeBreakdown() {
  const grouped = await prisma.submission.groupBy({
    by: ["fileType"],
    _count: { _all: true },
  });

  return grouped
    .map((row) => ({ fileType: row.fileType || "unknown", count: row._count._all }))
    .sort((a, b) => b.count - a.count);
}

module.exports = {
  createSubmission,
  getSubmissionById,
  listSubmissions,
  claimNextPendingSubmission,
  claimSubmissionById,
  markSubmissionFailed,
  getSubmissionStats,
  getFileTypeBreakdown,
};

