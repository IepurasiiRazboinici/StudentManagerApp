// Single shared PrismaClient instance for the whole app.
//
// Why: creating a `new PrismaClient()` per file/request opens a new
// connection pool each time, which exhausts Postgres connections fast.
// Every module in src/backend/db/* should `require("./client")` instead of
// instantiating its own client.
const { PrismaClient } = require("@prisma/client");

// In dev, tools like nodemon can re-run this module many times without a
// fresh process, which would otherwise create a new client (and new
// connection pool) on every reload. Stashing it on `global` avoids that.
const globalForPrisma = globalThis;

const prisma =
  globalForPrisma.__prismaClient ||
  new PrismaClient({
    // Uncomment while debugging to see every generated SQL statement:
    // log: ["query", "warn", "error"],
  });

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.__prismaClient = prisma;
}

module.exports = { prisma };
