// Data access functions for Classification rows.
//
// Two concurrency safeguards live here:
//   1. createClassification() - prevents duplicate classifications if a
//      classification job somehow runs twice for the same submission.
//   2. updateClassificationWithLock() - optimistic locking so two people
//      (or a person + a re-run job) can't silently clobber each other's
//      changes to the same classification.
const { prisma } = require("./client");
const { OptimisticLockError } = require("./errors");

// Creates the classification for a submission, or - if one already exists
// for that submissionId - leaves the existing row untouched and just
// returns it.
//
// Why upsert instead of "SELECT then INSERT if missing": that pattern has
// a race window between the SELECT and the INSERT where a second caller
// (e.g. a duplicate-triggered classification job) can slip in and insert
// its own row, which then violates the UNIQUE constraint on submissionId
// and crashes. `upsert` pushes that check down into a single atomic
// statement Postgres executes as one operation (effectively
// `INSERT ... ON CONFLICT (submissionId) DO NOTHING`-equivalent, since our
// `update` clause is a no-op).
//
// `client` defaults to the shared prisma instance but can be a
// `tx` passed in from a $transaction callback.
async function createClassification(data, client = prisma) {
  const classification = await client.classification.upsert({
    where: { submissionId: data.submissionId },
    update: {}, // already classified - do nothing, this is the "duplicate job" case
    create: {
      submissionId: data.submissionId,
      classificationLevel: data.classificationLevel,
      confidenceScore: data.confidenceScore,
      evidence: data.evidence,
      referencedGuidance: data.referencedGuidance ?? null,
      explanation: data.explanation,
      modelVersion: data.modelVersion,
    },
  });

  // Reflect the outcome on the parent submission. Safe to run even if the
  // upsert above was a no-op (submission is likely already CLASSIFIED).
  await client.submission.update({
    where: { id: data.submissionId },
    data: { status: "CLASSIFIED" },
  });

  return classification;
}

async function getClassificationById(id, client = prisma) {
  return client.classification.findUnique({ where: { id } });
}

// Updates a classification only if `expectedVersion` still matches what's
// in the database, then bumps the version counter. This is the standard
// "optimistic locking" pattern: instead of locking the row up front, we
// just check "has anything changed since I last read this?" at write time.
//
// Why this matters here: two reviewers could both open the same
// classification, and both try to act on it (e.g. one approves while the
// other overrides) without knowing about each other. Whoever writes second
// should be told "this changed since you loaded it" instead of silently
// overwriting the first reviewer's change.
//
// Throws OptimisticLockError if expectedVersion is stale (0 rows updated).
async function updateClassificationWithLock(id, expectedVersion, data, client = prisma) {
  const result = await client.classification.updateMany({
    where: { id, version: expectedVersion },
    data: {
      ...data,
      version: { increment: 1 },
    },
  });

  if (result.count === 0) {
    throw new OptimisticLockError(
      `Classification ${id} was not updated: expected version ${expectedVersion} is stale (someone else updated it first).`
    );
  }

  // updateMany doesn't return the updated row, so fetch it fresh.
  return getClassificationById(id, client);
}

// Lean projection backing the Approvals list/detail pages - deliberately
// selects only { id, fileName, classificationLevel, confidenceScore,
// explanation, submittedAt, reviewed } instead of the full Prisma rows, so
// the browser never receives rawContent, sourceMetadata, evidence,
// referencedGuidance, or modelVersion.
const REVIEW_LIST_SELECT = {
  id: true,
  classificationLevel: true,
  confidenceScore: true,
  explanation: true,
  version: true,
  submission: { select: { id: true, fileName: true, fileType: true, uploadedAt: true } },
  reviewActions: { select: { id: true } },
};

function toReviewSummary(classification) {
  return {
    id: classification.submission.id,
    fileName: classification.submission.fileName,
    fileType: classification.submission.fileType,
    classificationLevel: classification.classificationLevel,
    confidenceScore: classification.confidenceScore,
    explanation: classification.explanation,
    submittedAt: classification.submission.uploadedAt,
    reviewed: classification.reviewActions.length > 0,
  };
}

async function listClassificationsForReview() {
  const classifications = await prisma.classification.findMany({
    select: REVIEW_LIST_SELECT,
    orderBy: { classifiedAt: "desc" },
  });
  return classifications.map(toReviewSummary);
}

// Counts backing the dashboard's "Classification distribution" chart -
// how many classified assets fall into each sensitivity level.
async function getClassificationDistribution() {
  const grouped = await prisma.classification.groupBy({
    by: ["classificationLevel"],
    _count: { _all: true },
  });

  const distribution = { PUBLIC: 0, INTERNAL: 0, CONFIDENTIAL: 0, HIGHLY_CONFIDENTIAL: 0 };
  for (const row of grouped) {
    distribution[row.classificationLevel] = row._count._all;
  }
  return distribution;
}

module.exports = {
  createClassification,
  getClassificationById,
  updateClassificationWithLock,
  listClassificationsForReview,
  getClassificationDistribution,
};

