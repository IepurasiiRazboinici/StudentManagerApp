// Small set of custom error types so callers (API routes, UI handlers, etc.)
// can tell "this failed because of a concurrency conflict" apart from
// generic/unexpected errors, and react accordingly (e.g. show a "someone
// else already reviewed this - please refresh" message).

// Thrown when an update includes a `version` that no longer matches the
// row in the database - i.e. someone else updated it first.
class OptimisticLockError extends Error {
  constructor(message = "The record was modified by someone else. Refresh and try again.") {
    super(message);
    this.name = "OptimisticLockError";
  }
}

module.exports = { OptimisticLockError };
