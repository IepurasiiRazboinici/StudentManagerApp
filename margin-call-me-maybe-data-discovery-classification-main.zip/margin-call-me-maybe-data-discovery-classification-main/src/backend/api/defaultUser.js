// The webui has no login flow yet, but Submission.uploadedById and
// ReviewAction.userId are required foreign keys to User. Rather than block
// the whole integration on building auth, uploads and review decisions are
// each attributed to a single shared account, found-or-created on first
// use. Swap these out once real auth exists.
const { prisma } = require("../db/client");

const ANONYMOUS_USER_EMAIL = "webui@hackathon.local";
const ANONYMOUS_REVIEWER_EMAIL = "webui-reviewer@hackathon.local";

async function getOrCreateAnonymousUser() {
  return prisma.user.upsert({
    where: { email: ANONYMOUS_USER_EMAIL },
    update: {},
    create: {
      name: "Web UI Uploads",
      email: ANONYMOUS_USER_EMAIL,
      role: "INTERN",
    },
  });
}

async function getOrCreateAnonymousReviewer() {
  return prisma.user.upsert({
    where: { email: ANONYMOUS_REVIEWER_EMAIL },
    update: {},
    create: {
      name: "Web UI Reviewer",
      email: ANONYMOUS_REVIEWER_EMAIL,
      role: "REVIEWER",
    },
  });
}

module.exports = { getOrCreateAnonymousUser, getOrCreateAnonymousReviewer, ANONYMOUS_USER_EMAIL, ANONYMOUS_REVIEWER_EMAIL };
