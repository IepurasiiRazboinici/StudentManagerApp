// Node port of classify_with_genai.py, used by the API server so a single
// HTTP request from the UI can classify a whole batch of uploaded files in
// one call to the internal GenAI Service Builder endpoint (the Python
// script's `classify()` already builds one prompt covering every attached
// file and gets back one result per file - we mirror that exactly here so
// both entrypoints stay in sync).
//
// The actual system prompt sent to the model lives in
// DATA_CLASSIFICATION_SYSTEM_PROMPT.md at the repo root (single source of
// truth shared with classify_with_genai.py) - it defines the full
// discovery/profiling/classification rules AND the exact JSON response
// schema (one entry per file under `assets`, each with a nested
// `classification` object).
//
// Requires the GENAI_SERVICE_API_KEY environment variable (bearer token).
// Never hardcode a real key in this file - see .env.example.
const fs = require("fs");
const path = require("path");

const API_URL =
  "https://genai-service-builder.int.refinitiv.com/api/v1/services/" +
  "margincallmemaybeai/agentclassification";
const DEFAULT_MAX_TOKENS = 128000;

const SYSTEM_PROMPT_PATH = path.join(__dirname, "..", "..", "..", "DATA_CLASSIFICATION_SYSTEM_PROMPT.md");
const SYSTEM_PROMPT = fs.readFileSync(SYSTEM_PROMPT_PATH, "utf8");

const USER_INSTRUCTION =
  "Analyze each attached file (and any additional analyst notes) according to " +
  "the system prompt's instructions and return only the single JSON object it " +
  "describes - no Markdown fences, no text before or after it.";

// `fileEntries` is [{ name, content }], `notesText` is an optional combined
// string of any free-text notes + note-file contents provided by the uploader.
function buildPrompt(fileEntries, notesText) {
  const parts = [SYSTEM_PROMPT];

  if (notesText && notesText.trim()) {
    parts.push(`## Additional Analyst Notes\n${notesText}`);
  }

  for (const file of fileEntries) {
    parts.push(`## Attached File: ${file.name}\n\`\`\`\n${file.content}\n\`\`\``);
  }

  parts.push(USER_INSTRUCTION);
  return parts.join("\n\n");
}

// Tolerates replies wrapped in ```json ... ``` fences, matching the Python script.
function extractJson(replyText) {
  const text = replyText.trim();
  const fenced = text.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/);
  return JSON.parse(fenced ? fenced[1] : text);
}

// Sends one batch classification request covering every file in `fileEntries`.
// Returns the parsed response payload: { analysis_date, assets: [...], report_summary }
// (see DATA_CLASSIFICATION_SYSTEM_PROMPT.md for the full schema of each asset).
async function classifyBatch(fileEntries, notesText = "", maxTokens = DEFAULT_MAX_TOKENS) {
  const apiKey = process.env.GENAI_SERVICE_API_KEY;
  if (!apiKey) {
    throw new Error("GENAI_SERVICE_API_KEY environment variable is not set.");
  }
  if (!fileEntries || fileEntries.length === 0) {
    throw new Error("classifyBatch() requires at least one file.");
  }

  const prompt = buildPrompt(fileEntries, notesText);

  const response = await fetch(API_URL, {
    method: "POST",
    headers: {
      "Content-type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({ max_tokens: maxTokens, input1: prompt }),
  });

  if (!response.ok) {
    throw new Error(`GenAI service returned HTTP ${response.status}`);
  }

  const payload = await response.json();
  if (payload.status !== "Success") {
    throw new Error(`GenAI call did not succeed: ${JSON.stringify(payload)}`);
  }

  return extractJson(payload.response);
}

module.exports = { classifyBatch, buildPrompt, extractJson, API_URL, DEFAULT_MAX_TOKENS };
