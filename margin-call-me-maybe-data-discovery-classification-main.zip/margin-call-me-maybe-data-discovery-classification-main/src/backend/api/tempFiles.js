// Writes uploaded (in-memory, multer-buffered) files out to a throwaway
// temp directory so data-discovery's file-based parsers (which read from
// disk via fs.readFileSync) can run against them, then cleans the
// directory back up afterwards.
//
// Security note: multer gives us the original filename from the client,
// which cannot be trusted as-is (it could contain "../" path segments or
// other traversal attempts). We strip everything except the base name and
// a safe character set, and additionally prefix every file with its index
// so two uploads can never collide or overwrite each other.
const fs = require("fs");
const os = require("os");
const path = require("path");
const crypto = require("crypto");

function sanitizeFileName(originalName) {
  const base = path.basename(originalName || "file");
  const safe = base.replace(/[^A-Za-z0-9._-]/g, "_");
  return safe || "file";
}

// `files` is multer's in-memory file array: [{ originalname, buffer }, ...]
// Returns { dir, entries: [{ originalName, safeName, absolutePath }] }.
function writeFilesToTempDir(files) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "classify-upload-"));

  const entries = files.map((file, index) => {
    const safeName = `${index}-${sanitizeFileName(file.originalname)}`;
    const absolutePath = path.join(dir, safeName);
    fs.writeFileSync(absolutePath, file.buffer);
    return { originalName: file.originalname, safeName, absolutePath };
  });

  return { dir, entries };
}

function cleanupTempDir(dir) {
  fs.rmSync(dir, { recursive: true, force: true });
}

module.exports = { sanitizeFileName, writeFilesToTempDir, cleanupTempDir };
