// POST /api/classify
//
// The one endpoint that ties the whole pipeline together:
//   1. Files come in from the UI (multipart upload).
//   2. src/backend/data-discovery profiles each file (row/column counts, samples).
//   3. Each file becomes a PENDING Submission, then gets claimed by its own
//      id (see claimSubmissionById()) - deliberately *not* "claim whichever
//      PENDING row is oldest", since uploads are non-blocking and another
//      request could be claiming submissions at the same moment.
//   4. One batched call to the GenAI service classifies every file at once.
//   5. Each result is written back as a Classification (or the submission
//      is marked FAILED if the model didn't return a result for it).
const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const { runDataDiscovery } = require("../../data-discovery/data-discovery");
const { classifyBatch } = require("../genaiClient");
const { writeFilesToTempDir, cleanupTempDir } = require("../tempFiles");
const { getOrCreateAnonymousUser } = require("../defaultUser");
const { createSubmission, claimSubmissionById, markSubmissionFailed } = require("../../db/submissions");
const { createClassification } = require("../../db/classifications");

const router = express.Router();

const MAX_FILE_SIZE_BYTES = 25 * 1024 * 1024; // 25MB per file, generous for hackathon sample data
const MAX_FILES = 20;

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_FILE_SIZE_BYTES, files: MAX_FILES * 2 },
});

const CLASSIFICATION_LEVEL_MAP = {
  public: "PUBLIC",
  internal: "INTERNAL",
  confidential: "CONFIDENTIAL",
  "highly confidential": "HIGHLY_CONFIDENTIAL",
};

function toClassificationLevel(rawLabel) {
  const key = String(rawLabel || "").trim().toLowerCase();
  return CLASSIFICATION_LEVEL_MAP[key] || null;
}

// Pairs each claimed submission with exactly one asset from the model's
// response, and never hands the same asset out twice - important when a
// batch has several files, since without this a fuzzy name match could
// pair two different submissions to the same asset (one file's summary
// silently reused for another file). Matching happens in two passes over
// a shrinking pool of `remainingAssets`:
//   1. Exact `source_name` match (what we labeled the file as in the
//      prompt) - preferred whenever available.
//   2. Substring fallback (in case the model normalized the name),
//      applied only to submissions that didn't get an exact match, and
//      only against assets not already claimed by an exact match.
function matchAssetsToSubmissions(claimedSubmissions, assets) {
  const remainingAssets = [...assets];
  const matches = new Map(); // submission.id -> asset | null

  for (const { submission, originalName } of claimedSubmissions) {
    const index = remainingAssets.findIndex((asset) => asset.source_name === originalName);
    if (index !== -1) {
      matches.set(submission.id, remainingAssets[index]);
      remainingAssets.splice(index, 1);
    }
  }

  for (const { submission, originalName } of claimedSubmissions) {
    if (matches.has(submission.id)) continue;
    const index = remainingAssets.findIndex(
      (asset) => typeof asset.source_name === "string" && asset.source_name.includes(originalName)
    );
    matches.set(submission.id, index !== -1 ? remainingAssets.splice(index, 1)[0] : null);
  }

  return matches;
}

function buildCombinedNotes(notesText, noteFiles) {
  const parts = [];
  if (notesText && notesText.trim()) parts.push(notesText.trim());
  for (const file of noteFiles || []) {
    const text = file.buffer.toString("utf8").trim();
    if (text) parts.push(`## Note file: ${file.originalname}\n${text}`);
  }
  return parts.join("\n\n");
}

// Runs the (slow) GenAI batch call + writes the resulting Classification
// rows, entirely after the HTTP response has already been sent. The UI
// finds out these submissions are done by polling GET /api/submissions/:id
// (see submissions.js) - this is the "enqueue the job, let the UI poll for
// the result" behavior called out as a known limitation in the README.
async function processClassificationInBackground(claimedSubmissions, fileEntriesForGenai, combinedNotes) {
  let genaiAssets = [];
  try {
    const payload = await classifyBatch(fileEntriesForGenai, combinedNotes);
    genaiAssets = Array.isArray(payload.assets) ? payload.assets : [];
  } catch (genaiError) {
    // The whole batch call failed (network/service error) - mark every
    // submission we just claimed as FAILED rather than leaving them
    // stuck in PROCESSING forever.
    await Promise.all(
      claimedSubmissions.map(({ submission }) => markSubmissionFailed(submission.id))
    );
    // eslint-disable-next-line no-console
    console.error(`GenAI classification failed for batch: ${genaiError.message}`);
    return;
  }

  const assetMatches = matchAssetsToSubmissions(claimedSubmissions, genaiAssets);

  await Promise.all(
    claimedSubmissions.map(async ({ submission }) => {
      try {
        const asset = assetMatches.get(submission.id);
        const classificationInfo = asset?.classification;
        const level = classificationInfo ? toClassificationLevel(classificationInfo.level) : null;

        if (!asset || !classificationInfo || !level) {
          await markSubmissionFailed(submission.id);
          return;
        }

        await createClassification({
          submissionId: submission.id,
          classificationLevel: level,
          confidenceScore: Number(classificationInfo.confidence_score) || 0,
          evidence: classificationInfo.evidence || [],
          referencedGuidance: classificationInfo.referenced_rules || null,
          explanation: classificationInfo.plain_language_explanation || "",
          modelVersion: "genai-service-builder:margincallmemaybeai",
        });
      } catch (writeError) {
        // Don't let one bad submission (e.g. a DB error writing its
        // classification) leave it stuck in PROCESSING forever - that
        // would permanently inflate "AI Decisions Pending" on the
        // dashboard for a job that's actually done trying.
        // eslint-disable-next-line no-console
        console.error(`Failed to record classification for submission ${submission.id}: ${writeError.message}`);
        await markSubmissionFailed(submission.id).catch(() => {});
      }
    })
  );
}

router.post("/", upload.fields([{ name: "files" }, { name: "noteFiles" }]), async (req, res) => {
  const files = req.files?.files || [];
  const noteFiles = req.files?.noteFiles || [];
  const notesText = typeof req.body.notesText === "string" ? req.body.notesText : "";

  if (files.length === 0) {
    return res.status(400).json({ error: "At least one file is required." });
  }

  let tempDir;

  try {
    const { dir, entries } = writeFilesToTempDir(files);
    tempDir = dir;

    // Step 1: profile every uploaded file (rowCount/columns/sample rows).
    const discovery = await runDataDiscovery({
      cwd: tempDir,
      inputs: entries.map((entry) => entry.safeName),
      sampleSize: 5,
    });

    const combinedNotes = buildCombinedNotes(notesText, noteFiles);
    const user = await getOrCreateAnonymousUser();

    // Step 2: create + claim a Submission per file (PENDING -> PROCESSING).
    // Claims the exact row we just created (by id), not just "whichever
    // PENDING row is oldest" - uploads are non-blocking, so another
    // request (e.g. a second batch the user queues up while this one is
    // still going) could be claiming submissions at the same moment, and
    // "claim the oldest pending row" could hand this loop back somebody
    // else's submission instead of the one for `entry`.
    const claimedSubmissions = [];
    const fileEntriesForGenai = [];
    for (let i = 0; i < entries.length; i += 1) {
      const entry = entries[i];
      const discoveryMeta = discovery.files[i] || {};
      const content = fs.readFileSync(entry.absolutePath, "utf8");

      const submission = await createSubmission({
        uploadedById: user.id,
        fileName: entry.originalName,
        fileType: path.extname(entry.originalName).replace(/^\./, "") || "unknown",
        rawContent: { text: content },
        userNotes: combinedNotes || null,
        sourceMetadata: discoveryMeta,
      });

      const claimed = await claimSubmissionById(submission.id);
      claimedSubmissions.push({
        submission: claimed || submission,
        originalName: entry.originalName,
        discoveryMeta,
      });
      fileEntriesForGenai.push({ name: entry.originalName, content });
    }

    // Step 3: respond immediately so the UI can go back to being usable
    // (upload more files, browse elsewhere) instead of blocking on the
    // GenAI call. Every submission is already PROCESSING at this point.
    res.json({
      results: claimedSubmissions.map(({ submission, originalName }) => ({
        id: submission.id,
        fileName: originalName,
        status: "PROCESSING",
      })),
    });

    // Step 4: kick off the slow part (one batched GenAI call + writing
    // back Classification rows) without making the request wait on it.
    // The UI finds out it's done by polling GET /api/submissions/:id.
    processClassificationInBackground(claimedSubmissions, fileEntriesForGenai, combinedNotes).catch((error) => {
      // eslint-disable-next-line no-console
      console.error("Unexpected error during background classification:", error);
    });
  } catch (error) {
    if (!res.headersSent) {
      res.status(500).json({ error: error.message });
    }
  } finally {
    // Safe to clean up now - every file's content was already read into
    // `fileEntriesForGenai` above before this ever runs.
    if (tempDir) cleanupTempDir(tempDir);
  }
});

module.exports = router;
