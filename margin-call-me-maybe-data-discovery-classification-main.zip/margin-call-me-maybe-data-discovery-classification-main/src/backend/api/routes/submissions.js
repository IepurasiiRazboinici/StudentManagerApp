// GET /api/submissions       -> list submissions (optionally ?status=PENDING etc.)
// GET /api/submissions/:id   -> one submission + its classification
// GET /api/submissions/stats -> dashboard stat-card counts
const express = require("express");

const { listSubmissions, getSubmissionById, getSubmissionStats, getFileTypeBreakdown } = require("../../db/submissions");
const { getClassificationDistribution } = require("../../db/classifications");

const router = express.Router();

const VALID_STATUSES = ["PENDING", "PROCESSING", "CLASSIFIED", "FAILED"];

router.get("/stats", async (req, res) => {
  try {
    const [stats, distribution, fileTypes] = await Promise.all([
      getSubmissionStats(),
      getClassificationDistribution(),
      getFileTypeBreakdown(),
    ]);
    res.json({ ...stats, distribution, fileTypes });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get("/", async (req, res) => {
  const { status } = req.query;
  if (status && !VALID_STATUSES.includes(status)) {
    return res.status(400).json({ error: `status must be one of ${VALID_STATUSES.join(", ")}` });
  }

  try {
    const submissions = await listSubmissions(status ? { status } : {});
    res.json({ submissions });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const submission = await getSubmissionById(req.params.id);
    if (!submission) {
      return res.status(404).json({ error: "Submission not found." });
    }
    res.json({ submission });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
