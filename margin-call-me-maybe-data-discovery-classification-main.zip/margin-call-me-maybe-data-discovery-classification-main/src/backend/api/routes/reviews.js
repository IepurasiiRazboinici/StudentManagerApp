// GET  /api/reviews            -> lean list backing the Approvals table
// GET  /api/reviews/:id         -> lean detail backing the Approval detail page
// POST /api/reviews/:id/decision -> record a reviewer's APPROVE/OVERRIDE/COMMENT
//
// `:id` is always a Submission id (matches what /api/classify returns as
// `id`), not a Classification id - that keeps one identifier consistent
// across the whole UI (Upload results -> Approvals list -> Approval detail).
const express = require("express");

const { getSubmissionById } = require("../../db/submissions");
const { listClassificationsForReview } = require("../../db/classifications");
const { addReviewAction } = require("../../db/reviewActions");
const { getOrCreateAnonymousReviewer } = require("../defaultUser");
const { OptimisticLockError } = require("../../db/errors");

const router = express.Router();

const VALID_ACTIONS = ["APPROVE", "OVERRIDE", "COMMENT"];

// The detail page needs more than the list view: evidence/referenced
// guidance for "asset detail and evidence inspection", plus the review
// history so reviewers can see what's already been decided on this asset.
function toReviewDetail(submission) {
  const classification = submission.classification;
  const reviewActions = classification.reviewActions || [];
  return {
    id: submission.id,
    fileName: submission.fileName,
    fileType: submission.fileType,
    classificationLevel: classification.classificationLevel,
    confidenceScore: classification.confidenceScore,
    explanation: classification.explanation,
    evidence: classification.evidence || [],
    referencedGuidance: classification.referencedGuidance || null,
    submittedAt: submission.uploadedAt,
    reviewed: reviewActions.length > 0,
    // Raw text content + a couple of profiling stats, so the detail page
    // can render an actual file preview instead of a placeholder.
    fileContent: submission.rawContent?.text ?? null,
    sourceMetadata: submission.sourceMetadata || null,
    reviewHistory: reviewActions.map((action) => ({
      id: action.id,
      action: action.action,
      newLevel: action.newLevel,
      comment: action.comment,
      actedAt: action.createdAt,
    })),
  };
}

router.get("/", async (req, res) => {
  try {
    const reviews = await listClassificationsForReview();
    res.json({ reviews });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const submission = await getSubmissionById(req.params.id);
    if (!submission || !submission.classification) {
      return res.status(404).json({ error: "No classified submission found for this id." });
    }
    res.json({ review: toReviewDetail(submission) });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post("/:id/decision", async (req, res) => {
  const { action, newLevel, comment } = req.body || {};

  if (!VALID_ACTIONS.includes(action)) {
    return res.status(400).json({ error: `action must be one of ${VALID_ACTIONS.join(", ")}` });
  }

  try {
    const submission = await getSubmissionById(req.params.id);
    if (!submission || !submission.classification) {
      return res.status(404).json({ error: "No classified submission found for this id." });
    }

    const reviewer = await getOrCreateAnonymousReviewer();

    await addReviewAction({
      classificationId: submission.classification.id,
      userId: reviewer.id,
      action,
      newLevel: action === "OVERRIDE" ? newLevel : undefined,
      comment,
      expectedVersion: action === "OVERRIDE" ? submission.classification.version : undefined,
    });

    const updated = await getSubmissionById(req.params.id);
    res.json({ review: toReviewDetail(updated) });
  } catch (error) {
    if (error instanceof OptimisticLockError) {
      return res.status(409).json({ error: error.message });
    }
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
