// Express API server tying the webui frontend to data-discovery, the
// GenAI classifier, and the Prisma database layer. Start with:
//   npm run api
// (the Vite dev server proxies /api/* requests here - see webui/vite.config.js)
const express = require("express");
const cors = require("cors");

const classifyRouter = require("./routes/classify");
const submissionsRouter = require("./routes/submissions");
const reviewsRouter = require("./routes/reviews");

const app = express();
const PORT = process.env.API_PORT || 3001;

app.use(cors());
app.use(express.json());

app.get("/api/health", (req, res) => res.json({ status: "ok" }));
app.use("/api/classify", classifyRouter);
app.use("/api/submissions", submissionsRouter);
app.use("/api/reviews", reviewsRouter);

// Centralized fallback so an unexpected thrown error never leaks a stack
// trace to the client.
app.use((err, req, res, next) => {
  // eslint-disable-next-line no-console
  console.error(err);
  res.status(500).json({ error: "Internal server error." });
});

app.listen(PORT, () => {
  // eslint-disable-next-line no-console
  console.log(`API server listening on http://localhost:${PORT}`);
});

module.exports = app;
