const fs = require("fs");
const os = require("os");
const path = require("path");
const crypto = require("crypto");
const express = require("express");
const multer = require("multer");

const {
  FILES_DIR,
  ensureStore,
  createUploadRecord,
  getUploadRecord,
  updateUploadRecord,
} = require("./upload-store");
const { classifyWithRouting } = require("./scripts/file_to_ai_judgement");
const { runClassificationPipeline } = require("./main");

ensureStore();

const app = express();
app.use(express.json());

const uploadStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, FILES_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname || "");
    cb(null, `${Date.now()}-${crypto.randomUUID()}${ext}`);
  },
});

const upload = multer({ storage: uploadStorage });

function mapStoredFile(file) {
  return {
    id: crypto.randomUUID(),
    originalName: file.originalname,
    mimeType: file.mimetype,
    size: file.size,
    storedPath: file.path,
  };
}

function isTextLike(fileName) {
  const ext = path.extname(fileName || "").toLowerCase();
  return [".txt", ".md", ".log", ".csv", ".tsv", ".json"].includes(ext);
}

function buildNotesFile(record) {
  const chunks = [];

  if (record.notesText && record.notesText.trim()) {
    chunks.push("## Notes Text\n" + record.notesText.trim());
  }

  for (const noteFile of record.noteFiles || []) {
    if (!isTextLike(noteFile.originalName)) {
      continue;
    }

    try {
      const text = fs.readFileSync(noteFile.storedPath, "utf8");
      chunks.push(`## Note File: ${noteFile.originalName}\n${text}`);
    } catch {
      // Ignore unreadable note files so one bad attachment does not block classification.
    }
  }

  if (chunks.length === 0) {
    return null;
  }

  const notesPath = path.join(os.tmpdir(), `classification-notes-${crypto.randomUUID()}.txt`);
  fs.writeFileSync(notesPath, chunks.join("\n\n"), "utf8");
  return notesPath;
}

app.post(
  "/api/uploads",
  upload.fields([
    { name: "files", maxCount: 50 },
    { name: "noteFiles", maxCount: 20 },
  ]),
  (req, res) => {
    const files = (req.files && req.files.files ? req.files.files : []).map(mapStoredFile);
    const noteFiles = (req.files && req.files.noteFiles ? req.files.noteFiles : []).map(mapStoredFile);

    if (files.length === 0) {
      return res.status(400).json({ error: "At least one file is required." });
    }

    const record = createUploadRecord({
      files,
      noteFiles,
      notesText: req.body.notesText || "",
    });

    return res.status(201).json({
      uploadId: record.id,
      status: record.status,
      fileCount: record.files.length,
      noteFileCount: record.noteFiles.length,
    });
  },
);

app.post("/api/uploads/:uploadId/classify", async (req, res) => {
  const { uploadId } = req.params;
  const record = getUploadRecord(uploadId);

  if (!record) {
    return res.status(404).json({ error: "Upload not found." });
  }

  const sampleSize = Number(req.body.sampleSize || 3);
  const notesPath = buildNotesFile(record);

  try {
    updateUploadRecord(uploadId, () => ({ status: "classifying" }));

    const result = await classifyWithRouting({
      files: (record.files || []).map((f) => ({
        path: f.storedPath,
        name: f.originalName,
        source: f.originalName,
      })),
      sampleSize,
      notesPath,
      cwd: process.cwd(),
    });

    const updated = updateUploadRecord(uploadId, () => ({
      status: "classified",
      lastClassification: {
        generatedAt: new Date().toISOString(),
        sampleSize,
        result,
      },
    }));

    return res.json({
      uploadId,
      status: updated ? updated.status : "classified",
      discovery: result.discovery || null,
      profiling: result.profiling || null,
      result,
    });
  } catch (error) {
    updateUploadRecord(uploadId, () => ({ status: "error" }));
    return res.status(500).json({ error: error.message || "Classification failed." });
  } finally {
    if (notesPath && fs.existsSync(notesPath)) {
      fs.unlinkSync(notesPath);
    }
  }
});

app.post("/api/debug/discovery-profile", async (req, res) => {
  const sampleSize = Number(req.body.sampleSize || 3);
  const uploadId = typeof req.body.uploadId === "string" ? req.body.uploadId : "";
  const hasExplicitInputs = Array.isArray(req.body.inputs) && req.body.inputs.length > 0;

  let inputs = [];
  let cwd = process.cwd();

  if (uploadId) {
    const record = getUploadRecord(uploadId);
    if (!record) {
      return res.status(404).json({ error: "Upload not found." });
    }

    inputs = (record.files || []).map((f) => f.storedPath);
    cwd = FILES_DIR;
  } else if (hasExplicitInputs) {
    inputs = req.body.inputs.filter((x) => typeof x === "string" && x.trim() !== "");
    cwd = typeof req.body.cwd === "string" && req.body.cwd.trim() ? req.body.cwd : process.cwd();
  }

  if (inputs.length === 0 && !(Array.isArray(req.body.sqlite) && req.body.sqlite.length > 0) && !req.body.pg) {
    return res.status(400).json({
      error: "Provide one of: uploadId, inputs[], sqlite[], or pg connection details.",
    });
  }

  try {
    const report = await runClassificationPipeline({
      inputs,
      sqlite: Array.isArray(req.body.sqlite) ? req.body.sqlite : [],
      pg: typeof req.body.pg === "string" ? req.body.pg : "",
      schema: typeof req.body.schema === "string" ? req.body.schema : "public",
      sampleSize,
      cwd,
      autoDiscoverInputs: Boolean(req.body.autoDiscoverInputs),
      suppressUnsupportedFiles: Boolean(req.body.suppressUnsupportedFiles),
    });

    return res.json({
      generatedAt: report.generatedAt,
      config: report.config,
      discovery: report.discovery,
      profiling: report.profiling,
      errors: report.errors,
    });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Discovery/profile failed." });
  }
});

app.get("/api/uploads/:uploadId", (req, res) => {
  const record = getUploadRecord(req.params.uploadId);
  if (!record) {
    return res.status(404).json({ error: "Upload not found." });
  }

  return res.json({
    id: record.id,
    status: record.status,
    createdAt: record.createdAt,
    updatedAt: record.updatedAt,
    notesText: record.notesText,
    files: (record.files || []).map((f) => ({
      id: f.id,
      originalName: f.originalName,
      mimeType: f.mimeType,
      size: f.size,
    })),
    noteFiles: (record.noteFiles || []).map((f) => ({
      id: f.id,
      originalName: f.originalName,
      mimeType: f.mimeType,
      size: f.size,
    })),
    lastClassification: record.lastClassification,
  });
});

const port = Number(process.env.PORT || 3001);
app.listen(port, () => {
  console.log(`Backend API listening on http://localhost:${port}`);
});
