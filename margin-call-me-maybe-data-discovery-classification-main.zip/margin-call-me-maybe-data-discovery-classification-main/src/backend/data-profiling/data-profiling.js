/**
 * DATA-PROFILING.JS - Analysis Router
 * ===================================
 * Takes in discovery responses to return profiling results.
 * 
 * Routes discovered assets to appropriate profilers:
 *   - Files → analyzeFileProfile()
 *   - SQLite → profileSqliteDb()
 *   - PostgreSQL → profilePostgres()
 */
const { analyzeFileProfile } = require("./profilers/file-profiler");
const { profileSqliteDb } = require("./profilers/sqlite-profiler");
const { profilePostgres } = require("./profilers/postgres-profiler");

/**
 * Main profiling function that routes each discovered asset to its profiler.
 * @param {Object} discovery - Output from data-discovery.discoverDataAssets()
 * @param {Array} discovery.files - File assets to profile
 * @param {Array} discovery.sqlite - SQLite database files
 * @param {Object} options - Profiling options (sampleSize, pg, schema)
 * @returns {Promise<Object>} Profiling results for all asset types
 */
async function runDataProfiling(discovery, options = {}) {
  const sampleSize = Number.isFinite(Number(options.sampleSize))
    ? Math.max(1, Math.floor(Number(options.sampleSize)))
    : 5;
  const pgConnection = typeof options.pg === "string" ? options.pg : "";
  const schema = options.schema || "public";

  const result = {
    fileProfiles: [],
    sqliteProfiles: [],
    postgresProfile: null,
    errors: [],
  };

  for (const fileAsset of discovery.files || []) {
    if (!fileAsset.exists) {
      result.errors.push({ asset: fileAsset.sourceName, error: "File not found" });
      continue;
    }

    try {
      // Pass already-discovered file metadata instead of re-parsing the file
      result.fileProfiles.push(analyzeFileProfile(fileAsset));
    } catch (error) {
      result.errors.push({ asset: fileAsset.sourceName, error: error.message });
    }
  }

  for (const sqliteAsset of discovery.sqlite || []) {
    if (!sqliteAsset.exists) {
      result.errors.push({ asset: sqliteAsset.sourceName, error: "SQLite file not found" });
      continue;
    }

    try {
      const sqliteProfile = await profileSqliteDb(sqliteAsset.asset, sampleSize);
      result.sqliteProfiles.push(sqliteProfile);
    } catch (error) {
      result.errors.push({ asset: sqliteAsset.sourceName, error: error.message });
    }
  }

  if (pgConnection) {
    try {
      result.postgresProfile = await profilePostgres(pgConnection, schema, sampleSize);
    } catch (error) {
      result.errors.push({ asset: "postgres", error: error.message });
    }
  }

  return result;
}

module.exports = {
  runDataProfiling,
};