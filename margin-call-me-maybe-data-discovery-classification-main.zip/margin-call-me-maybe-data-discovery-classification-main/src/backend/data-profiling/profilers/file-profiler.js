/**
 * FILE-PROFILER.JS - File Profile Analyzer
 * ========================================
 * Takes in discovery response to return analyzed file profile.
 * 
 * Analyzes column patterns and generates dataset summary.
 */
const { summarizeColumns, datasetWideSummary } = require("../signals");

/**
 * Analyzes a file asset from discovery.
 * 
 * @param {Object} fileAsset - Discovered file asset
 * @returns {Object} File profile with analysis results
 */
function analyzeFileProfile(fileAsset) {
  const records = fileAsset.sampleRecords || [];
  const columns = summarizeColumns(records);
  const profiledRowCount = records.length;

  return {
    asset: fileAsset.asset,
    sourceType: fileAsset.sourceType,
    rowCount: fileAsset.rowCount || records.length,
    profiledRowCount,
    columnCount: fileAsset.columnCount || (records.length > 0 ? Object.keys(records[0]).length : 0),
    columns,
    datasetSummary: datasetWideSummary(columns, profiledRowCount),
    sampleRows: records.slice(0, 3),
  };
}

module.exports = {
  analyzeFileProfile,
};
