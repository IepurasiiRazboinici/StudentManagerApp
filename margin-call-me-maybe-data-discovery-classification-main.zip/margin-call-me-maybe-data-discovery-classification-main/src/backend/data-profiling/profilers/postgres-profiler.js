/**
 * POSTGRES-PROFILER.JS - PostgreSQL Database Table Analyzer
 * ===========================================================
 * Profiles tables found in a PostgreSQL schema discovered by data-discovery.
 * 
 * For each table in the schema:
 * 1. Queries information_schema for metadata (columns, declared types, row counts)
 * 2. Samples rows from each table
 * 3. For each column, calculates:
 *    - Null counts and ratios
 *    - Distinct value estimates
 *    - Inferred types using signals.typeFromValues()
 *    - Pattern signals (emails, phones, accounts, money, free text)
 * 4. Generates dataset summary for the table
 * 
 * Uses pg npm package for PostgreSQL client access.
 * Returns profile with all tables in schema and their column-level analysis.
 */
const { typeFromValues, patternSignals, datasetWideSummary } = require("../signals");

/**
 * Profiles all base tables in a PostgreSQL schema.
 * @param {string} connectionString - PostgreSQL connection URI
 * @param {string} schema - Schema name to profile (e.g., 'public')
 * @param {number} sampleSize - Number of rows to sample per table
 */
async function profilePostgres(connectionString, schema, sampleSize) {
  let Client;
  try {
    ({ Client } = require("pg"));
  } catch {
    throw new Error("PostgreSQL profiling needs package pg. Install in WSL with: npm install pg");
  }

  const client = new Client({ connectionString });
  await client.connect();

  try {
    const tableRes = await client.query(
      `SELECT table_name
       FROM information_schema.tables
       WHERE table_schema = $1 AND table_type = 'BASE TABLE'
       ORDER BY table_name`,
      [schema]
    );

    const tableProfiles = [];
    for (const row of tableRes.rows) {
      const tableName = row.table_name;
      const safeSchema = `"${schema.replace(/"/g, '""')}"`;
      const safeTable = `"${tableName.replace(/"/g, '""')}"`;
      const fq = `${safeSchema}.${safeTable}`;

      const colRes = await client.query(
        `SELECT column_name, data_type
         FROM information_schema.columns
         WHERE table_schema = $1 AND table_name = $2
         ORDER BY ordinal_position`,
        [schema, tableName]
      );
      const rowCountRes = await client.query(`SELECT COUNT(*)::bigint AS c FROM ${fq}`);
      const rowCount = Number(rowCountRes.rows[0].c);
      const sampleRes = await client.query(`SELECT * FROM ${fq} LIMIT ${Math.max(1, sampleSize)}`);

      const columnProfiles = [];
      for (const col of colRes.rows) {
        const colName = col.column_name;
        const safeCol = `"${colName.replace(/"/g, '""')}"`;
        const nullRes = await client.query(
          `SELECT COUNT(*)::bigint AS c FROM ${fq} WHERE ${safeCol} IS NULL OR BTRIM(CAST(${safeCol} AS TEXT)) = ''`
        );
        const distinctRes = await client.query(
          `SELECT COUNT(DISTINCT ${safeCol})::bigint AS c FROM ${fq}`
        );
        const sampleValsRes = await client.query(
          `SELECT ${safeCol} AS v FROM ${fq} WHERE ${safeCol} IS NOT NULL LIMIT 5`
        );
        const values = sampleValsRes.rows.map((r) => r.v);

        columnProfiles.push({
          column: colName,
          declaredType: col.data_type,
          inferredType: typeFromValues(values),
          nullCount: Number(nullRes.rows[0].c),
          nullRatio: rowCount ? Number(nullRes.rows[0].c) / rowCount : 0,
          distinctCountEstimate: Number(distinctRes.rows[0].c),
          sampleValues: values.map((v) => String(v)),
          patterns: patternSignals(values),
        });
      }

      tableProfiles.push({
        table: `${schema}.${tableName}`,
        rowCount,
        columnCount: colRes.rows.length,
        columns: columnProfiles,
        datasetSummary: datasetWideSummary(columnProfiles, rowCount),
        sampleRows: sampleRes.rows,
      });
    }

    return {
      sourceType: "postgres",
      asset: `${schema}.*`,
      tableCount: tableRes.rows.length,
      tables: tableProfiles,
    };
  } finally {
    await client.end();
  }
}

module.exports = {
  profilePostgres,
};
