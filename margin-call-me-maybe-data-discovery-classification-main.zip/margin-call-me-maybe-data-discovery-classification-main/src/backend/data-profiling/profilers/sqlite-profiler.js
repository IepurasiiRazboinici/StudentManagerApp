/**
 * SQLITE-PROFILER.JS - SQLite Database Table Analyzer
 * ====================================================
 * Profiles tables found in a SQLite database discovered by data-discovery.
 * 
 * For each table in the database:
 * 1. Queries metadata (column names, types, row count)
 * 2. Samples rows (first N rows defined by sampleSize)
 * 3. For each column, calculates:
 *    - Null counts and ratios
 *    - Distinct value estimates
 *    - Inferred types using signals.typeFromValues()
 *    - Pattern signals (emails, phones, accounts, money, free text)
 * 4. Generates dataset summary for the table
 * 
 * Uses sqlite3 and sqlite npm packages for async database access.
 * Returns profile with all tables and their column-level analysis.
 */
const { typeFromValues, patternSignals, datasetWideSummary } = require("../signals");

/**
 * Profiles all tables in a SQLite database.
 * @param {string} dbPath - Path to SQLite database file
 * @param {number} sampleSize - Number of rows to sample per table
 */
async function profileSqliteDb(dbPath, sampleSize) {
  let sqlite3;
  let open;
  try {
    sqlite3 = require("sqlite3");
    ({ open } = require("sqlite"));
  } catch {
    throw new Error(
      "SQLite profiling needs packages sqlite and sqlite3. Install in WSL with: npm install sqlite sqlite3"
    );
  }

  const db = await open({
    filename: dbPath,
    driver: sqlite3.Database,
  });

  try {
    const tables = await db.all(
      "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
    );

    const tableProfiles = [];
    for (const table of tables) {
      const tableName = table.name;
      const quoted = `"${tableName.replace(/"/g, '""')}"`;
      const columnRows = await db.all(`PRAGMA table_info(${quoted})`);
      const rowCountRow = await db.get(`SELECT COUNT(*) AS count FROM ${quoted}`);
      const rowCount = rowCountRow ? rowCountRow.count : 0;
      const sampleRows = await db.all(`SELECT * FROM ${quoted} LIMIT ${Math.max(1, sampleSize)}`);

      const columnProfiles = [];
      for (const col of columnRows) {
        const colName = col.name;
        const colQuoted = `"${colName.replace(/"/g, '""')}"`;
        const nullRow = await db.get(
          `SELECT COUNT(*) AS c FROM ${quoted} WHERE ${colQuoted} IS NULL OR TRIM(CAST(${colQuoted} AS TEXT)) = ''`
        );
        const distinctRow = await db.get(
          `SELECT COUNT(DISTINCT ${colQuoted}) AS c FROM ${quoted}`
        );

        const sampleValRows = await db.all(
          `SELECT ${colQuoted} AS v FROM ${quoted} WHERE ${colQuoted} IS NOT NULL LIMIT 5`
        );
        const values = sampleValRows.map((x) => x.v);

        columnProfiles.push({
          column: colName,
          declaredType: col.type,
          inferredType: typeFromValues(values),
          nullCount: nullRow ? nullRow.c : 0,
          nullRatio: rowCount ? (nullRow ? nullRow.c : 0) / rowCount : 0,
          distinctCountEstimate: distinctRow ? distinctRow.c : 0,
          sampleValues: values.map((v) => String(v)),
          patterns: patternSignals(values),
        });
      }

      tableProfiles.push({
        table: tableName,
        rowCount,
        columnCount: columnRows.length,
        columns: columnProfiles,
        datasetSummary: datasetWideSummary(columnProfiles, rowCount),
        sampleRows,
      });
    }

    return {
      sourceType: "sqlite",
      asset: dbPath,
      tableCount: tables.length,
      tables: tableProfiles,
    };
  } finally {
    await db.close();
  }
}

module.exports = {
  profileSqliteDb,
};
