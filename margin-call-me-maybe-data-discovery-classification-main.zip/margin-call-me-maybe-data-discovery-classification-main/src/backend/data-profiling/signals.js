/**
 * SIGNALS.JS - Column-Level Pattern & Entity Detection
 * =====================================================
 * Analyzes individual column values to detect sensitive patterns and data types.
 * 
 * Core functions used by file-profiler.js, sqlite-profiler.js, postgres-profiler.js:
 * 
 * summarizeColumns(rows)
 *   - Main entry point: analyzes all columns in a dataset
 *   - For each column, extracts type inference and pattern signals
 *   - Returns array of column summaries with metadata
 * 
 * datasetWideSummary(columns, rowCount)
 *   - Aggregates column-level signals into dataset metrics
 *   - Counts columns with sensitive patterns (>20% threshold)
 *   - Computes completeness ratio and type distribution
 * 
 * Pattern Detection Functions:
 * - patternSignals(values): Detects emails, phones, account IDs, money, free text
 * - detectSemiStructuredSignals(values): Detects JSON and key-value pair structures
 * - typeFromValues(values): Infers column type using threshold-based heuristics
 * 
 * Regex Patterns:
 * - EMAIL_RE: Detects email addresses
 * - PHONE_RE: Detects international and US phone numbers
 * - ACCOUNT_RE: Detects account-like identifiers (ACCT, IBAN, SWIFT, CUSIP, ISIN, EXECID, FUND)
 * - MONEY_RE: Detects numeric values (money-like)
 * - KV_PAIR_RE: Detects key=value pair structures
 */

const EMAIL_RE = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i;
const PHONE_RE = /(?:\+\d{1,3}[\s-]?)?(?:\(?\d{3}\)?[\s-]?)\d{3}[\s-]?\d{4}/;
const ACCOUNT_RE = /(?:ACCT|ACCOUNT|IBAN|SWIFT|CUSIP|ISIN|EXECID|FUND)[_\-;:=\s0-9A-Z()]*/i;
const NAME_RE = /\b([A-Z][a-z]+(?:[-'][A-Z][a-z]+)?\s+[A-Z][a-z]+(?:[-'][A-Z][a-z]+)?)\b/;
const MONEY_RE = /^[-+]?\d+(?:\.\d+)?$/;
const KV_PAIR_RE = /(?:^|[;,(\s])[A-Z0-9_\-]{2,}=.+/i;

function isNumberLike(v) {
  return typeof v === "number" || (typeof v === "string" && MONEY_RE.test(v.trim()));
}

function looksLikeDate(v) {
  if (typeof v !== "string") return false;
  const t = Date.parse(v);
  return Number.isFinite(t);
}

function getNonNull(values) {
  return values.filter((v) => v !== null && v !== undefined && String(v).trim() !== "");
}

function safeJsonParse(text) {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

/**
 * Infers column data type from sample values using threshold-based heuristics.
 * This makes the profiler robust to data quality issues (nulls, mixed types).
 * 
 * Type priority (in order of checking):
 * 1. Number: >90% of values are numeric (including decimal)
 * 2. Boolean: >90% of values are true/false/0/1
 * 3. Datetime: >80% of values parse as ISO dates
 * 4. JSON-string: >80% of values are valid JSON objects/arrays
 * 5. String: Default fallback
 * 
 * @param {Array} values - Sample of column values
 * @returns {string} Inferred type name
 */
function typeFromValues(values) {
  if (values.length === 0) return "empty";
  const nonNull = getNonNull(values);
  if (nonNull.length === 0) return "empty";

  const numRatio = nonNull.filter((v) => isNumberLike(v)).length / nonNull.length;
  if (numRatio > 0.9) return "number";

  const boolRatio = nonNull.filter((v) => {
    const s = String(v).toLowerCase();
    return s === "true" || s === "false" || s === "0" || s === "1";
  }).length / nonNull.length;
  if (boolRatio > 0.9) return "boolean";

  const dateRatio = nonNull.filter((v) => looksLikeDate(String(v))).length / nonNull.length;
  if (dateRatio > 0.8) return "datetime";

  const jsonRatio = nonNull.filter((v) => {
    if (typeof v !== "string") return false;
    const trimmed = v.trim();
    if (!(trimmed.startsWith("{") || trimmed.startsWith("["))) return false;
    try {
      JSON.parse(trimmed);
      return true;
    } catch {
      return false;
    }
  }).length / nonNull.length;
  if (jsonRatio > 0.8) return "json-string";

  return "string";
}

function getNumericStats(values) {
  const nums = values
    .filter((v) => isNumberLike(v))
    .map((v) => Number(v))
    .filter((v) => Number.isFinite(v));

  if (nums.length === 0) return null;

  let min = nums[0];
  let max = nums[0];
  let sum = 0;
  for (const n of nums) {
    if (n < min) min = n;
    if (n > max) max = n;
    sum += n;
  }

  return {
    min,
    max,
    mean: sum / nums.length,
    numericCount: nums.length,
  };
}

function getStringLengthStats(values) {
  const lengths = values.map((v) => String(v).length);
  if (lengths.length === 0) return null;

  let min = lengths[0];
  let max = lengths[0];
  let sum = 0;
  for (const n of lengths) {
    if (n < min) min = n;
    if (n > max) max = n;
    sum += n;
  }

  return {
    min,
    max,
    mean: sum / lengths.length,
  };
}

function detectSemiStructuredSignals(values) {
  const nonNull = getNonNull(values);
  if (nonNull.length === 0) return null;

  let jsonLike = 0;
  let keyValueLike = 0;
  let parsedJsonObjects = 0;
  const jsonKeys = new Map();
  const kvKeys = new Map();

  for (const value of nonNull) {
    const text = String(value).trim();

    if (text.startsWith("{") || text.startsWith("[")) {
      const parsed = safeJsonParse(text);
      if (parsed !== null) {
        jsonLike += 1;
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
          parsedJsonObjects += 1;
          for (const key of Object.keys(parsed)) {
            jsonKeys.set(key, (jsonKeys.get(key) || 0) + 1);
          }
        }
      }
    }

    if (KV_PAIR_RE.test(text)) {
      keyValueLike += 1;
      const matches = text.match(/[A-Z0-9_\-]{2,}=/gi) || [];
      for (const m of matches) {
        const key = m.slice(0, -1);
        kvKeys.set(key, (kvKeys.get(key) || 0) + 1);
      }
    }
  }

  return {
    jsonLikeCount: jsonLike,
    jsonLikeRatio: jsonLike / nonNull.length,
    keyValueLikeCount: keyValueLike,
    keyValueLikeRatio: keyValueLike / nonNull.length,
    parsedJsonObjectCount: parsedJsonObjects,
    topJsonKeys: [...jsonKeys.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .map(([key, count]) => ({ key, count })),
    topKeyValueKeys: [...kvKeys.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .map(([key, count]) => ({ key, count })),
  };
}

/**
 * Detects common sensitive patterns and entities in column values.
 * 
 * Returns both counts and ratios for classification confidence:
 * - emailHits / emailRatio: Email addresses matching EMAIL_RE
 * - phoneHits / phoneRatio: Phone numbers matching PHONE_RE
 * - nameLikeHits / nameLikeRatio: Person-like names (First Last)
 * - accountLikeHits / accountLikeRatio: Account IDs, IBAN, CUSIP, etc. matching ACCOUNT_RE
 * - moneyLikeHits / moneyLikeRatio: Numeric values for financial data
 * - freeTextLikeHits / freeTextLikeRatio: Natural language (8+ words)
 * 
 * Used for data sensitivity classification and field importance ranking.
 * 
 * @param {Array} values - Sample of column values
 * @returns {Object} Pattern signal counts and ratios
 */
function patternSignals(values) {
  const nonNull = getNonNull(values);
  if (nonNull.length === 0) return {};

  const signal = {
    emailHits: 0,
    phoneHits: 0,
    nameLikeHits: 0,
    accountLikeHits: 0,
    moneyLikeHits: 0,
    freeTextLikeHits: 0,
  };

  for (const value of nonNull) {
    const text = String(value);
    if (EMAIL_RE.test(text)) signal.emailHits += 1;
    if (PHONE_RE.test(text)) signal.phoneHits += 1;
    if (NAME_RE.test(text)) signal.nameLikeHits += 1;
    if (ACCOUNT_RE.test(text)) signal.accountLikeHits += 1;
    if (isNumberLike(text)) signal.moneyLikeHits += 1;
    if (text.split(/\s+/).length >= 8) signal.freeTextLikeHits += 1;
  }

  return {
    ...signal,
    totalNonNull: nonNull.length,
    emailRatio: signal.emailHits / nonNull.length,
    phoneRatio: signal.phoneHits / nonNull.length,
    nameLikeRatio: signal.nameLikeHits / nonNull.length,
    accountLikeRatio: signal.accountLikeHits / nonNull.length,
    moneyLikeRatio: signal.moneyLikeHits / nonNull.length,
    freeTextLikeRatio: signal.freeTextLikeHits / nonNull.length,
  };
}

function summarizeColumns(rows) {
  const headers = new Set();
  for (const row of rows) {
    Object.keys(row || {}).forEach((h) => headers.add(h));
  }

  const summaries = [];
  for (const header of headers) {
    const values = rows.map((r) => (r ? r[header] : null));
    const nullCount = values.filter((v) => v === null || v === undefined || String(v).trim() === "").length;
    const nonNull = getNonNull(values);
    const uniqueSet = new Set(nonNull.map((v) => String(v)));
    const distinctRatio = nonNull.length ? uniqueSet.size / nonNull.length : 0;

    summaries.push({
      column: header,
      inferredType: typeFromValues(values),
      nullCount,
      nullRatio: rows.length ? nullCount / rows.length : 0,
      distinctCountEstimate: uniqueSet.size,
      distinctRatio,
      cardinalityClass: distinctRatio > 0.95 ? "high" : distinctRatio > 0.2 ? "medium" : "low",
      sampleValues: [...uniqueSet].slice(0, 5),
      patterns: patternSignals(values),
      numericStats: getNumericStats(nonNull),
      lengthStats: getStringLengthStats(nonNull),
      structureSignals: detectSemiStructuredSignals(nonNull),
    });
  }

  return summaries;
}

/**
 * Aggregates column-level signals into dataset-wide metrics.
 * 
 * Returns:
 * - completenessRatio: (total_cells - total_nulls) / total_cells (0-1 scale)
 * - likelySensitiveColumns: Count of columns with >20% email/phone/account patterns
 * - inferredTypeDistribution: Histogram of column types across the dataset
 * 
 * Used for data quality assessment and sensitivity classification at dataset level.
 * 
 * @param {Array} columns - Array of column summaries from summarizeColumns()
 * @param {number} rowCount - Total number of rows in dataset
 * @returns {Object} Dataset-wide summary statistics
 */
function datasetWideSummary(columns, rowCount) {
  if (!rowCount) {
    return {
      completenessRatio: 0,
      likelySensitiveColumns: 0,
      inferredTypeDistribution: {},
    };
  }

  let totalCells = 0;
  let totalNulls = 0;
  let sensitiveColumns = 0;
  const inferredTypeDistribution = {};

  for (const col of columns) {
    totalCells += rowCount;
    totalNulls += col.nullCount;
    inferredTypeDistribution[col.inferredType] =
      (inferredTypeDistribution[col.inferredType] || 0) + 1;

    const p = col.patterns || {};
    if (
      (p.emailRatio || 0) > 0.2
      || (p.phoneRatio || 0) > 0.2
      || (p.nameLikeRatio || 0) > 0.2
      || (p.accountLikeRatio || 0) > 0.2
    ) {
      sensitiveColumns += 1;
    }
  }

  return {
    completenessRatio: totalCells ? (totalCells - totalNulls) / totalCells : 0,
    likelySensitiveColumns: sensitiveColumns,
    inferredTypeDistribution,
  };
}

module.exports = {
  typeFromValues,
  patternSignals,
  summarizeColumns,
  datasetWideSummary,
  detectSemiStructuredSignals,
};
