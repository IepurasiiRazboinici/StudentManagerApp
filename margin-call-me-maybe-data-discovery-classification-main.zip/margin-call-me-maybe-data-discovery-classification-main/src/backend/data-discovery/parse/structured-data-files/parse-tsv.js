const fs = require("fs");
const { parseDelimited } = require("../parse-delimited");
const { toColumnMetadata } = require("../../metadata-schema");

function parseTsvFile(filePath, sampleSize = 3) {
  const raw = fs.readFileSync(filePath, "utf8");
  const records = parseDelimited(raw, "\t");
  const columns = records.length
    ? Object.keys(records[0]).map((name) => toColumnMetadata(name, "string"))
    : [];

  return {
    records,
    metadata: {
      rowCount: records.length,
      columnCount: columns.length,
      columns,
      sampleRecords: records.slice(0, Math.max(1, sampleSize)),
    },
  };
}

module.exports = {
  parseTsvFile,
};