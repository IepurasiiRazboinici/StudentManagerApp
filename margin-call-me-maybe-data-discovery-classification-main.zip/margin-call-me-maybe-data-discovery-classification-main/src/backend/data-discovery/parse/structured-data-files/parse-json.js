const fs = require("fs");
const { toColumnMetadata } = require("../../metadata-schema");

function parseJsonFile(filePath, sampleSize = 3) {
  const raw = fs.readFileSync(filePath, "utf8");
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return {
      records: [],
      metadata: {
        rowCount: 0,
        columnCount: 0,
        columns: [],
        sampleRecords: [],
        topLevelType: "invalid",
      },
      error: "Invalid JSON",
    };
  }

  let records = [];
  if (Array.isArray(parsed)) {
    records = parsed.filter((x) => x && typeof x === "object" && !Array.isArray(x));
  } else if (parsed && typeof parsed === "object") {
    records = [parsed];
  }

  const columnNames = new Set();
  for (const record of records) {
    Object.keys(record).forEach((key) => columnNames.add(key));
  }

  const columns = [...columnNames].map((name) => toColumnMetadata(name, "json-value"));

  return {
    records,
    metadata: {
      rowCount: records.length,
      columnCount: columns.length,
      columns,
      sampleRecords: records.slice(0, Math.max(1, sampleSize)),
      topLevelType: Array.isArray(parsed) ? "array" : typeof parsed,
    },
  };
}

module.exports = {
  parseJsonFile,
};