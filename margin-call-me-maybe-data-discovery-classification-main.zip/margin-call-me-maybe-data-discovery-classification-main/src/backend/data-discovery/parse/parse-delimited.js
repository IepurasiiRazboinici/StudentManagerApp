// Parses raw delimited text (CSV/TSV) into object records using the first row as headers.
function parseDelimited(raw, delimiter) {
  // Accumulates all parsed rows as arrays of field values.
  const rows = [];
  // Current field buffer.
  let field = "";
  // Current row buffer.
  let row = [];
  // Tracks whether parser is currently inside quoted text.
  let inQuotes = false;

  // Character-by-character parser to correctly handle delimiters/newlines in quotes.
  for (let i = 0; i < raw.length; i += 1) {
    const ch = raw[i];
    const next = raw[i + 1];

    // Toggle quote mode, but treat doubled quotes inside quoted fields as escaped quotes.
    if (ch === '"') {
      if (inQuotes && next === '"') {
        field += '"';
        i += 1;
      } else {
        inQuotes = !inQuotes;
      }
      continue;
    }

    // Delimiter ends a field only when not inside quotes.
    if (!inQuotes && ch === delimiter) {
      row.push(field);
      field = "";
      continue;
    }

    // Newline ends a row only when not inside quotes.
    if (!inQuotes && (ch === "\n" || ch === "\r")) {
      // Handle Windows CRLF as one newline token.
      if (ch === "\r" && next === "\n") i += 1;
      row.push(field);
      field = "";
      // Ignore fully empty rows to reduce noisy records.
      if (row.some((cell) => String(cell).trim() !== "")) {
        rows.push(row);
      }
      row = [];
      continue;
    }

    field += ch;
  }

  // Flush trailing field/row at end-of-file.
  if (field.length > 0 || row.length > 0) {
    row.push(field);
    if (row.some((cell) => String(cell).trim() !== "")) {
      rows.push(row);
    }
  }

  // No data rows found.
  if (rows.length === 0) return [];

  // First row becomes headers; generate fallback names for empty header cells.
  const headers = rows[0].map((h, idx) => {
    const key = String(h || "").trim();
    return key || `col_${idx + 1}`;
  });

  // Convert each row array into an object keyed by header name.
  const records = [];
  for (let i = 1; i < rows.length; i += 1) {
    const source = rows[i];
    const rec = {};
    // Fill missing trailing cells with empty strings for stable shape.
    for (let j = 0; j < headers.length; j += 1) {
      rec[headers[j]] = source[j] !== undefined ? source[j] : "";
    }
    records.push(rec);
  }

  return records;
}

module.exports = {
  parseDelimited,
};