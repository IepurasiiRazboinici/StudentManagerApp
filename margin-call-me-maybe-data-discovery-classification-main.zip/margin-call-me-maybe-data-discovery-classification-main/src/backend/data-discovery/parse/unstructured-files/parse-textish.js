/**
 * PARSE-TEXTISH.JS - Text File Parser
 * ===================================
 * Parses unstructured text files (markdown, text, log) into line-based records.
 * 
 * Preserves original line numbers for evidence traceability in classification results.
 * Skips blank lines but maintains original line indexing.
 */

const fs = require("fs");

/**
 * Parses a text file into line records with original line numbers preserved.
 * 
 * @param {string} filePath - Path to the text file
 * @param {number} sampleSize - Maximum number of records to sample (default 3)
 * @returns {Object} { metadata: { rowCount, columnCount, columns, sampleRecords }, error }
 */
function parseTextishFile(filePath, sampleSize = 3) {
  try {
    const content = fs.readFileSync(filePath, "utf8");
    const lines = content.split(/\r?\n/);

    const records = [];
    for (let i = 0; i < lines.length; i++) {
      const text = lines[i];
      // Skip blank lines but preserve original line numbers (1-indexed in output)
      if (text.trim().length > 0) {
        records.push({
          lineNumber: i + 1,
          text: text,
        });
      }
    }

    return {
      metadata: {
        rowCount: records.length,
        columnCount: 2,
        columns: [
          { column: "lineNumber", type: "number" },
          { column: "text", type: "string" },
        ],
        sampleRecords: records.slice(0, sampleSize),
      },
      error: null,
    };
  } catch (error) {
    return {
      metadata: {
        rowCount: 0,
        columnCount: 0,
        columns: [],
        sampleRecords: [],
      },
      error: error.message,
    };
  }
}

module.exports = {
  parseTextishFile,
};
