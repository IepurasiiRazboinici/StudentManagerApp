const { toColumnMetadata } = require("../../metadata-schema");

async function parseSqliteDatabase(dbPath, sampleSize = 3) {
  let sqlite3;
  let open;
  try {
    sqlite3 = require("sqlite3");
    ({ open } = require("sqlite"));
  } catch {
    throw new Error("SQLite discovery needs packages sqlite and sqlite3");
  }

  const db = await open({
    filename: dbPath,
    driver: sqlite3.Database,
  });

  try {
    const tableRows = await db.all(
      "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
    );

    const tables = [];
    for (const tableRow of tableRows) {
      const tableName = tableRow.name;
      const quoted = `"${tableName.replace(/"/g, '""')}"`;
      const columnRows = await db.all(`PRAGMA table_info(${quoted})`);
      // Full table cardinality is computed via COUNT(*).
      const rowCountRow = await db.get(`SELECT COUNT(*) AS c FROM ${quoted}`);
      // Only a small preview is returned, not full table rows.
      const sampleRecords = await db.all(`SELECT * FROM ${quoted} LIMIT ${Math.max(1, sampleSize)}`);

      tables.push({
        table: tableName,
        rowCount: rowCountRow ? rowCountRow.c : 0,
        columnCount: columnRows.length,
        columns: columnRows.map((col) => toColumnMetadata(col.name, col.type || "")),
        sampleRecords,
      });
    }

    return {
      tableCount: tables.length,
      tables,
    };
  } finally {
    await db.close();
  }
}

module.exports = {
  parseSqliteDatabase,
};