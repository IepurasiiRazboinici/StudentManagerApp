const { toColumnMetadata } = require("../../metadata-schema");

async function parsePostgresDatabase(connectionString, schema, sampleSize = 3) {
  let Client;
  try {
    ({ Client } = require("pg"));
  } catch {
    throw new Error("PostgreSQL discovery needs package pg");
  }

  const client = new Client({ connectionString });
  await client.connect();

  try {
    const tableRes = await client.query(
      `SELECT table_name
       FROM information_schema.tables
       WHERE table_schema = $1 AND table_type = 'BASE TABLE'
       ORDER BY table_name`,
      [schema]
    );

    const tables = [];
    for (const row of tableRes.rows) {
      const tableName = row.table_name;
      const safeSchema = `"${schema.replace(/"/g, '""')}"`;
      const safeTable = `"${tableName.replace(/"/g, '""')}"`;
      const fq = `${safeSchema}.${safeTable}`;

      const colRes = await client.query(
        `SELECT column_name, data_type
         FROM information_schema.columns
         WHERE table_schema = $1 AND table_name = $2
         ORDER BY ordinal_position`,
        [schema, tableName]
      );
      // Full table cardinality is computed via COUNT(*).
      const countRes = await client.query(`SELECT COUNT(*)::bigint AS c FROM ${fq}`);
      // Only a small preview is returned, not full table rows.
      const sampleRes = await client.query(`SELECT * FROM ${fq} LIMIT ${Math.max(1, sampleSize)}`);

      tables.push({
        table: `${schema}.${tableName}`,
        rowCount: Number(countRes.rows[0].c),
        columnCount: colRes.rows.length,
        columns: colRes.rows.map((col) => toColumnMetadata(col.column_name, col.data_type)),
        sampleRecords: sampleRes.rows,
      });
    }

    return {
      tableCount: tables.length,
      tables,
    };
  } finally {
    await client.end();
  }
}

module.exports = {
  parsePostgresDatabase,
};