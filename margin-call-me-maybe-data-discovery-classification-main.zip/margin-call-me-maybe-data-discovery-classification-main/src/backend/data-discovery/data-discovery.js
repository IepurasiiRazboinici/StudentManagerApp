/**
 * DATA-DISCOVERY.JS - Data Discovery Pipeline
 * ============================================
 * Orchestrates complete discovery of all data assets:
 * - Files (CSV, TSV, JSON)
 * - SQLite databases
 * - PostgreSQL tables
 * 
 * Returns normalized metadata + sample records for each discovered asset.
 */
const fs = require("fs");
const path = require("path");
const { normalizeDiscoveryConfig, collectFileInputs, collectDatabaseInputs } = require("./file-input");
const { toAssetMetadata } = require("./metadata-schema");
const { parseCsvFile } = require("./parse/structured-data-files/parse-csv");
const { parseTsvFile } = require("./parse/structured-data-files/parse-tsv");
const { parseJsonFile } = require("./parse/structured-data-files/parse-json");
const { parseTextishFile } = require("./parse/unstructured-files/parse-textish");
const { parseSqliteDatabase } = require("./parse/databases/parse-sqlite");
const { parsePostgresDatabase } = require("./parse/databases/parse-postgres");

/**
 * Discovers file assets and parses structured and text-like ones.
 * Unknown file types are discovered but marked unsupported for parsing.
 */
async function discoverFileAssets(fileInputs, sampleSize, options = {}) {
  const files = [];
  const errors = [];
  const suppressUnsupportedFiles = Boolean(options.suppressUnsupportedFiles);

  for (const fileInput of fileInputs) {
    try {
      // Check file exists
      if (!fs.existsSync(fileInput.asset)) {
        files.push(
          toAssetMetadata({
            ...fileInput,
            exists: false,
            error: "File not found",
          })
        );
        continue;
      }

      // Parse based on source type
      let parseResult;
      if (fileInput.sourceType === "csv") {
        parseResult = parseCsvFile(fileInput.asset, sampleSize);
      } else if (fileInput.sourceType === "tsv") {
        parseResult = parseTsvFile(fileInput.asset, sampleSize);
      } else if (fileInput.sourceType === "json") {
        parseResult = parseJsonFile(fileInput.asset, sampleSize);
      } else if (
        fileInput.sourceType === "markdown"
        || fileInput.sourceType === "text"
        || fileInput.sourceType === "log"
      ) {
        parseResult = parseTextishFile(fileInput.asset, sampleSize);
      } else {
        if (suppressUnsupportedFiles) {
          continue;
        }
        files.push(
          toAssetMetadata({
            ...fileInput,
            exists: true,
            error: `Unsupported file type: ${fileInput.sourceType}`,
          })
        );
        continue;
      }

      // Add asset with parsed metadata
      files.push(
        toAssetMetadata({
          ...fileInput,
          exists: true,
          rowCount: parseResult.metadata.rowCount,
          columnCount: parseResult.metadata.columnCount,
          columns: parseResult.metadata.columns,
          sampleRecords: parseResult.metadata.sampleRecords,
          error: parseResult.error || "",
        })
      );

      if (parseResult.error) {
        errors.push({ asset: fileInput.sourceName, error: parseResult.error });
      }
    } catch (error) {
      files.push(
        toAssetMetadata({
          ...fileInput,
          exists: false,
          error: error.message,
        })
      );
      errors.push({ asset: fileInput.sourceName, error: error.message });
    }
  }

  return { files, errors };
}

/**
 * Discovers SQLite databases
 */
async function discoverSqliteAssets(sqliteInputs, sampleSize) {
  const sqlite = [];
  const errors = [];

  for (const dbInput of sqliteInputs) {
    try {
      // Check database exists
      if (!fs.existsSync(dbInput.asset)) {
        sqlite.push(
          toAssetMetadata({
            ...dbInput,
            exists: false,
            error: "Database file not found",
          })
        );
        continue;
      }

      // Lightweight metadata only (table list, columns, row count, sample rows).
      // No pattern/type analysis here - that's data-profiling's job.
      const result = await parseSqliteDatabase(dbInput.asset, sampleSize);
      const tables = result.tables || [];
      const totalRows = tables.reduce((sum, table) => sum + (table.rowCount || 0), 0);

      sqlite.push(
        toAssetMetadata({
          ...dbInput,
          exists: true,
          table: null,
          tableCount: result.tableCount || 0,
          tables,
          // For DB-level assets, rowCount is total rows across all discovered tables.
          rowCount: totalRows,
          // DB-level asset does not imply one shared schema.
          columnCount: 0,
          columns: [],
          sampleRecords: [],
        })
      );
    } catch (error) {
      sqlite.push(
        toAssetMetadata({
          ...dbInput,
          exists: false,
          error: error.message,
        })
      );
      errors.push({ asset: dbInput.sourceName, error: error.message });
    }
  }

  return { sqlite, errors };
}

/**
 * Discovers PostgreSQL tables
 */
async function discoverPostgresAssets(pgInput, sampleSize) {
  const errors = [];
  let postgres = null;

  if (!pgInput) {
    return { postgres, errors };
  }

  try {
    // Lightweight metadata only (table list, columns, row count, sample rows).
    // No pattern/type analysis here - that's data-profiling's job.
    const result = await parsePostgresDatabase(pgInput.connectionString, pgInput.schema, sampleSize);
    postgres = {
      sourceType: "postgres",
      sourceName: pgInput.sourceName,
      asset: `${pgInput.schema}.*`,
      exists: true,
      tableCount: result.tableCount,
      tables: result.tables,
      error: "",
    };
  } catch (error) {
    errors.push({ asset: "postgres", error: error.message });
  }

  return { postgres, errors };
}

/**
 * Main discovery entrypoint
 * Discovers all data assets (files, SQLite, PostgreSQL)
 * 
 * @param {Object} config - Discovery configuration
 * @param {Array} config.inputs - File paths to discover
 * @param {Array} config.sqlite - SQLite database paths
 * @param {string} config.pg - PostgreSQL connection string
 * @param {string} config.schema - PostgreSQL schema
 * @param {number} config.sampleSize - Sample rows per asset
 * @param {string} config.cwd - Working directory
 * 
 * @returns {Promise<Object>} Discovery result with files, sqlite, postgres, assets, errors
 */
async function runDataDiscovery(config = {}) {
  const normalized = normalizeDiscoveryConfig(config);

  // Collect file and database input descriptors
  const fileInputs = collectFileInputs(normalized);
  const { sqlite: sqliteInputs, postgres: pgInput } = collectDatabaseInputs(normalized);

  // Discover each asset type in parallel
  const [fileResult, sqliteResult, postgresResult] = await Promise.all([
    discoverFileAssets(fileInputs, normalized.sampleSize, {
      suppressUnsupportedFiles: normalized.suppressUnsupportedFiles,
    }),
    discoverSqliteAssets(sqliteInputs, normalized.sampleSize),
    discoverPostgresAssets(pgInput, normalized.sampleSize),
  ]);

  // Flatten all assets into canonical list
  const assets = [
    ...fileResult.files,
    ...sqliteResult.sqlite,
    ...(postgresResult.postgres ? [postgresResult.postgres] : []),
  ];

  // Aggregate errors from all sources
  const allErrors = [
    ...fileResult.errors,
    ...sqliteResult.errors,
    ...postgresResult.errors,
  ];

  return {
    files: fileResult.files,
    sqlite: sqliteResult.sqlite,
    postgres: postgresResult.postgres,
    assets,
    errors: allErrors,
  };
}

module.exports = {
  normalizeDiscoveryConfig,
  runDataDiscovery,
};