# Data Discovery Module

Discovers and parses data assets:
- CSV / TSV / JSON files
- SQLite databases
- PostgreSQL tables

Entry point: `runDataDiscovery()` in `run-data-discovery.js`

## Return Structure

```javascript
{
  files: [],        // Array of file assets
  sqlite: [],       // Array of SQLite assets
  postgres: null,   // PostgreSQL asset (or null if not configured)
  assets: [],       // Flattened list: all files + all sqlite + postgres (if exists)
  errors: []        // Non-fatal discovery errors
}
```

**Note:** `assets` is a convenience array that combines all discovered assets. It's the same data as `files + sqlite + [postgres]` flattened into one list.

Each asset (in `files`, `sqlite`, or `postgres`) has this structure:

| Field | Type | Description |
|-------|------|-------------|
| `sourceType` | string | "csv" \| "tsv" \| "json" \| "sqlite" \| "postgres" |
| `sourceName` | string | User-provided identifier (file path or database name) |
| `asset` | string | Resolved absolute path or connection string |
| `exists` | boolean | Whether the asset was found and accessible |
| `table` | string \| null | Table name (databases only), null for files |
| `rowCount` | number | **Total rows** in asset (not limited) |
| `columnCount` | number | Number of columns |
| `columns` | array | Column metadata: `[{name: "col1", declaredType: "string"}, ...]` |
| `sampleRecords` | array | **First `sampleSize` rows only** (default: 3 rows) |
| `error` | string | Error message if discovery failed, empty string if successful |

## Key Behavior

**For all asset types (files, SQLite, PostgreSQL):**

- `rowCount`: Represents the **actual total** rows (e.g., 1000 rows)
- `sampleRecords`: Contains **only the first N rows** for preview (e.g., first 3 rows)

This means discovery doesn't load entire datasets into memory. It provides total counts for metadata and limited samples for quick preview.

**Specific to files (CSV/TSV/JSON):**
- Files are parsed fully to determine accurate `rowCount`
- `sampleRecords` limited to `sampleSize` parameter

**Specific to databases (SQLite/PostgreSQL):**
- `rowCount` obtained via SQL count queries
- `sampleRecords` obtained via `SELECT ... LIMIT sampleSize`
