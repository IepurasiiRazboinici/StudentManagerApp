const fs = require("fs");
const path = require("path");

// Normalizes user-provided discovery options and applies safe defaults.
function normalizeDiscoveryConfig(config = {}) {
  // Coerce sample size once so downstream code can trust it is numeric.
  const sampleNum = Number(config.sampleSize !== undefined ? config.sampleSize : 3);

  return {
    // Base folder for resolving relative file/database paths.
    cwd: config.cwd || process.cwd(),
    // Explicit file inputs (CSV/TSV/JSON) from CLI/API.
    inputs: Array.isArray(config.inputs) ? config.inputs.filter(Boolean) : [],
    // Whether to auto-scan cwd for structured files when inputs is empty.
    autoDiscoverInputs: config.autoDiscoverInputs !== false,
    // Whether unsupported file types should be skipped without discovery output rows.
    suppressUnsupportedFiles: Boolean(config.suppressUnsupportedFiles),
    // Explicit SQLite database inputs.
    sqlite: Array.isArray(config.sqlite) ? config.sqlite.filter(Boolean) : [],
    // PostgreSQL connection string, usually from --pg or PG_URL.
    pg: typeof config.pg === "string" ? config.pg : process.env.PG_URL || "",
    // PostgreSQL schema to inspect.
    schema: config.schema || "public",
    // Positive integer sample size used by discovery metadata extraction.
    sampleSize: Number.isFinite(sampleNum) && sampleNum > 0 ? Math.floor(sampleNum) : 3,
  };
}

// Infers supported source type from file extension.
function sourceTypeFromPath(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === ".csv") return "csv";
  if (ext === ".tsv") return "tsv";
  if (ext === ".json") return "json";
  if (ext === ".md") return "markdown";
  if (ext === ".txt") return "text";
  if (ext === ".log") return "log";
  return "unknown";
}

// Auto-discovers local structured files when --inputs is not provided.
function discoverLocalFiles(baseDir) {
  // Read only direct files in the folder and keep supported structured formats.
  const entries = fs.readdirSync(baseDir, { withFileTypes: true });
  return entries
    .filter((entry) => entry.isFile())
    .map((entry) => entry.name)
    .filter((name) => /\.(csv|tsv|json)$/i.test(name));
}

// Produces normalized file-source descriptors for discovery pipeline ingestion.
function collectFileInputs(config = {}) {
  const normalized = normalizeDiscoveryConfig(config);
  // Use explicit inputs when provided; otherwise optionally scan cwd for CSV/TSV/JSON files.
  const discoveredInputs = normalized.inputs.length
    ? normalized.inputs
    : (normalized.autoDiscoverInputs ? discoverLocalFiles(normalized.cwd) : []);

  return discoveredInputs.map((input) => {
    // Resolve each input to an absolute local path for reliable downstream IO.
    const absolute = path.isAbsolute(input) ? input : path.join(normalized.cwd, input);
    return {
      // Classify file source by extension.
      sourceType: sourceTypeFromPath(absolute),
      // Preserve the original user-provided input value.
      sourceName: input,
      // Absolute file path used by parser modules.
      asset: absolute,
    };
  });
}

// Produces normalized database-source descriptors (SQLite + PostgreSQL).
function collectDatabaseInputs(config = {}) {
  const normalized = normalizeDiscoveryConfig(config);

  // Resolve each SQLite path to absolute for stable table discovery.
  const sqlite = normalized.sqlite.map((dbPath) => ({
    sourceType: "sqlite",
    sourceName: dbPath,
    asset: path.isAbsolute(dbPath) ? dbPath : path.join(normalized.cwd, dbPath),
  }));

  // Postgres is optional and represented as a single connection descriptor.
  const postgres = normalized.pg
    ? {
        sourceType: "postgres",
        sourceName: "postgres",
        connectionString: normalized.pg,
        schema: normalized.schema,
      }
    : null;

  return {
    sqlite,
    postgres,
  };
}

module.exports = {
  // Exported config and input utilities used by the discovery pipeline.
  normalizeDiscoveryConfig,
  sourceTypeFromPath,
  discoverLocalFiles,
  collectFileInputs,
  collectDatabaseInputs,
};