function toColumnMetadata(name, declaredType = "") {
  return {
    name,
    declaredType,
  };
}

function toAssetMetadata(params) {
  return {
    sourceType: params.sourceType,
    sourceName: params.sourceName,
    asset: params.asset,
    exists: params.exists,
    table: params.table || null,
    rowCount: params.rowCount || 0,
    columnCount: params.columnCount || 0,
    columns: params.columns || [],
    sampleRecords: params.sampleRecords || [],
    error: params.error || "",
  };
}

module.exports = {
  toColumnMetadata,
  toAssetMetadata,
};