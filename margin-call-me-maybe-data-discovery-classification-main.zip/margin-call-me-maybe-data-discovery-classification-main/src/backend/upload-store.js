const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const STORAGE_DIR = path.resolve(__dirname, "storage");
const FILES_DIR = path.join(STORAGE_DIR, "files");
const DB_PATH = path.join(STORAGE_DIR, "uploads.json");

function ensureStore() {
  fs.mkdirSync(FILES_DIR, { recursive: true });
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify({ uploads: [] }, null, 2), "utf8");
  }
}

function readDb() {
  ensureStore();
  return JSON.parse(fs.readFileSync(DB_PATH, "utf8"));
}

function writeDb(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), "utf8");
}

function createUploadRecord({ files, noteFiles, notesText }) {
  const db = readDb();
  const uploadId = crypto.randomUUID();
  const now = new Date().toISOString();

  const record = {
    id: uploadId,
    createdAt: now,
    updatedAt: now,
    status: "uploaded",
    notesText: notesText || "",
    files,
    noteFiles,
    lastClassification: null,
  };

  db.uploads.push(record);
  writeDb(db);
  return record;
}

function getUploadRecord(uploadId) {
  const db = readDb();
  return db.uploads.find((u) => u.id === uploadId) || null;
}

function updateUploadRecord(uploadId, updater) {
  const db = readDb();
  const index = db.uploads.findIndex((u) => u.id === uploadId);
  if (index < 0) return null;

  const current = db.uploads[index];
  const updated = {
    ...current,
    ...updater(current),
    updatedAt: new Date().toISOString(),
  };

  db.uploads[index] = updated;
  writeDb(db);
  return updated;
}

module.exports = {
  STORAGE_DIR,
  FILES_DIR,
  ensureStore,
  createUploadRecord,
  getUploadRecord,
  updateUploadRecord,
};
