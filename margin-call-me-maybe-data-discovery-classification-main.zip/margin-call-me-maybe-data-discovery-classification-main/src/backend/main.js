/**
 * MAIN.JS - Main Data Classification Pipeline
 * ============================================
 * Coordinates the complete end-to-end pipeline:
 * 1. Data discovery - identifies all data assets (files, databases)
 * 2. Data profiling - analyzes discovered assets for patterns & sensitivity
 * 3. Report generation - combines results into unified classification report
 * 
 * The orchestration layer handles parsing and data preparation.
 * Profilers receive ready-to-analyze data and focus on analysis only.
 * 
 * Usage:
 *   const { runClassificationPipeline } = require('./main');
 *   const report = await runClassificationPipeline({
 *     inputs: ['file1.csv', 'file2.json'],
 *     sqlite: ['db.sqlite'],
 *     pg: 'postgresql://user:pass@host/db',
 *     schema: 'public',
 *     sampleSize: 5,
 *     cwd: process.cwd()
 *   });
 */
const { runDataDiscovery } = require("./data-discovery/data-discovery");
const { runDataProfiling } = require("./data-profiling/data-profiling");

/**
 * Runs the complete discovery + profiling pipeline.
 * 
 * @param {Object} config - Pipeline configuration
 * @param {Array} config.inputs - File paths to discover and profile (CSV, TSV, JSON)
 * @param {Array} config.sqlite - SQLite database paths
 * @param {string} config.pg - PostgreSQL connection string
 * @param {string} config.schema - PostgreSQL schema name (default: 'public')
 * @param {number} config.sampleSize - Sample rows per table (default: 5)
 * @param {string} config.cwd - Working directory (default: process.cwd())
 * 
 * @returns {Promise<Object>} Complete report with discovery + profiling results
 */
async function runClassificationPipeline(config = {}) {
  // Step 1: Discover all data assets (files, databases)
  const discovery = await runDataDiscovery({
    inputs: config.inputs || [],
    sqlite: config.sqlite || [],
    pg: config.pg || "",
    schema: config.schema || "public",
    sampleSize: config.sampleSize || 5,
    cwd: config.cwd || process.cwd(),
    autoDiscoverInputs: config.autoDiscoverInputs,
    suppressUnsupportedFiles: config.suppressUnsupportedFiles,
  });

  // Step 2: Profile each discovered asset
  const profiling = await runDataProfiling(discovery, {
    sampleSize: config.sampleSize || 5,
    pg: config.pg || "",
    schema: config.schema || "public",
  });

  // Step 3: Combine into unified report
  const report = {
    generatedAt: new Date().toISOString(),
    pipelineVersion: "1.0",
    config: {
      inputs: config.inputs || [],
      sqlite: config.sqlite || [],
      hasPostgres: Boolean(config.pg),
      schema: config.schema || "public",
      sampleSize: config.sampleSize || 5,
      cwd: config.cwd || process.cwd(),
      autoDiscoverInputs: config.autoDiscoverInputs !== false,
      suppressUnsupportedFiles: Boolean(config.suppressUnsupportedFiles),
    },
    discovery,
    profiling,
    errors: [
      ...(discovery.errors || []),
      ...(profiling.errors || []),
    ],
  };

  return report;
}

module.exports = {
  runClassificationPipeline,
};
