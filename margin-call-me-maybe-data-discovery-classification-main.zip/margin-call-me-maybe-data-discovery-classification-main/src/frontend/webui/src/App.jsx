import { NavLink, Navigate, Route, Routes } from "react-router-dom";
import AppHeader from "./components/AppHeader";
import DashboardPage from "./pages/DashboardPage";
import UploadPage from "./pages/UploadPage";
import ApprovalsPage  from "./pages/ApprovalsPage.jsx";
import ApprovalDetailPage from "./pages/ApprovalDetailPage.jsx";
import AboutPage from "./pages/AboutPage.jsx";
import "./App.css";

export default function App() {
    return (
        <div className="app-shell">
            <AppHeader />
            <div className="app-body">
                <aside className="side-nav">
                    <NavLink to="/dashboard" className={({ isActive }) => (isActive ? "nav-link active" : "nav-link")}>
                        Dashboard
                    </NavLink>
                    <NavLink to="/upload" className={({ isActive }) => (isActive ? "nav-link active" : "nav-link")}>
                        Upload
                    </NavLink>
                    <NavLink to="/approvals" className={({ isActive }) => (isActive ? "nav-link active" : "nav-link")}>
                        Approvals
                    </NavLink>
                    <NavLink to="/about" className={({ isActive }) => (isActive ? "nav-link active" : "nav-link")}>
                        About
                    </NavLink>
                </aside>

                <main className="app-main">
                    <Routes>
                        <Route path="/" element={<Navigate to="/dashboard" replace />} />
                        <Route path="/dashboard" element={<DashboardPage />} />
                        <Route path="/upload" element={<UploadPage />} />
                        <Route path="/approvals" element={<ApprovalsPage />} />
                        <Route path="/approvals/:id" element={<ApprovalDetailPage />} />
                        <Route path="/about" element={<AboutPage />} />
                    </Routes>
                </main>
            </div>
        </div>
    );
}