// src/webui/src/data/aiJudgements.js
export const aiJudgements = [
    {
        id: "AJ-1001",
        fileName: "invoice-q2.pdf",
        fileUrl: "/mock-files/invoice-q2.pdf", // placeholder
        aiConfidentiality: "Internal",
        confidence: "94%",
        reasoning:
            "Contains financial summaries and vendor identifiers. No personal sensitive data detected, but operationally sensitive details are present.",
        submittedAt: "2026-07-23 08:40",
        flaggedForReview: false,
    },
    {
        id: "AJ-1002",
        fileName: "nda-client-a.docx",
        fileUrl: "/mock-files/nda-client-a.pdf", // placeholder
        aiConfidentiality: "Restricted",
        confidence: "88%",
        reasoning:
            "Document includes contractual terms and client obligations. Potential legal impact if disclosed externally.",
        submittedAt: "2026-07-23 08:52",
        flaggedForReview: true,
    },
];