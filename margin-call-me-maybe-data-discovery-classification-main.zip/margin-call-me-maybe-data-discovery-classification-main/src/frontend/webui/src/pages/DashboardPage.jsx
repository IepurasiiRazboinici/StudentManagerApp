import { useEffect, useState } from "react";

const LEVEL_LABELS = {
    PUBLIC: "Public",
    INTERNAL: "Internal",
    CONFIDENTIAL: "Confidential",
    HIGHLY_CONFIDENTIAL: "Highly Confidential",
};

const LEVEL_COLORS = {
    PUBLIC: "#16a34a",
    INTERNAL: "#1157e0",
    CONFIDENTIAL: "#f59e0b",
    HIGHLY_CONFIDENTIAL: "#dc2626",
};

const FILE_TYPE_COLORS = ["#1157e0", "#2f8fff", "#0a2f7a", "#00b8a9", "#f59e0b", "#16a34a"];

export default function DashboardPage() {
    const [stats, setStats] = useState(null);
    const [error, setError] = useState("");

    useEffect(() => {
        let cancelled = false;

        function loadStats() {
            fetch("/api/submissions/stats")
                .then((response) => response.json().then((data) => ({ ok: response.ok, data })))
                .then(({ ok, data }) => {
                    if (cancelled) return;
                    if (!ok) {
                        setError(data.error || "Could not load stats.");
                        return;
                    }
                    setError("");
                    setStats(data);
                })
                .catch((err) => {
                    if (!cancelled) setError(err.message);
                });
        }

        // Load immediately, then keep polling so numbers stay live while
        // background classification jobs (kicked off from the Upload page)
        // finish without needing a manual page refresh.
        loadStats();
        const intervalId = setInterval(loadStats, 5000);

        return () => {
            cancelled = true;
            clearInterval(intervalId);
        };
    }, []);

    const distribution = stats?.distribution || {};
    const distributionTotal = Object.values(distribution).reduce((sum, count) => sum + count, 0);
    const reviewedCount = stats ? Math.max(0, distributionTotal - stats.pendingReview) : 0;

    const statCards = [
        { title: "Files Processed", value: stats ? stats.totalSubmissions : "—" },
        { title: "Classified Today", value: stats ? stats.classifiedToday : "—" },
        { title: "AI Decisions Pending", value: stats ? stats.aiDecisionsPending : "—", accent: true },
        { title: "Awaiting Human Approval", value: stats ? stats.pendingReview : "—" },
    ];

    const fileTypes = stats?.fileTypes || [];
    const fileTypesTotal = fileTypes.reduce((sum, row) => sum + row.count, 0);

    const reviewSegments =
        distributionTotal > 0
            ? [
                  { label: "Reviewed", count: reviewedCount, color: "#00b8a9" },
                  { label: "Awaiting Approval", count: stats.pendingReview, color: "#f59e0b" },
              ]
            : [];

    // Builds a conic-gradient() string so the "Review Status" ring chart
    // needs no charting library - just plain CSS.
    function conicGradient(segments, total) {
        let cursor = 0;
        const stops = segments.map((segment) => {
            const start = (cursor / total) * 360;
            cursor += segment.count;
            const end = (cursor / total) * 360;
            return `${segment.color} ${start}deg ${end}deg`;
        });
        return `conic-gradient(${stops.join(", ")})`;
    }

    return (
        <section className="dashboard page-enter">
            <h2>Dashboard</h2>
            {error ? <p className="upload-error">Could not load stats: {error}</p> : null}
            <div className="stat-grid">
                {statCards.map((item) => (
                    <article key={item.title} className={item.accent ? "stat-card stat-card-accent" : "stat-card"}>
                        <h3>{item.title}</h3>
                        <p>{item.value}</p>
                    </article>
                ))}
            </div>

            <div className="graph-grid">
                <article className="graph-card">
                    <h3>Classification Distribution</h3>
                    {distributionTotal > 0 ? (
                        <div className="distribution-chart">
                            {Object.entries(distribution).map(([level, count]) => (
                                <div key={level} className="distribution-row">
                                    <span className="distribution-label">{LEVEL_LABELS[level] || level}</span>
                                    <div className="distribution-bar-track">
                                        <div
                                            className="distribution-bar-fill"
                                            style={{
                                                width: `${Math.max(2, (count / distributionTotal) * 100)}%`,
                                                background: LEVEL_COLORS[level] || "#64748b",
                                            }}
                                        />
                                    </div>
                                    <span className="distribution-count">{count}</span>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="graph-placeholder">No classified assets yet</div>
                    )}
                </article>

                <article className="graph-card">
                    <h3>Review Status</h3>
                    {distributionTotal > 0 ? (
                        <div className="donut-wrap">
                            <div
                                className="donut-chart"
                                style={{ background: conicGradient(reviewSegments, distributionTotal) }}
                            >
                                <div className="donut-hole">
                                    <strong>{Math.round((reviewedCount / distributionTotal) * 100)}%</strong>
                                    <span className="muted">reviewed</span>
                                </div>
                            </div>
                            <ul className="donut-legend">
                                {reviewSegments.map((segment) => (
                                    <li key={segment.label}>
                                        <span className="legend-swatch" style={{ background: segment.color }} />
                                        {segment.label} ({segment.count})
                                    </li>
                                ))}
                            </ul>
                        </div>
                    ) : (
                        <div className="graph-placeholder">No classified assets yet</div>
                    )}
                </article>

                <article className="graph-card">
                    <h3>Files by Type</h3>
                    {fileTypes.length > 0 ? (
                        <div className="distribution-chart">
                            {fileTypes.map((row, index) => (
                                <div key={row.fileType} className="distribution-row">
                                    <span className="distribution-label">{row.fileType}</span>
                                    <div className="distribution-bar-track">
                                        <div
                                            className="distribution-bar-fill"
                                            style={{
                                                width: `${Math.max(2, (row.count / fileTypesTotal) * 100)}%`,
                                                background: FILE_TYPE_COLORS[index % FILE_TYPE_COLORS.length],
                                            }}
                                        />
                                    </div>
                                    <span className="distribution-count">{row.count}</span>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="graph-placeholder">No files uploaded yet</div>
                    )}
                </article>
            </div>
        </section>
    );
}

