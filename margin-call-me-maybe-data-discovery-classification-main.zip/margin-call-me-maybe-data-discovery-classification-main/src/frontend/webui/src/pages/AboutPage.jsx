// src/frontend/webui/src/pages/AboutPage.jsx
//
// A largely static, presentational page - explains what ClassifAI does and
// how it's built, for both business stakeholders (plain English) and
// technical reviewers (a real, interactive architecture diagram). Client
// side interactivity: clicking a pipeline stage/diagram node expands its
// detail card, a Business/Technical toggle switches the "How it works"
// view, the FAQ is an accordion, and press-and-hold on any card calls it
// out with a highlight glow (handy when walking someone through the page).
import { useState } from "react";
import ArchitectureDiagram from "../components/ArchitectureDiagram";
import LongPressHighlight from "../components/LongPressHighlight";
import {
    IconUpload,
    IconSearch,
    IconSpark,
    IconDatabase,
    IconCheckCircle,
    IconChartBar,
    IconBolt,
    IconLayers,
    IconLock,
    IconUserCheck,
} from "../components/icons";

const STAGES = [
    {
        id: "upload",
        Icon: IconUpload,
        title: "Upload",
        blurb: "Analysts drop files in",
        description:
            "A user drags in one or more files - spreadsheets, reports, exports, notes - and optionally adds a note explaining context. That's the only manual step in the whole process.",
    },
    {
        id: "discovery",
        Icon: IconSearch,
        title: "Data Discovery & Profiling",
        blurb: "The system reads and understands each file",
        description:
            "Before anything is judged, the system quickly looks at the shape of the data - how many rows, what columns, a few sample values - so the AI has real structure to reason about, not just a filename.",
    },
    {
        id: "genai",
        Icon: IconSpark,
        title: "AI Classification",
        blurb: "One AI call judges every file in the batch",
        description:
            "The AI - powered by Claude Sonnet 4.6 - reads the profiled data against a fixed set of classification rules and decides how sensitive each file is - Public, Internal, Confidential, or Highly Confidential - and explains why in plain language.",
    },
    {
        id: "storage",
        Icon: IconDatabase,
        title: "Secure Storage",
        blurb: "Every decision is recorded, not just displayed",
        description:
            "Nothing lives only on-screen. Every file, every AI decision, and every human review action is saved permanently, so there's always a clear record of who decided what, and when.",
    },
    {
        id: "review",
        Icon: IconCheckCircle,
        title: "Human Review",
        blurb: "A person always has the final say",
        description:
            "The AI's judgement is a recommendation, not a verdict. A reviewer sees the evidence and reasoning, and can accept it, override it with a different sensitivity level, or flag it with a comment for someone else to look at.",
    },
    {
        id: "dashboard",
        Icon: IconChartBar,
        title: "Dashboard & Reporting",
        blurb: "Leaders see the big picture in real time",
        description:
            "A live dashboard shows how much has been processed, what's still waiting on the AI or a human, and how sensitive data breaks down across the organization - updating automatically as new files come in.",
    },
];

const BENEFITS = [
    { Icon: IconBolt, title: "Fast", text: "Minutes instead of hours per document, with no loss of rigor." },
    { Icon: IconLayers, title: "Consistent", text: "The same rules are applied every time, for every file, by every user." },
    { Icon: IconLock, title: "Auditable", text: "Every decision - AI or human - is permanently recorded and explainable." },
    { Icon: IconUserCheck, title: "Human-in-the-loop", text: "The AI recommends; a person always approves, overrides, or flags." },
];

const FAQS = [
    {
        q: "What problem does this actually solve?",
        a: "Classifying data by sensitivity (Public, Internal, Confidential, Highly Confidential) used to be manual, slow, and inconsistent. ClassifAI automates the first pass so people spend their time reviewing decisions, not making every single one from scratch.",
    },
    {
        q: "Does the AI make the final decision?",
        a: "No. Every AI classification lands in an approvals queue where a human explicitly accepts it, overrides it, or flags it for further review before it's considered final.",
    },
    {
        q: "What AI model powers the classification?",
        a: "Claude Sonnet 4.6, called through the internal GenAI Service Builder endpoint with a fixed system prompt that defines every classification rule - so results stay consistent across every file and every user.",
    },
    {
        q: "What happens to my files?",
        a: "Files are profiled (structure + redacted samples) rather than exposed wholesale to the model where possible, and every submission, classification, and review decision is stored durably in PostgreSQL for a full audit trail.",
    },
    {
        q: "Can this handle more than one file at a time?",
        a: "Yes - uploads are batched and processed in the background, so you can queue up a new batch while an earlier one is still being classified, and track each file's status independently.",
    },
];

function StageDetailCard({ stage }) {
    const Icon = stage.Icon;
    return (
        <LongPressHighlight as="div" className="stage-detail-card">
            <div className="stage-detail-head">
                <span className="stage-detail-icon">
                    <Icon />
                </span>
                <div>
                    <h4>{stage.title}</h4>
                    <p className="muted">{stage.blurb}</p>
                </div>
            </div>
            <p className="stage-detail-body">{stage.description}</p>
        </LongPressHighlight>
    );
}

export default function AboutPage() {
    const [activeStageId, setActiveStageId] = useState(STAGES[0].id);
    const [mode, setMode] = useState("business");
    const [openFaqIndex, setOpenFaqIndex] = useState(0);

    const activeStage = STAGES.find((s) => s.id === activeStageId) || STAGES[0];

    return (
        <section className="about-page page-enter">
            <header className="about-hero">
                <span className="about-eyebrow">About this product</span>
                <h2>Turning data classification into an automated, auditable pipeline</h2>
                <p className="about-hero-sub">
                    ClassifAI reads uploaded data, uses AI to judge how sensitive it is, and puts every decision in
                    front of a human before it counts - so nothing gets classified blindly, and nothing gets lost.
                </p>
            </header>

            <div className="benefits-grid">
                {BENEFITS.map((b) => {
                    const Icon = b.Icon;
                    return (
                        <LongPressHighlight as="article" key={b.title} className="benefit-card">
                            <span className="benefit-icon">
                                <Icon />
                            </span>
                            <h4>{b.title}</h4>
                            <p className="muted">{b.text}</p>
                        </LongPressHighlight>
                    );
                })}
            </div>

            <article className="about-section-card">
                <div className="about-section-head">
                    <h3>How it works</h3>
                    <div className="mode-toggle" role="tablist" aria-label="Explanation detail level">
                        <button
                            type="button"
                            role="tab"
                            aria-selected={mode === "business"}
                            className={mode === "business" ? "mode-toggle-btn active" : "mode-toggle-btn"}
                            onClick={() => setMode("business")}
                        >
                            Business Interpretation
                        </button>
                        <button
                            type="button"
                            role="tab"
                            aria-selected={mode === "technical"}
                            className={mode === "technical" ? "mode-toggle-btn active" : "mode-toggle-btn"}
                            onClick={() => setMode("technical")}
                        >
                            Technical
                        </button>
                    </div>
                </div>

                {mode === "business" ? (
                    <>
                        <p className="muted about-section-hint">Click a stage below to see what happens there.</p>

                        <div className="stage-flow">
                            {STAGES.map((stage, index) => {
                                const Icon = stage.Icon;
                                return (
                                    <div className="stage-flow-item" key={stage.id}>
                                        <LongPressHighlight
                                            as="button"
                                            type="button"
                                            className={stage.id === activeStageId ? "stage-node active" : "stage-node"}
                                            onClick={() => setActiveStageId(stage.id)}
                                        >
                                            <span className="stage-node-icon">
                                                <Icon />
                                            </span>
                                            <span className="stage-node-title">{stage.title}</span>
                                        </LongPressHighlight>
                                        {index < STAGES.length - 1 ? (
                                            <span className="stage-arrow" aria-hidden="true">&rsaquo;</span>
                                        ) : null}
                                    </div>
                                );
                            })}
                        </div>

                        <StageDetailCard stage={activeStage} />
                    </>
                ) : (
                    <>
                        <p className="muted about-section-hint">
                            Click a layer below to see what's inside it and how it connects to the rest of the system.
                        </p>
                        <ArchitectureDiagram />
                    </>
                )}
            </article>

            <article className="about-section-card">
                <h3>Frequently asked questions</h3>
                <div className="faq-list">
                    {FAQS.map((faq, index) => {
                        const isOpen = openFaqIndex === index;
                        return (
                            <LongPressHighlight
                                as="div"
                                className={isOpen ? "faq-item open" : "faq-item"}
                                key={faq.q}
                            >
                                <button
                                    type="button"
                                    className="faq-question"
                                    onClick={() => setOpenFaqIndex(isOpen ? -1 : index)}
                                    aria-expanded={isOpen}
                                >
                                    {faq.q}
                                    <span className="faq-chevron" aria-hidden="true">&#8250;</span>
                                </button>
                                <div className="faq-answer-wrap">
                                    <p className="faq-answer">{faq.a}</p>
                                </div>
                            </LongPressHighlight>
                        );
                    })}
                </div>
            </article>
        </section>
    );
}

