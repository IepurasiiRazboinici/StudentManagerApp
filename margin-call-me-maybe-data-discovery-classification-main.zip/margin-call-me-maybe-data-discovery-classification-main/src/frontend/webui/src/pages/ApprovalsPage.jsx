// src/frontend/webui/src/pages/ApprovalsPage.jsx
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

const LEVEL_OPTIONS = [
    { value: "", label: "All levels" },
    { value: "PUBLIC", label: "Public" },
    { value: "INTERNAL", label: "Internal" },
    { value: "CONFIDENTIAL", label: "Confidential" },
    { value: "HIGHLY_CONFIDENTIAL", label: "Highly Confidential" },
];

function toCsv(rows) {
    const header = ["Record ID", "File", "Type", "Classification", "Confidence", "Submitted", "Reviewed"];
    const lines = rows.map((row) =>
        [
            row.id,
            row.fileName,
            row.fileType || "",
            row.classificationLevel,
            Math.round((row.confidenceScore || 0) * 100) + "%",
            new Date(row.submittedAt).toISOString(),
            row.reviewed ? "yes" : "no",
        ]
            .map((value) => `"${String(value).replace(/"/g, '""')}"`)
            .join(",")
    );
    return [header.join(","), ...lines].join("\n");
}

export default function ApprovalsPage() {
    const navigate = useNavigate();
    const [rows, setRows] = useState([]);
    const [error, setError] = useState("");

    const [search, setSearch] = useState("");
    const [levelFilter, setLevelFilter] = useState("");
    const [minConfidence, setMinConfidence] = useState("");
    const [activeTab, setActiveTab] = useState("pending"); // "pending" | "reviewed"

    useEffect(() => {
        let cancelled = false;

        fetch("/api/reviews")
            .then((response) => response.json())
            .then((data) => {
                if (!cancelled) setRows((data.reviews || []).map((row) => ({ ...row, flaggedForReview: false })));
            })
            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        return () => {
            cancelled = true;
        };
    }, []);

    // Flagging is a client-side-only convenience for now - there's no
    // dedicated "flag" field in the schema yet, so this doesn't persist
    // across reloads. See README known limitations.
    function toggleFlag(id) {
        setRows((prev) =>
            prev.map((r) => (r.id === id ? { ...r, flaggedForReview: !r.flaggedForReview } : r)),
        );
    }

    const baseFilteredRows = useMemo(() => {
        const searchLower = search.trim().toLowerCase();
        const minConfidenceValue = minConfidence === "" ? 0 : Number(minConfidence) / 100;

        return rows.filter((row) => {
            if (levelFilter && row.classificationLevel !== levelFilter) return false;
            if ((row.confidenceScore || 0) < minConfidenceValue) return false;
            if (
                searchLower &&
                !row.fileName.toLowerCase().includes(searchLower) &&
                !(row.fileType || "").toLowerCase().includes(searchLower)
            ) {
                return false;
            }
            return true;
        });
    }, [rows, search, levelFilter, minConfidence]);

    const pendingRows = useMemo(() => baseFilteredRows.filter((row) => !row.reviewed), [baseFilteredRows]);
    const reviewedRows = useMemo(() => baseFilteredRows.filter((row) => row.reviewed), [baseFilteredRows]);
    const filteredRows = activeTab === "reviewed" ? reviewedRows : pendingRows;

    function handleExport() {
        const csv = toCsv(filteredRows);
        const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `classification-report-${new Date().toISOString().slice(0, 10)}.csv`;
        link.click();
        URL.revokeObjectURL(url);
    }

    return (
        <section className="approvals-page page-enter">
            <h2>Approvals</h2>
            {error ? <p className="upload-error">Could not load reviews: {error}</p> : null}

            <div className="approvals-tabs">
                <button
                    type="button"
                    className={activeTab === "pending" ? "approvals-tab active" : "approvals-tab"}
                    onClick={() => setActiveTab("pending")}
                >
                    Awaiting Approval <span className="tab-count">{pendingRows.length}</span>
                </button>
                <button
                    type="button"
                    className={activeTab === "reviewed" ? "approvals-tab active" : "approvals-tab"}
                    onClick={() => setActiveTab("reviewed")}
                >
                    Reviewed <span className="tab-count">{reviewedRows.length}</span>
                </button>
            </div>

            <div className="approvals-toolbar">
                <div className="search-input-wrap">
                    <svg className="search-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                        <circle cx="11" cy="11" r="6.5" stroke="currentColor" strokeWidth="2" />
                        <line x1="16" y1="16" x2="21" y2="21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                    </svg>
                    <input
                        type="text"
                        placeholder="Search by file name or type…"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                    {search ? (
                        <button type="button" className="search-clear-btn" onClick={() => setSearch("")} aria-label="Clear search">
                            &times;
                        </button>
                    ) : null}
                </div>
                <select className="filter-select" value={levelFilter} onChange={(e) => setLevelFilter(e.target.value)}>
                    {LEVEL_OPTIONS.map((o) => (
                        <option key={o.value} value={o.value}>{o.label}</option>
                    ))}
                </select>
                <div className="confidence-input-wrap">
                    <input
                        type="number"
                        min="0"
                        max="100"
                        placeholder="Min confidence"
                        value={minConfidence}
                        onChange={(e) => setMinConfidence(e.target.value)}
                    />
                    <span className="confidence-suffix">%</span>
                </div>
                <button type="button" className="secondary-btn export-btn" onClick={handleExport}>
                    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true" className="export-icon">
                        <path d="M12 3v12m0 0-4-4m4 4 4-4M5 21h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    Export CSV
                </button>
            </div>

            <div className="table-card">
                <table className="approvals-table">
                    <thead>
                    <tr>
                        <th>Record ID</th>
                        <th>File</th>
                        <th>Type</th>
                        <th>AI Confidentiality</th>
                        <th>Confidence</th>
                        <th>Submitted</th>
                        <th>Status</th>
                        <th>Mark for review</th>
                    </tr>
                    </thead>
                    <tbody>
                    {filteredRows.map((row) => (
                        <tr key={row.id} className="clickable-row" onClick={() => navigate(`/approvals/${row.id}`)}>
                            <td>{row.id}</td>
                            <td>{row.fileName}</td>
                            <td>{row.fileType}</td>
                            <td>{row.classificationLevel}</td>
                            <td>{Math.round((row.confidenceScore || 0) * 100)}%</td>
                            <td>{new Date(row.submittedAt).toLocaleString()}</td>
                            <td>
                                {row.reviewed ? (
                                    <span className="status-pill status-reviewed">Reviewed</span>
                                ) : (
                                    <span className="status-pill status-pending">Awaiting Approval</span>
                                )}
                            </td>
                            <td>
                                <button
                                    type="button"
                                    className={row.flaggedForReview ? "flag-icon-btn active" : "flag-icon-btn"}
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        toggleFlag(row.id);
                                    }}
                                >
                                    ⚑
                                </button>
                            </td>
                        </tr>
                    ))}
                    {filteredRows.length === 0 ? (
                        <tr>
                            <td colSpan={8} className="muted" style={{ padding: "16px", textAlign: "center" }}>
                                {activeTab === "reviewed"
                                    ? "No reviewed records match the current filters."
                                    : "No records awaiting approval match the current filters."}
                            </td>
                        </tr>
                    ) : null}
                    </tbody>
                </table>
            </div>
        </section>
    );
}