// src/frontend/webui/src/pages/ApprovalDetailPage.jsx
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { splitIntoParagraphs } from "../utils/formatReasoning";

// Must match the ClassificationLevel enum in prisma/schema.prisma.
const options = [
    { value: "PUBLIC", label: "Public" },
    { value: "INTERNAL", label: "Internal" },
    { value: "CONFIDENTIAL", label: "Confidential" },
    { value: "HIGHLY_CONFIDENTIAL", label: "Highly Confidential" },
];

const ACTION_LABELS = {
    APPROVE: "Approved",
    OVERRIDE: "Overridden",
    COMMENT: "Commented / flagged for review",
};

function levelSlug(level) {
    return String(level || "").trim().toLowerCase().replace(/[_\s]+/g, "-");
}

export default function ApprovalDetailPage() {
    const navigate = useNavigate();
    const { id } = useParams();
    const [record, setRecord] = useState(null);
    const [error, setError] = useState("");
    const [decision, setDecision] = useState(null); // "accept" | "override" | "comment"
    const [overrideConfidentiality, setOverrideConfidentiality] = useState("");
    const [commentText, setCommentText] = useState("");
    const [actionError, setActionError] = useState("");
    const [successMessage, setSuccessMessage] = useState("");
    const [isSubmittingAction, setIsSubmittingAction] = useState(false);

    useEffect(() => {
        let cancelled = false;

        fetch(`/api/reviews/${id}`)
            .then((response) => response.json().then((data) => ({ ok: response.ok, data })))
            .then(({ ok, data }) => {
                if (cancelled) return;
                if (!ok) {
                    setError(data.error || "Could not load this review.");
                    return;
                }
                setRecord(data.review);
            })
            .catch((err) => {
                if (!cancelled) setError(err.message);
            });

        return () => {
            cancelled = true;
        };
    }, [id]);

    async function submitDecision(action, newLevel, comment) {
        setIsSubmittingAction(true);
        setActionError("");
        setSuccessMessage("");
        try {
            const response = await fetch(`/api/reviews/${id}/decision`, {
                method: "POST",
                headers: { "Content-type": "application/json" },
                body: JSON.stringify({ action, newLevel, comment }),
            });
            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.error || "Failed to record decision.");
            }
            setRecord(data.review);
            setDecision(null);
            setCommentText("");
            setSuccessMessage(
                action === "APPROVE"
                    ? "✅ Approved — recorded to the database."
                    : action === "OVERRIDE"
                        ? `✅ Override recorded — confidentiality set to ${newLevel}.`
                        : "✅ Comment saved and flagged for further review."
            );
        } catch (err) {
            setActionError(err.message);
        } finally {
            setIsSubmittingAction(false);
        }
    }

    if (error) {
        return (
            <section>
                <button className="back-btn" onClick={() => navigate("/approvals")}>← Back</button>
                <p className="upload-error">{error}</p>
            </section>
        );
    }

    if (!record) {
        return (
            <section>
                <button className="back-btn" onClick={() => navigate("/approvals")}>← Back</button>
                <p>Loading…</p>
            </section>
        );
    }

    function handleAccept() {
        setDecision("accept");
        submitDecision("APPROVE");
    }

    function handleOverride() {
        setDecision("override");
    }

    function handleFlagForReview() {
        setDecision("comment");
    }

    function confirmOverride() {
        if (!overrideConfidentiality) return;
        submitDecision("OVERRIDE", overrideConfidentiality);
    }

    function confirmComment() {
        if (!commentText.trim()) return;
        submitDecision("COMMENT", undefined, commentText.trim());
    }

    return (
        <section className="approval-detail-page page-enter">
            <button className="back-btn" onClick={() => navigate("/approvals")}>← Back to Approvals</button>

            {record.reviewed ? (
                <p className="reviewed-banner">✔ This asset already has {record.reviewHistory.length} review action{record.reviewHistory.length > 1 ? "s" : ""} recorded.</p>
            ) : null}

            <div className="approval-detail-grid">
                <article className="file-pane">
                    <h3>Original File</h3>
                    <div className="file-preview-header">
                        <p className="file-preview-name">{record.fileName}</p>
                        <div className="file-preview-meta">
                            {record.fileType ? <span className="file-type-badge">{record.fileType}</span> : null}
                            {record.sourceMetadata?.rowCount != null ? (
                                <span className="muted">{record.sourceMetadata.rowCount} rows</span>
                            ) : null}
                            {record.sourceMetadata?.columnCount != null ? (
                                <span className="muted">{record.sourceMetadata.columnCount} columns</span>
                            ) : null}
                        </div>
                    </div>
                    {record.fileContent ? (
                        <pre className="file-preview-content">{record.fileContent}</pre>
                    ) : (
                        <div className="file-preview-empty">
                            <p className="muted">No preview available for this file.</p>
                        </div>
                    )}

                    <h3>Evidence &amp; Guidance</h3>
                    {Array.isArray(record.evidence) && record.evidence.length > 0 ? (
                        <ul className="evidence-list">
                            {record.evidence.map((item, index) => {
                                if (typeof item === "string") {
                                    return (
                                        <li key={index} className="evidence-item">
                                            <p className="evidence-signal">{item}</p>
                                        </li>
                                    );
                                }
                                const signal = item.signal || item.description || "Evidence";
                                const level = item.supports_level;
                                return (
                                    <li key={index} className="evidence-item">
                                        <div className="evidence-item-head">
                                            <span className="evidence-signal">{signal}</span>
                                            {level ? (
                                                <span className={`level-pill level-${levelSlug(level)}`}>{level}</span>
                                            ) : null}
                                        </div>
                                        {item.location ? (
                                            <p className="evidence-location">
                                                <span className="evidence-meta-label">Location</span> {item.location}
                                            </p>
                                        ) : null}
                                        {item.redacted_excerpt ? (
                                            <p className="evidence-excerpt">&ldquo;{item.redacted_excerpt}&rdquo;</p>
                                        ) : null}
                                    </li>
                                );
                            })}
                        </ul>
                    ) : (
                        <p className="muted">No evidence was recorded for this classification.</p>
                    )}

                    {record.referencedGuidance ? (
                        <>
                            <h4>Referenced Guidance</h4>
                            {Array.isArray(record.referencedGuidance) && record.referencedGuidance.length > 0 ? (
                                <ul className="guidance-list">
                                    {record.referencedGuidance.map((rule, index) => {
                                        if (typeof rule === "string") {
                                            return (
                                                <li key={index} className="guidance-item">
                                                    <p className="guidance-application">{rule}</p>
                                                </li>
                                            );
                                        }
                                        return (
                                            <li key={index} className="guidance-item">
                                                {rule.rule_id ? (
                                                    <span className="guidance-rule-id">{rule.rule_id}</span>
                                                ) : null}
                                                <p className="guidance-application">
                                                    {rule.application || JSON.stringify(rule)}
                                                </p>
                                            </li>
                                        );
                                    })}
                                </ul>
                            ) : !Array.isArray(record.referencedGuidance) ? (
                                <p className="referenced-guidance">
                                    {typeof record.referencedGuidance === "string"
                                        ? record.referencedGuidance
                                        : JSON.stringify(record.referencedGuidance)}
                                </p>
                            ) : null}
                        </>
                    ) : null}
                </article>

                <article className="info-pane">
                    <h3>AI Judgement</h3>
                    <div className="ai-judgement-summary">
                        <span className={`level-pill level-${levelSlug(record.classificationLevel)}`}>
                            {record.classificationLevel}
                        </span>
                        <span className="confidence-chip">
                            {Math.round((record.confidenceScore || 0) * 100)}% confidence
                        </span>
                    </div>

                    <h4 className="reasoning-heading">Reasoning</h4>
                    <div className="reasoning-card">
                        {splitIntoParagraphs(record.explanation).map((paragraph, index) => (
                            <p key={index}>{paragraph}</p>
                        ))}
                    </div>

                    {successMessage ? <p className="action-success">{successMessage}</p> : null}
                    {actionError ? <p className="upload-error">{actionError}</p> : null}

                    {!record.reviewed && decision === null ? (
                        <div className="decision-actions">
                            <button type="button" className="primary-btn" onClick={handleAccept} disabled={isSubmittingAction}>
                                Accept AI Confidentiality
                            </button>
                            <button type="button" className="secondary-btn" onClick={handleOverride} disabled={isSubmittingAction}>
                                Override
                            </button>
                            <button type="button" className="secondary-btn" onClick={handleFlagForReview} disabled={isSubmittingAction}>
                                Add Comment / Flag
                            </button>
                        </div>
                    ) : null}

                    {!record.reviewed && decision === "override" ? (
                        <div className="override-panel">
                            <label htmlFor="overrideLevel"><strong>Set confidentiality:</strong></label>
                            <select
                                id="overrideLevel"
                                value={overrideConfidentiality}
                                onChange={(e) => setOverrideConfidentiality(e.target.value)}
                            >
                                <option value="">Select level</option>
                                {options.map((o) => (
                                    <option key={o.value} value={o.value}>{o.label}</option>
                                ))}
                            </select>
                            <div className="decision-actions">
                                <button
                                    type="button"
                                    className="primary-btn"
                                    onClick={confirmOverride}
                                    disabled={!overrideConfidentiality || isSubmittingAction}
                                >
                                    Confirm Override
                                </button>
                                <button
                                    type="button"
                                    className="secondary-btn"
                                    onClick={() => setDecision(null)}
                                    disabled={isSubmittingAction}
                                >
                                    Cancel
                                </button>
                            </div>
                        </div>
                    ) : null}

                    {!record.reviewed && decision === "comment" ? (
                        <div className="override-panel">
                            <label htmlFor="reviewComment"><strong>Comment / reason for flagging:</strong></label>
                            <textarea
                                id="reviewComment"
                                className="notes-textarea"
                                style={{ minHeight: "80px", maxHeight: "80px" }}
                                value={commentText}
                                onChange={(e) => setCommentText(e.target.value)}
                                placeholder="e.g. needs a second opinion from Legal"
                            />
                            <div className="decision-actions">
                                <button
                                    type="button"
                                    className="primary-btn"
                                    onClick={confirmComment}
                                    disabled={!commentText.trim() || isSubmittingAction}
                                >
                                    Save Comment
                                </button>
                                <button
                                    type="button"
                                    className="secondary-btn"
                                    onClick={() => setDecision(null)}
                                    disabled={isSubmittingAction}
                                >
                                    Cancel
                                </button>
                            </div>
                        </div>
                    ) : null}

                    {record.reviewHistory && record.reviewHistory.length > 0 ? (
                        <div className="review-history">
                            <h4>Review History</h4>
                            <ul>
                                {record.reviewHistory.map((entry) => (
                                    <li key={entry.id}>
                                        <strong>{ACTION_LABELS[entry.action] || entry.action}</strong>
                                        {entry.newLevel ? ` → ${entry.newLevel}` : ""}
                                        {entry.comment ? <em> — "{entry.comment}"</em> : null}
                                        <span className="muted"> ({new Date(entry.actedAt).toLocaleString()})</span>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    ) : null}
                </article>
            </div>
        </section>
    );
}