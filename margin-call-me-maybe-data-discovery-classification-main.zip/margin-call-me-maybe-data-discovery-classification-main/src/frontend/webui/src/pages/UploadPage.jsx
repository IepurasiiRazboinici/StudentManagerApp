// src/frontend/webui/src/pages/UploadPage.jsx
import { useEffect, useRef, useState } from "react";
import FileDropzone from "../components/FileDropzone";
import { splitIntoParagraphs } from "../utils/formatReasoning";

const POLL_INTERVAL_MS = 2000;
const TOAST_DURATION_MS = 7000;

export default function UploadPage() {
    const [files, setFiles] = useState([]);
    const [noteFiles, setNoteFiles] = useState([]);
    const [notesText, setNotesText] = useState("");
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [jobs, setJobs] = useState([]); // accumulates across every batch submitted this session
    const [submitError, setSubmitError] = useState("");
    const [confirmation, setConfirmation] = useState(null);
    const [toasts, setToasts] = useState([]); // one per file, fired when the AI finishes with it

    // Tracks active poll timers so they can be cleared on unmount, keyed by submission id.
    const pollTimers = useRef({});
    const confirmationTimer = useRef(null);
    const toastTimers = useRef({});

    useEffect(() => {
        return () => {
            Object.values(pollTimers.current).forEach(clearTimeout);
            Object.values(toastTimers.current).forEach(clearTimeout);
            if (confirmationTimer.current) clearTimeout(confirmationTimer.current);
        };
    }, []);

    function updateJob(id, patch) {
        setJobs((prev) => prev.map((job) => (job.id === id ? { ...job, ...patch } : job)));
    }

    function pushToast(message, tone = "info") {
        const toastId = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
        setToasts((prev) => [...prev, { id: toastId, message, tone }]);
        toastTimers.current[toastId] = setTimeout(() => {
            setToasts((prev) => prev.filter((toast) => toast.id !== toastId));
            delete toastTimers.current[toastId];
        }, TOAST_DURATION_MS);
    }

    function dismissToast(toastId) {
        setToasts((prev) => prev.filter((toast) => toast.id !== toastId));
        if (toastTimers.current[toastId]) {
            clearTimeout(toastTimers.current[toastId]);
            delete toastTimers.current[toastId];
        }
    }

    function pollSubmission(id) {
        fetch(`/api/submissions/${id}`)
            .then((response) => response.json())
            .then(({ submission }) => {
                if (!submission) return;

                if (submission.status === "CLASSIFIED" && submission.classification) {
                    updateJob(id, {
                        status: "CLASSIFIED",
                        classificationLevel: submission.classification.classificationLevel,
                        confidenceScore: submission.classification.confidenceScore,
                        explanation: submission.classification.explanation,
                    });
                    const confidencePct = Math.round((submission.classification.confidenceScore || 0) * 100);
                    pushToast(
                        `AI finished "${submission.fileName}" - classified as ${submission.classification.classificationLevel} (${confidencePct}% confidence).`,
                        "success"
                    );
                    return;
                }

                if (submission.status === "FAILED") {
                    updateJob(id, { status: "FAILED", error: "Classification failed for this file." });
                    pushToast(`AI classification failed for "${submission.fileName}".`, "error");
                    return;
                }

                // Still PENDING/PROCESSING - check again shortly.
                pollTimers.current[id] = setTimeout(() => pollSubmission(id), POLL_INTERVAL_MS);
            })
            .catch(() => {
                pollTimers.current[id] = setTimeout(() => pollSubmission(id), POLL_INTERVAL_MS);
            });
    }

    async function handleSubmit() {
        if (files.length === 0 || isSubmitting) return;

        setIsSubmitting(true);
        setSubmitError("");

        // Snapshot + clear the form immediately so the user can start
        // queuing up the next batch of files right away.
        const submittedFiles = files;
        const submittedNoteFiles = noteFiles;
        const submittedNotesText = notesText;
        setFiles([]);
        setNoteFiles([]);
        setNotesText("");

        try {
            const formData = new FormData();
            submittedFiles.forEach((file) => formData.append("files", file));
            submittedNoteFiles.forEach((file) => formData.append("noteFiles", file));
            formData.append("notesText", submittedNotesText);

            const response = await fetch("/api/classify", { method: "POST", body: formData });
            const payload = await response.json();

            if (!response.ok) {
                throw new Error(payload.error || "Classification request failed.");
            }

            // New batch goes to the top; each file starts out PROCESSING
            // and gets polled independently until it's classified/failed.
            setJobs((prev) => [...payload.results, ...prev]);
            payload.results.forEach((result) => {
                if (result.id) pollSubmission(result.id);
            });

            // Explicit confirmation that the upload was received - separate
            // from the per-file processing status below, so it's obvious
            // right away that the submission actually went through.
            const count = payload.results.length;
            setConfirmation(
                `${count} file${count > 1 ? "s" : ""} submitted successfully - now being classified in the background.`
            );
            if (confirmationTimer.current) clearTimeout(confirmationTimer.current);
            confirmationTimer.current = setTimeout(() => setConfirmation(null), 6000);
        } catch (error) {
            setSubmitError(error.message);
        } finally {
            setIsSubmitting(false);
        }
    }

    return (
        <section className="upload-page page-enter">
            {toasts.length > 0 ? (
                <div className="toast-stack" role="status" aria-live="polite">
                    {toasts.map((toast) => (
                        <div key={toast.id} className={`toast toast-${toast.tone}`}>
                            <span className="toast-icon" aria-hidden="true">
                                {toast.tone === "success" ? "\u2713" : toast.tone === "error" ? "!" : "\u2139"}
                            </span>
                            <span className="toast-message">{toast.message}</span>
                            <button
                                type="button"
                                className="toast-dismiss"
                                onClick={() => dismissToast(toast.id)}
                                aria-label="Dismiss notification"
                            >
                                &times;
                            </button>
                        </div>
                    ))}
                </div>
            ) : null}

            <h2>Upload Inbox</h2>
            <p className="upload-subtitle">
                Drop files, optionally drop note files, and/or type notes below. Files are
                classified in the background - you can keep uploading while earlier files finish.
            </p>

            {submitError ? <p className="upload-error">{submitError}</p> : null}
            {confirmation ? (
                <p className="upload-confirmation">
                    <span className="confirmation-check" aria-hidden="true">&#10003;</span> {confirmation}
                    <button type="button" className="dismiss-btn" onClick={() => setConfirmation(null)} aria-label="Dismiss">
                        &times;
                    </button>
                </p>
            ) : null}

            {jobs.length > 0 ? (
                <div className="results-panel">
                    <h3>Classification Results</h3>
                    <ul className="results-list">
                        {jobs.map((job) => (
                            <li key={job.id || job.fileName} className="result-item">
                                <strong>{job.fileName}</strong>
                                {job.status === "CLASSIFIED" ? (
                                    <>
                                        {" "}
                                        — <span className="result-level">{job.classificationLevel}</span>{" "}
                                        ({Math.round((job.confidenceScore || 0) * 100)}% confidence)
                                        <div className="reasoning-card">
                                            {splitIntoParagraphs(job.explanation).map((paragraph, index) => (
                                                <p key={index}>{paragraph}</p>
                                            ))}
                                        </div>
                                    </>
                                ) : job.status === "FAILED" ? (
                                    <span className="result-failed"> — Failed: {job.error}</span>
                                ) : (
                                    <span className="result-pending">
                                        {" "}
                                        <span className="mini-spinner" /> Processing…
                                    </span>
                                )}
                            </li>
                        ))}
                    </ul>
                </div>
            ) : null}

            {files.length > 0 ? (
                <div className="submit-panel">
                    <p className="submit-summary">
                        Ready to submit {files.length} file{files.length > 1 ? "s" : ""}
                        {noteFiles.length > 0 || notesText.trim()
                            ? " with notes."
                            : "."}
                    </p>
                    <button type="button" className="submit-btn" onClick={handleSubmit} disabled={isSubmitting}>
                        {isSubmitting ? "Submitting…" : "Submit for Classification"}
                    </button>
                </div>
            ) : null}


            <div className="upload-grid">
                <FileDropzone
                    title="Files"
                    hint="Drop one or more files"
                    files={files}
                    onFilesChange={setFiles}
                />

                <section className="notes-panel">
                    <FileDropzone
                        title="Notes files (optional)"
                        hint="Drop supporting note files"
                        files={noteFiles}
                        onFilesChange={setNoteFiles}
                        accept=".txt,.md,.doc,.docx,.pdf"
                    />

                    <h3 className="dropzone-title" style={{ marginTop: "14px" }}>
                        Notes text (optional)
                    </h3>
                    <textarea
                        className="notes-textarea"
                        value={notesText}
                        onChange={(e) => setNotesText(e.target.value)}
                        placeholder="Type notes here..."
                        rows={8}
                    />
                </section>
            </div>
        </section>
    );
}
