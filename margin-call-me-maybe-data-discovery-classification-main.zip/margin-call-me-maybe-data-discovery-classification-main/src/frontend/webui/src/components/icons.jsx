// src/frontend/webui/src/components/icons.jsx
//
// Small, hand-drawn, single-color line icon set (no external icon library -
// webui's node_modules isn't installed, so this avoids adding a dependency).
// Every icon shares the same 24x24 viewBox / stroke conventions so they drop
// in wherever an emoji used to be, but read as clean/technical rather than
// cartoonish. Color comes from `currentColor`, so they inherit theme color.
const BASE_PROPS = {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.7,
    strokeLinecap: "round",
    strokeLinejoin: "round",
};

export function IconUpload(props) {
    return (
        <svg {...BASE_PROPS} {...props}>
            <path d="M12 15V4" />
            <path d="M7.5 8.5 12 4l4.5 4.5" />
            <path d="M4.5 14.5v3a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2v-3" />
        </svg>
    );
}

export function IconSearch(props) {
    return (
        <svg {...BASE_PROPS} {...props}>
            <circle cx="10.5" cy="10.5" r="6.5" />
            <path d="m20 20-4.35-4.35" />
        </svg>
    );
}

export function IconSpark(props) {
    return (
        <svg {...BASE_PROPS} {...props}>
            <path d="M12 3v4M12 17v4M3 12h4M17 12h4" />
            <path d="M7 7 9.5 9.5M14.5 14.5 17 17M17 7l-2.5 2.5M9.5 14.5 7 17" />
            <circle cx="12" cy="12" r="2.3" />
        </svg>
    );
}

export function IconDatabase(props) {
    return (
        <svg {...BASE_PROPS} {...props}>
            <ellipse cx="12" cy="5.5" rx="7" ry="2.5" />
            <path d="M5 5.5V12c0 1.38 3.13 2.5 7 2.5s7-1.12 7-2.5V5.5" />
            <path d="M5 12v6.5c0 1.38 3.13 2.5 7 2.5s7-1.12 7-2.5V12" />
        </svg>
    );
}

export function IconCheckCircle(props) {
    return (
        <svg {...BASE_PROPS} {...props}>
            <circle cx="12" cy="12" r="8.5" />
            <path d="m8.3 12.3 2.6 2.6 5-5.2" />
        </svg>
    );
}

export function IconChartBar(props) {
    return (
        <svg {...BASE_PROPS} {...props}>
            <path d="M4 20V10" />
            <path d="M12 20V4" />
            <path d="M20 20v-7" />
            <path d="M3 20h18" />
        </svg>
    );
}

export function IconBolt(props) {
    return (
        <svg {...BASE_PROPS} {...props}>
            <path d="M12.5 3 5 13.2h5.2L11 21l7.5-10.2h-5.2Z" />
        </svg>
    );
}

export function IconLayers(props) {
    return (
        <svg {...BASE_PROPS} {...props}>
            <path d="m12 3.5 8 4.3-8 4.3-8-4.3Z" />
            <path d="m4 12.3 8 4.3 8-4.3" />
            <path d="m4 16.3 8 4.3 8-4.3" />
        </svg>
    );
}

export function IconLock(props) {
    return (
        <svg {...BASE_PROPS} {...props}>
            <rect x="5" y="11" width="14" height="9.5" rx="2" />
            <path d="M8 11V7.5a4 4 0 0 1 8 0V11" />
        </svg>
    );
}

export function IconUserCheck(props) {
    return (
        <svg {...BASE_PROPS} {...props}>
            <circle cx="9.5" cy="8" r="3.3" />
            <path d="M3.5 20c0-3.6 2.7-6 6-6s6 2.4 6 6" />
            <path d="m15.5 13.5 2 2 3.5-4" />
        </svg>
    );
}

export function IconMonitor(props) {
    return (
        <svg {...BASE_PROPS} {...props}>
            <rect x="3" y="4.5" width="18" height="12" rx="1.6" />
            <path d="M9 20h6M12 16.5V20" />
        </svg>
    );
}

export function IconServer(props) {
    return (
        <svg {...BASE_PROPS} {...props}>
            <rect x="3.5" y="4" width="17" height="6.5" rx="1.4" />
            <rect x="3.5" y="13" width="17" height="6.5" rx="1.4" />
            <path d="M7 7.25h.01M7 16.25h.01" />
        </svg>
    );
}

export function IconCpu(props) {
    return (
        <svg {...BASE_PROPS} {...props}>
            <rect x="7" y="7" width="10" height="10" rx="1.6" />
            <path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.6 5.6l2 2M16.4 16.4l2 2M5.6 18.4l2-2M16.4 7.6l2-2" />
        </svg>
    );
}
