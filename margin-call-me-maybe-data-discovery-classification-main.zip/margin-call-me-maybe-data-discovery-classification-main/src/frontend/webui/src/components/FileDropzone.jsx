// src/frontend/webui/src/components/FileDropzone.jsx
import { useRef, useState } from "react";

export default function FileDropzone({ title, hint, files, onFilesChange, accept }) {
    const [dragActive, setDragActive] = useState(false);
    const inputRef = useRef(null);

    function mergeFiles(incomingList) {
        if (!incomingList || incomingList.length === 0) return;

        const incomingFiles = Array.from(incomingList);
        const merged = [...files, ...incomingFiles];
        const deduped = merged.filter(
            (file, index, array) =>
                index ===
                array.findIndex(
                    (candidate) =>
                        candidate.name === file.name &&
                        candidate.size === file.size &&
                        candidate.lastModified === file.lastModified,
                ),
        );
        onFilesChange(deduped);
    }

    function removeFile(fileToRemove) {
        onFilesChange(
            files.filter(
                (file) =>
                    !(
                        file.name === fileToRemove.name &&
                        file.size === fileToRemove.size &&
                        file.lastModified === fileToRemove.lastModified
                    ),
            ),
        );
    }

    return (
        <section className="dropzone-wrap">
            <h3 className="dropzone-title">{title}</h3>
            <div
                className={dragActive ? "dropzone drag-active" : "dropzone"}
                onDragOver={(event) => {
                    event.preventDefault();
                    setDragActive(true);
                }}
                onDragLeave={() => setDragActive(false)}
                onDrop={(event) => {
                    event.preventDefault();
                    setDragActive(false);
                    mergeFiles(event.dataTransfer.files);
                }}
                onClick={() => inputRef.current && inputRef.current.click()}
            >
                <p>{hint}</p>
                <p className="dropzone-hint">Click to browse or drag and drop.</p>
            </div>

            <input
                ref={inputRef}
                type="file"
                multiple
                accept={accept}
                hidden
                onChange={(event) => mergeFiles(event.target.files)}
            />

            {files.length > 0 ? (
                <ul className="file-list">
                    {files.map((file, index) => (
                        <li key={`${file.name}-${file.size}-${index}`} className="file-list-item">
                            <span>{file.name}</span>
                            <button
                                type="button"
                                className="remove-file-btn"
                                onClick={() => removeFile(file)}
                                aria-label={`Remove ${file.name}`}
                            >
                                Remove
                            </button>
                        </li>
                    ))}
                </ul>
            ) : null}
        </section>
    );
}