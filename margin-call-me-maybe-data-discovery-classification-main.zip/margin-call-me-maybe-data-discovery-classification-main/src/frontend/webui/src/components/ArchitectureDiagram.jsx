// src/frontend/webui/src/components/ArchitectureDiagram.jsx
//
// "Technical" view for the About page's How-it-works section. Deliberately
// mirrors the structure of the business-mode stage-flow: a row of clickable
// pills - one per architectural layer - and a detail card below explaining
// what lives in that layer and how it connects to the others. No dense
// node-and-arrow canvas; just the same familiar pattern, one level deeper.
import { useState } from "react";
import LongPressHighlight from "./LongPressHighlight";
import { IconMonitor, IconServer, IconCpu, IconDatabase } from "./icons";

const LAYERS = [
    {
        id: "frontend",
        Icon: IconMonitor,
        title: "Frontend",
        blurb: "React pages people actually use",
        path: "src/frontend/webui",
        components: [
            { name: "UploadPage.jsx", text: "Batches file uploads and polls each submission until it's classified or failed." },
            { name: "ApprovalsPage.jsx", text: "Lists classified assets awaiting or already given a human decision, with search/filter/export." },
            { name: "ApprovalDetailPage.jsx", text: "Shows one asset's AI evidence and file preview, and records approve/override/comment decisions." },
            { name: "DashboardPage.jsx", text: "Polls aggregate stats every 5 seconds for live totals, distribution, and review status." },
        ],
        flow: [
            "Uploads files + notes \u2192 POST /api/classify",
            "Polls GET /api/submissions/:id \u2192 classification level, confidence, explanation",
            "Fetches/posts decisions \u2192 /api/reviews",
            "Polls GET /api/submissions/stats \u2192 live dashboard totals",
        ],
    },
    {
        id: "backend",
        Icon: IconServer,
        title: "Backend API",
        blurb: "Express routes that tie everything together",
        path: "src/backend/api",
        components: [
            { name: "POST /api/classify", text: "Profiles uploaded files, atomically claims each Submission row, then classifies the whole batch in one GenAI call." },
            { name: "/api/reviews", text: "GET list, GET one, POST decision - lean review projections plus APPROVE/OVERRIDE/COMMENT actions with optimistic locking." },
            { name: "/api/submissions", text: "GET /:id for per-submission polling, GET /stats for the dashboard's live aggregates." },
        ],
        flow: [
            "Calls the processing pipeline to profile and classify each file",
            "Reads and writes Submission, Classification, and ReviewAction rows",
        ],
    },
    {
        id: "pipeline",
        Icon: IconCpu,
        title: "Processing pipeline",
        blurb: "Called by classify.js to turn raw files into a verdict",
        path: "called from src/backend/api/routes/classify.js",
        components: [
            { name: "data-discovery.js", text: "Parses each file by type (CSV/TSV/JSON/text/SQLite/Postgres) into row/column counts and redacted samples." },
            { name: "genaiClient.js", text: "Sends one batched prompt covering every file to the GenAI Service Builder endpoint, backed by Claude Sonnet 4.6." },
            { name: "data-profiling.js", text: "Deeper pattern/entity analysis - built and tested, but only wired into the legacy CLI pipeline so far, not this live API.", muted: true },
        ],
        flow: [
            "classify.js \u2192 data-discovery.js: profile each file",
            "classify.js \u2192 genaiClient.js: batch classify",
            "genaiClient.js \u2192 classify.js: assets[] classification results",
        ],
    },
    {
        id: "database",
        Icon: IconDatabase,
        title: "Database",
        blurb: "Prisma models on PostgreSQL - the permanent record",
        path: "prisma/schema.prisma",
        components: [
            { name: "User", text: "The uploader/reviewer identity behind every Submission and ReviewAction." },
            { name: "Submission", text: "One row per uploaded file: content, profiling metadata, and PENDING/PROCESSING/CLASSIFIED/FAILED status." },
            { name: "Classification", text: "The AI's verdict for a Submission - level, confidence, evidence, and plain-language explanation." },
            { name: "ReviewAction", text: "An immutable record of a human decision (approve/override/comment) against a Classification." },
        ],
        flow: [
            "Submission 1 : 1 Classification",
            "Classification 1 : many ReviewAction",
            "User 1 : many Submission (uploadedBy)",
        ],
    },
];

export default function ArchitectureDiagram() {
    const [activeLayerId, setActiveLayerId] = useState(LAYERS[0].id);
    const activeLayer = LAYERS.find((layer) => layer.id === activeLayerId) || LAYERS[0];
    const ActiveIcon = activeLayer.Icon;

    return (
        <>
            <div className="stage-flow">
                {LAYERS.map((layer, index) => {
                    const Icon = layer.Icon;
                    return (
                        <div className="stage-flow-item" key={layer.id}>
                            <LongPressHighlight
                                as="button"
                                type="button"
                                className={layer.id === activeLayerId ? "stage-node active" : "stage-node"}
                                onClick={() => setActiveLayerId(layer.id)}
                            >
                                <span className="stage-node-icon">
                                    <Icon />
                                </span>
                                <span className="stage-node-title">{layer.title}</span>
                            </LongPressHighlight>
                            {index < LAYERS.length - 1 ? (
                                <span className="stage-arrow" aria-hidden="true">&rsaquo;</span>
                            ) : null}
                        </div>
                    );
                })}
            </div>

            <LongPressHighlight as="div" className="stage-detail-card arch-layer-card">
                <div className="stage-detail-head">
                    <span className="stage-detail-icon">
                        <ActiveIcon />
                    </span>
                    <div>
                        <h4>{activeLayer.title}</h4>
                        <p className="muted">{activeLayer.blurb}</p>
                    </div>
                </div>
                <p className="arch-layer-path">{activeLayer.path}</p>

                <div className="arch-layer-section">
                    <h5>What's in this layer</h5>
                    <ul className="arch-layer-components">
                        {activeLayer.components.map((component) => (
                            <li key={component.name} className={component.muted ? "muted-item" : undefined}>
                                <span className="arch-layer-component-name">{component.name}</span>
                                <span className="arch-layer-component-text">{component.text}</span>
                            </li>
                        ))}
                    </ul>
                </div>

                <div className="arch-layer-section">
                    <h5>How it connects</h5>
                    <ul className="arch-layer-flow">
                        {activeLayer.flow.map((line) => (
                            <li key={line}>{line}</li>
                        ))}
                    </ul>
                </div>
            </LongPressHighlight>
        </>
    );
}

