export default function AppHeader() {
    return (
        <header className="app-header">
            <div className="brand">
                <span className="brand-mark" aria-hidden="true">
                    <svg viewBox="0 0 48 48" width="34" height="34" fill="none">
                        <defs>
                            <linearGradient id="brandGradient" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
                                <stop offset="0" stopColor="#ADDEDC" />
                                <stop offset="0.55" stopColor="#5CCADE" />
                                <stop offset="1" stopColor="#029BE3" />
                            </linearGradient>
                        </defs>
                        <circle cx="21" cy="21" r="15" stroke="url(#brandGradient)" strokeWidth="5" />
                        <line x1="31.5" y1="31.5" x2="43" y2="43" stroke="url(#brandGradient)" strokeWidth="5.5" strokeLinecap="round" />
                        <path d="M14.5 21a6.5 6.5 0 0 1 6.5-6.5" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" opacity="0.85" />
                    </svg>
                </span>
                <div className="brand-text">
                    <h1 className="app-title">
                        Classif<span className="app-title-ai">AI</span>
                    </h1>
                    <span className="app-subtitle">Data Discovery &amp; Classification</span>
                </div>
            </div>
            <img src="/lseg-logo.png" alt="LSEG" className="app-logo" />
        </header>
    );
}
