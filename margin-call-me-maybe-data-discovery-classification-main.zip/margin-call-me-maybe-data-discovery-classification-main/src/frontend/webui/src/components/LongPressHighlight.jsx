// src/frontend/webui/src/components/LongPressHighlight.jsx
//
// Wraps a block of UI so that pressing and holding it (mouse or touch) for
// a beat calls out that specific box with a glowing highlight - handy when
// walking someone through the About page section by section. A quick
// click/tap still behaves completely normally (onClick etc. pass through
// unaffected); the highlight only appears once the press has been held
// past HOLD_MS, and fades on its own after FADE_MS.
import { forwardRef, useEffect, useRef, useState } from "react";

const HOLD_MS = 450;
const FADE_MS = 2200;

const LongPressHighlight = forwardRef(function LongPressHighlight(
    { as: Tag = "div", className = "", children, ...rest },
    forwardedRef
) {
    const [highlighted, setHighlighted] = useState(false);
    const holdTimer = useRef(null);
    const fadeTimer = useRef(null);

    function clearTimers() {
        if (holdTimer.current) {
            clearTimeout(holdTimer.current);
            holdTimer.current = null;
        }
        if (fadeTimer.current) {
            clearTimeout(fadeTimer.current);
            fadeTimer.current = null;
        }
    }

    function startPress() {
        clearTimers();
        holdTimer.current = setTimeout(() => {
            setHighlighted(true);
            fadeTimer.current = setTimeout(() => setHighlighted(false), FADE_MS);
        }, HOLD_MS);
    }

    function cancelPress() {
        if (holdTimer.current) {
            clearTimeout(holdTimer.current);
            holdTimer.current = null;
        }
    }

    useEffect(() => () => clearTimers(), []);

    const combinedClassName = highlighted ? `${className} long-highlight` : className;

    return (
        <Tag
            ref={forwardedRef}
            className={combinedClassName}
            onPointerDown={startPress}
            onPointerUp={cancelPress}
            onPointerLeave={cancelPress}
            onPointerCancel={cancelPress}
            {...rest}
        >
            {children}
        </Tag>
    );
});

export default LongPressHighlight;

