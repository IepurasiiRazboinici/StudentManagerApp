// src/frontend/webui/src/utils/formatReasoning.js
//
// The AI's explanation comes back as a single string. This turns it into
// readable paragraphs instead of one dense wall of text: splits on existing
// newlines if the model provided any, otherwise groups sentences two at a
// time so long explanations still read like prose rather than a text dump.
export function splitIntoParagraphs(text) {
    if (!text) return [];

    const byNewline = text
        .split(/\n+/)
        .map((chunk) => chunk.trim())
        .filter(Boolean);
    if (byNewline.length > 1) return byNewline;

    const sentences = (text.match(/[^.!?]+[.!?]+(?:\s+|$)/g) || [text])
        .map((sentence) => sentence.trim())
        .filter(Boolean);

    if (sentences.length <= 2) return [text.trim()];

    const paragraphs = [];
    for (let i = 0; i < sentences.length; i += 2) {
        paragraphs.push(sentences.slice(i, i + 2).join(" "));
    }
    return paragraphs;
}
