// src/webui/src/state/JudgementsContext.jsx
import { createContext, useContext, useMemo, useState } from "react";

const Ctx = createContext(null);

const seed = [
    { id: "AJ-1001", fileName: "invoice-q2.pdf", aiConfidentiality: "Internal", confidence: "94%", reasoning: "I am AI and I am so smart and you should listen to me" },
    { id: "AJ-1002", fileName: "nda-client-a.docx", aiConfidentiality: "Confidential", confidence: "88%", reasoning: "Hi queen" },
];

export function JudgementsProvider({ children }) {
    const [pending, setPending] = useState(seed);
    const [finalClassifications, setFinalClassifications] = useState([]);

    function accept(id) {
        setPending((prev) => {
            const rec = prev.find((r) => r.id === id);
            if (!rec) return prev;
            setFinalClassifications((f) => [
                ...f,
                { ...rec, finalConfidentiality: rec.aiConfidentiality, decision: "accepted" },
            ]);
            return prev.filter((r) => r.id !== id);
        });
    }

    function override(id, overrideValue) {
        setPending((prev) => {
            const rec = prev.find((r) => r.id === id);
            if (!rec) return prev;
            setFinalClassifications((f) => [
                ...f,
                { ...rec, finalConfidentiality: overrideValue, decision: "overridden" },
            ]);
            return prev.filter((r) => r.id !== id);
        });
    }

    const value = useMemo(
        () => ({ pending, finalClassifications, accept, override }),
        [pending, finalClassifications],
    );

    return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useJudgements() {
    return useContext(Ctx);
}