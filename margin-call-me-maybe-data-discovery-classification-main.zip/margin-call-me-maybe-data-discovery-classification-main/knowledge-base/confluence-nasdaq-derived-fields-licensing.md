# Publishing Nasdaq (".O") Data to Customers — What You Need to Know About Derived Fields

> **Space:** Market Data Governance
> **Status:** ✅ Approved
> **Owner:** Market Data Licensing Office
> **Last updated:** 20 July 2026
> **Labels:** market-data, licensing, nasdaq, redistribution

---

Hi all — a few people have asked recently whether it's fine to pass certain
Nasdaq fields straight through to customer feeds, so I wanted to write this
up properly instead of answering it one-off in Slack each time.

Short version: for anything listed on Nasdaq (RICs ending in **`.O`**, like
`AAPL.O`, `AMD.O`, `AMZN.O` or `ASML.O`), there are a **few calculated fields
we can't hand to customers** unless we've actually got a licensing agreement
in place that covers them. Everything else on those instruments is fine as
normal.

## Why this is a thing

The raw quote data (last trade, bid, ask, size, volume, etc.) is covered
under our standard market data agreements — no issue there. The problem is
the *derived* fields — things we (or our vendor) calculate off the back of
the raw data, like a theoretical price or a VWAP. Exchanges and vendors tend
to treat those as a separate product, and redistributing them without the
right paperwork is exactly the kind of thing that gets flagged in an audit.

So until we've confirmed the licensing for a given customer/feed, these
fields need to stay out of anything that leaves the building.

## The fields in question

| Field | What it is | FID |
|---|---|---|
| `VWAP` | Volume Weighted Average Price | `3404` |
| `THEO_PRC` | Theoretical Price | `3396` |
| `THEO_VOL` | Theoretical Volume | `4107` |

If you're not sure whether a field counts as "derived" vs "raw", these three
are the ones to watch for right now — this list may grow if Licensing flags
more later, so keep an eye on updates to this page.

To be clear, this **doesn't** affect the standard stuff — `BID` (`22`),
`ASK` (`25`), last price `TRDPRC_1` (`6`), volume `ACVOL_1` (`32`) and so on
are all still fine to publish for `.O` instruments as usual.

## What to actually do about it

If you're building or maintaining a customer-facing feed or export:

- Check whether it includes `VWAP`, `THEO_PRC`, or `THEO_VOL` for any `.O`
  instrument.
- If it does, either strip those fields out before it goes external, or
  check with the Licensing Office first to see if there's already an
  agreement covering that customer.
- If there's no agreement, don't publish those fields — blank them or drop
  them from the schema, whichever is easier for your pipeline.
- None of this applies internally — for research, dashboards, or anything
  that stays in-house, use whatever you need.

## Not sure? Ask first

If you're ever unsure whether something counts as "derived" or whether a
license is already in place, just reach out to the Market Data Licensing
Office before publishing rather than guessing. It's a quick check on our
end and saves everyone a headache later.

## Revision history

| Version | Date | Change |
|---|---|---|
| 1.0 | 20 July 2026 | First version of this page. |

