# Intelligent Data Discovery & Classification Hackathon

Build an AI-powered system that discovers datasets, profiles their content, interprets classification guidance, and assigns explainable sensitivity labels.

## Objective

Organizations store data across files, tables, and documents. Sensitivity is often unclear from names alone. Your solution should help users answer:

- What data exists?
- How sensitive is it?
- Why was it classified that way?
- What human review action is required before usage/sharing?

## Classification Levels

- **Public**: Safe to share openly.
- **Internal**: For internal business use.
- **Confidential**: Sensitive business/customer/financial/operational information.
- **Highly Confidential**: Highly sensitive information (e.g., credentials, regulated data, security-critical content).

## What You Need to Build

Your application must include the following capabilities.

### 1) Data discovery

- Ingest at least 2 source types.
- List discovered assets (files/tables/documents).
- Extract metadata (source name, schema/columns when applicable, sample records, row/document count).

### 2) Data profiling

- Detect common patterns and entities (emails, phones, names, account-like identifiers, financial values, free text, etc.).
- Produce a dataset profile summary.

### 3) Guidance interpretation

- Read one or more policy/guidance documents.
- Extract usable classification rules/examples.
- Apply guidance to classification decisions.

### 4) AI-based classification

For each dataset/document/table, return:

- Assigned classification level
- Confidence score
- Evidence (fields/snippets/signals)
- Referenced rule/guidance
- Plain-language explanation
- Review recommendation when confidence is low or evidence conflicts

### 5) Human review workflow

- Approve result
- Override result
- Add reviewer comments
- Mark for further review

### 6) Interactive UI

Include views for:

- Classification distribution dashboard
- Search/filter by class, confidence, source, or data type
- Asset detail and evidence inspection
- Human review actions
- Exportable report

## Allowed Data

- Use **synthetic**, **open**, or **team-created** sample data only.
- Do **not** use real personal, confidential, or proprietary data.

## Suggested Source Types

Pick at least two:

- CSV / TSV / JSON
- Markdown / text documents
- SQLite or PostgreSQL tables
- Mock wiki/knowledge-base pages

## Sample Scope (Recommended)

Use mixed-content synthetic assets such as:

- Public market/product reference data
- Internal project notes
- Customer-like fake records
- Financial report-like content
- API/security log-like content
- Contract/support-ticket-like text

## Deliverables

Submit:

- Working prototype/application
- Sample synthetic datasets for demo
- Sample classification policy/guidance document
- Short architecture overview
- Demo walkthrough
- Summary of AI approach
- Known limitations + next improvements

## Suggested Architecture (Reference)

- Source connectors
- Data profiler
- Policy interpreter
- Classification engine
- Evidence generator
- Review UI
- Report generator

## Example End-to-End Outcome

Given:

- A CSV with fake customer contact records
- A table with public product references
- A markdown policy document

Expected behavior:

- Discover all assets
- Profile fields/content
- Interpret policy statements
- Classify with explanation (e.g., Product data -> Public, Customer contacts -> Confidential)
- Allow reviewer approval/override/comments

## Sample Data & Guidance Docs in This Repo

This repo includes real sample assets you can use directly, or as inspiration for building your own. They're intentionally messy and mixed — that's the point of the exercise.

| File | What it is |
|---|---|
| `market-data-usa.log` | Raw market data feed log — one line per instrument update, values encoded as `FID=value` pairs. |
| `reuters.fids` | Field Identifier (FID) reference dictionary — explains what each numeric FID in the log actually means. |
| `trades.csv` / `trades_sample.csv` | Trade execution/allocation records (fund/account-style data, in CSV form). |
| `knowledge-base/trade-fields-notes.txt` | Informal engineering notes about what the `trades.csv` columns mean — incomplete and a bit vague on purpose. |
| `knowledge-base/confluence-nasdaq-derived-fields-licensing.md` | A wiki-style internal page about a data licensing restriction. |
| `financial-report-q3-2026-draft.md` | Draft, unpublished quarterly financial report (scheduled publish date in the future). |
| `financial-report-q2-2026-published.md` | The same kind of quarterly financial report, but already publicly released (publish date in the past). |

### Sample: `market-data-usa.log`

Each line is a log record containing an instrument identifier followed by a comma-separated list of `FID=value` pairs:

```text
INFO[16:54:04,773] - RecordService.MsgProcessor - DATALOG - IWM,32=5098295.0,6=286.93,1000=A,1009063=50044317,3404=285.290097,14=þ,3855=50044316,178=40.0,18=13:54:00,22=286.91,56=1.7302,25=286.92,14265=13:54:04:316:000,30=80.0,31=240.0
INFO[16:54:04,774] - RecordService.MsgProcessor - DATALOG - MGC,22=267.96,1000=A,25=268.12,14265=13:54:04:013:089,30=2200.0,31=2000.0,3855=50044013
```

To make sense of this you need both files together:

1. Extract the instrument identifier (`IWM`, `MGC`, ...) right after `DATALOG -`.
2. Split the rest on commas to get `FID=value` pairs (e.g. `22=286.91`).
3. Look up each numeric FID in `reuters.fids` to find its name and meaning (e.g. FID `22` → `BID`, FID `25` → `ASK`, FID `6` → `TRDPRC_1` / last trade price).
4. Some FIDs appear with an empty value (`3396=`) — that's normal; not every field is populated for every instrument/update.

### Sample: `trades.csv`

```text
execid,symbol,lastshares,lastpx,recdate,ownergroup,executionexchange,fundallocation,totalfundallocation,extrafields
AAAkuWoGJroAANHR,CS.NULL.JAPAN.T.JPY.KBOX,500.00000000,393.90000000,2026-05-15 13:07:03.022000,AURORA_CAP,XNYS,ACCT_001=500,ACCT_001=63400,"{""ExecAvgPx"":""395.9973"",""AggQty"":""63400.0"",""TxnDate"":""May 15, 2026"",""LiquidityFlag"":2}"
AAAm32nxLTEAAEHQ,CS.NULL.USA.US.USD.BNVMPS,50.00000000,154.25000000,2026-04-29 23:18:00.547000,NORTHBRIDGE,XNAS,Fund;ACCT_002=50(PB;ACCT_003=50),Fund;ACCT_002=247916(PB;ACCT_003=247916),"{""ExecAvgPx"":""153.885268"",""AggQty"":""247916.0"",""TxnDate"":""Apr 29, 2026"",""LiquidityFlag"":1}"
```

Things worth noticing while profiling this file:

- `symbol` is a dotted, multi-segment instrument code — not a plain ticker.
- `fundallocation` / `totalfundallocation` are **not** simple scalar values — they can contain one or more `CODE=qty` pairs, sometimes with a `Fund;X=..(PB;Y=..)` sub-structure.
- `extrafields` is a nested JSON blob with a variable set of keys row to row.
- See `knowledge-base/trade-fields-notes.txt` for (partial, informal) context on what these columns mean — don't treat it as an authoritative spec.

### How this data should be processed

- Treat `market-data-usa.log` and `reuters.fids` as a pair: the log is meaningless without the FID dictionary to decode it.
- Treat `trades.csv` as a nested/semi-structured CSV: don't assume every "value" column is a flat scalar — some are mini key=value or JSON structures that need their own parser.
- `knowledge-base/trade-fields-notes.txt` is informal tribal knowledge, not a schema — a good stand-in for the "unclear labels / mixed content" scenario described in the challenge.

### Sample: financial reports (time-based classification)

These two files are deliberately near-identical in structure and content —
same fictional company, same report format — but one is still a draft and
one has already been released. This is meant to show that **classification
can depend on metadata like a publish date, not just the content itself**.

`financial-report-q3-2026-draft.md`:

```text
> **Status:** 🔒 DRAFT — NOT YET PUBLISHED
> **Scheduled Publish Date:** 2026-08-10
> **Distribution:** Internal only — Board, Finance, Investor Relations (pre-release)
```

`financial-report-q2-2026-published.md`:

```text
> **Status:** ✅ Published
> **Published Date:** 2026-05-10
> **Distribution:** Public — released via investor relations website and press release
```

To classify these correctly, your system needs to reason about the
**publish date relative to "today"**, not just detect that a file "looks
like a financial report":

- If the scheduled/published date is in the **future** (or the status says
  "draft"/"embargoed"), the report should be classified as **Internal**
  (or **Confidential**, depending on how strict your policy is) — it must
  not leak before release.
- If the date is in the **past** and the status says "Published", the same
  kind of report becomes **Public** — it has already been officially
  released and may be freely shared.

## Classifying the Sample Data (Reference)

Since one of the goals of this hackathon is producing *explainable* classifications, here's how the sample data in this repo should actually be classified, and why:

| Source | Classification | Why |
|---|---|---|
| `market-data-usa.log` (raw quote/trade fields: `BID`, `ASK`, `TRDPRC_1`, size, volume, etc.) | **Internal** | The values themselves (prices, sizes) reflect public market activity, but this is an internal vendor feed dump, not an approved external publication — so treat the feed as Internal by default. |
| `market-data-usa.log` — specifically the `VWAP` (`3404`), `THEO_PRC` (`3396`), `THEO_VOL` (`4107`) fields for `.O`-suffixed instruments | **Confidential** | Per `knowledge-base/confluence-nasdaq-derived-fields-licensing.md`, these specific derived fields can't be published to customers without a licensing agreement — a good example of column-level classification within an otherwise Internal file. |
| `reuters.fids` | **Internal** | It's technical reference documentation (field name ↔ FID mapping) used to interpret the feed — not customer data, but also not something meant for public distribution. |
| `trades.csv` / `trades_sample.csv` | **Highly Confidential** | Structurally, this represents trade execution and fund/account allocation data — account-style identifiers, position sizes, and broker/prime-broker splits. This category of data is highly sensitive in a real environment (it can reveal trading positions and strategy), so it should be classified at the highest level even though the sample values here are synthetic/anonymized. |
| `knowledge-base/trade-fields-notes.txt` | **Internal** | Informal engineering notes about internal data — no customer/personal data present, but not meant for external audiences either. |
| `knowledge-base/confluence-nasdaq-derived-fields-licensing.md` | **Internal** | Internal policy/licensing guidance for staff — operational information, not customer-facing. |
| `financial-report-q3-2026-draft.md` | **Internal** | Unaudited financial results with a scheduled publish date (2026-08-10) that hasn't happened yet as of today (2026-07-20) — must stay internal until the official release. |
| `financial-report-q2-2026-published.md` | **Public** | Same type of quarterly report, but its publish date (2026-05-10) has already passed and its status is "Published" — it has been officially released, so it's safe to treat as Public. |

Use this table as a sanity check for your own classification engine's output on these same files — if your system disagrees, that's a good discussion point for your demo (was it missing evidence, guidance, or context?).

## Database Layer (PostgreSQL + Prisma)

The persistence layer lives in [prisma/schema.prisma](prisma/schema.prisma) (models) and [src/db/](src/db) (query functions). Setup:

```bash
npm install
cp .env.example .env        # then edit DATABASE_URL to point at your Postgres instance
npm run db:migrate          # creates the tables
npm run db:seed             # loads sample users + submissions for a demo
```

### Concurrency Strategy (plain English)

This is a hackathon project, so we picked a small number of **simple,
demonstrable** safeguards rather than a full production-grade job queue.
Each one maps to a specific "what could go wrong" scenario:

1. **Two workers grabbing the same submission ("job claiming").**
   Moving a submission from `PENDING` to `PROCESSING` is done with a single
   atomic SQL statement: `UPDATE ... WHERE status = 'PENDING' ... RETURNING *`,
   using `FOR UPDATE SKIP LOCKED` to pick the row. There's no
   "check if it's pending, then update it" gap for two workers to race
   through — the database itself guarantees only one caller can win.
   If a worker gets back zero rows, that means someone else already
   claimed it, so it just moves on. See `claimNextPendingSubmission()` in
   [src/db/submissions.js](src/db/submissions.js).

2. **The same submission getting classified twice.** A `UNIQUE` constraint
   on `Classification.submissionId` makes a duplicate impossible at the
   database level. Instead of writing `SELECT` (does one exist?) then
   `INSERT` (which has the same race problem as #1), we use Prisma's
   `upsert`, which Postgres executes as a single atomic operation. If a
   classification already exists, we simply do nothing and return the
   existing row instead of erroring out. See `createClassification()` in
   [src/db/classifications.js](src/db/classifications.js).

3. **Two reviewers acting on the same classification at once
   ("optimistic locking").** Every `Classification` has a `version`
   counter. When a reviewer overrides a classification, the update
   statement includes `WHERE id = ... AND version = <what the reviewer
   last saw>`. If someone else changed it in the meantime, the version
   won't match, zero rows are updated, and we throw a clear
   `OptimisticLockError` telling the caller to refresh and try again —
   instead of silently overwriting the other reviewer's decision. See
   `updateClassificationWithLock()` in
   [src/db/classifications.js](src/db/classifications.js).

4. **Partial writes on override.** Recording a reviewer's action and
   changing the classification's level are two separate writes, but they
   must succeed or fail together — otherwise you could end up with an
   audit log entry for an override that never actually took effect (or
   vice versa). Both writes happen inside one Prisma `$transaction`, so a
   failure in the optimistic lock check (#3) automatically rolls back the
   review action insert too. See `addReviewAction()` in
   [src/db/reviewActions.js](src/db/reviewActions.js).

### Known limitations / next steps

- No retry/backoff for a `FAILED` submission — a teammate would currently
  need to manually flip its status back to `PENDING` to retry it.
- `FOR UPDATE SKIP LOCKED` claiming works well for a handful of workers,
  but we haven't load-tested it at any real scale.
- Optimistic locking here only protects `Classification` updates — if this
  grew beyond a hackathon, the same pattern would need to be applied
  anywhere else concurrent edits are possible.
- There's no soft-delete/audit trail on `User` — role changes or removals
  just overwrite data.

## End-to-End Integration (API + UI + Discovery + GenAI + DB)

The webui, [src/data-discovery](src/data-discovery), [classify_with_genai.py](classify_with_genai.py)'s Node equivalent, and the Prisma db layer are wired together through a small Express API in [src/api](src/api):

```
webui (React, Vite)  --/api/classify-->  Express API  --runDataDiscovery-->  src/data-discovery
                                              |----------classifyBatch()-->  GenAI Service Builder
                                              |----------createSubmission/claimNextPendingSubmission/
                                              |          createClassification------------------->  Prisma db layer
```

### Running it locally

```bash
npm install
cp .env.example .env                # fill in DATABASE_URL and GENAI_SERVICE_API_KEY
npm run db:migrate && npm run db:seed
npm run api                         # starts the Express API on :3001
cd src/webui && npm install && npm run dev   # starts Vite on :5173, proxying /api to :3001
```

### What `POST /api/classify` does

1. Accepts a multipart upload (`files`, optional `noteFiles`, optional `notesText`) from [UploadPage.jsx](src/webui/src/pages/UploadPage.jsx).
2. Writes the uploaded files to a throwaway temp dir and runs `runDataDiscovery()` ([src/data-discovery/data-discovery.js](src/data-discovery/data-discovery.js)) to profile each one (row/column counts, sample records).
3. Creates a `PENDING` `Submission` per file and immediately claims it via `claimNextPendingSubmission()` — the same atomic job-claiming path a background worker would use.
4. Sends **one** batched request covering every file in the upload to the GenAI Service Builder endpoint via [src/api/genaiClient.js](src/api/genaiClient.js) (a Node port of `classify_with_genai.py`'s prompt-building/response-parsing logic).
5. Writes a `Classification` row back for each file that got a result (`createClassification()`), or marks the submission `FAILED` if the model didn't return one.

`GET /api/submissions/stats` backs the dashboard's stat cards ([DashboardPage.jsx](src/webui/src/pages/DashboardPage.jsx)) with real counts (`totalSubmissions`, `classifiedToday`, `pendingReview`) instead of placeholder numbers.

### Known limitations

- No auth yet — every upload is attributed to a single shared "Web UI Uploads" account ([src/api/defaultUser.js](src/api/defaultUser.js)).
- `classify_with_genai.py` (Python CLI) and `src/api/genaiClient.js` (Node) both call the same GenAI endpoint independently — they aren't unified into one implementation, so a prompt change needs to be made in both places.
- The whole classify request is synchronous (the UI waits on the GenAI call); a real system would enqueue the job and let the UI poll/subscribe for the result.
