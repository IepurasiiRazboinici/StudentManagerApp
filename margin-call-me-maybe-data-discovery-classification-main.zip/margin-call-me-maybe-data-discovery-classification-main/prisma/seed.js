// prisma/seed.js
//
// Seeds a handful of realistic-looking (but 100% synthetic) submissions so
// the app has something to demo without uploading files by hand first.
// Run with `npm run db:seed` (or `npx prisma db seed`).
//
// This intentionally goes through the same src/backend/db/* functions the rest of
// the app uses (createSubmission, createClassification, addReviewAction,
// claimNextPendingSubmission) instead of calling prisma.*.create directly -
// that way the seed script doubles as a smoke test for the db layer.
const { prisma } = require("../src/backend/db/client");
const { createSubmission, claimNextPendingSubmission } = require("../src/backend/db/submissions");
const { createClassification } = require("../src/backend/db/classifications");
const { addReviewAction } = require("../src/backend/db/reviewActions");

// --- Synthetic sample file contents (loosely modeled on this repo's real
// sample assets, but kept self-contained so the seed script has no file
// path dependencies) ---------------------------------------------------

const CUSTOMER_CONTACTS_CSV = `customer_id,full_name,email,phone,account_manager
CUST-10231,Priya Natarajan,priya.natarajan@example.com,+1-415-555-0142,J. Alvarez
CUST-10232,Marcus Webb,marcus.webb@example.com,+1-312-555-0198,J. Alvarez
CUST-10233,Ines Dubois,ines.dubois@example.com,+33-1-55-55-0110,R. Chen
CUST-10234,Tomasz Kowalski,tomasz.kowalski@example.com,+48-22-555-0173,R. Chen
`;

const FINANCIAL_REPORT_MD = `# Q3 2026 Financial Report (DRAFT)

> **Status:** DRAFT - NOT YET PUBLISHED
> **Scheduled Publish Date:** 2026-08-10
> **Distribution:** Internal only - Board, Finance, Investor Relations (pre-release)

## Summary

Revenue grew 8% quarter-over-quarter, driven by continued expansion in the
APAC region. Operating margin improved to 21.4%, up from 19.8% in Q2.

Full commentary and audited figures are pending sign-off from the audit
committee ahead of the scheduled public release date above.
`;

const MARKET_DATA_LOG = `INFO[16:54:04,773] - RecordService.MsgProcessor - DATALOG - IWM,32=5098295.0,6=286.93,1000=A,3855=50044316,178=40.0,18=13:54:00,22=286.91,25=286.92
INFO[16:54:04,774] - RecordService.MsgProcessor - DATALOG - MGC,22=267.96,1000=A,25=268.12,30=2200.0,31=2000.0,3855=50044013
`;

async function main() {
  console.log("Seeding users...");
  // upsert so re-running the seed script doesn't fail on unique email constraints
  const intern = await prisma.user.upsert({
    where: { email: "intern@example.com" },
    update: {},
    create: { name: "Alex Intern", email: "intern@example.com", role: "INTERN" },
  });
  const reviewer = await prisma.user.upsert({
    where: { email: "reviewer@example.com" },
    update: {},
    create: { name: "Riley Reviewer", email: "reviewer@example.com", role: "REVIEWER" },
  });
  const admin = await prisma.user.upsert({
    where: { email: "admin@example.com" },
    update: {},
    create: { name: "Sam Admin", email: "admin@example.com", role: "ADMIN" },
  });

  // --- Submission 1: customer contact CSV - left PENDING, as if it was
  // just uploaded and nothing has processed it yet. ----------------------
  console.log("Seeding submission 1/3: customer contacts CSV (PENDING)...");
  await createSubmission({
    uploadedById: intern.id,
    fileName: "customer-contacts.csv",
    fileType: "csv",
    rawContent: { text: CUSTOMER_CONTACTS_CSV },
    userNotes: "Export from the CRM for the Q3 outreach campaign.",
    sourceMetadata: {
      rowCount: 4,
      columnCount: 5,
      columns: ["customer_id", "full_name", "email", "phone", "account_manager"],
      sampleRecords: [
        {
          customer_id: "CUST-10231",
          full_name: "Priya Natarajan",
          email: "priya.natarajan@example.com",
          phone: "+1-415-555-0142",
          account_manager: "J. Alvarez",
        },
      ],
    },
  });

  // --- Submission 2: financial report - fully processed end-to-end:
  // classified by the "LLM" (hardcoded here) and then approved by a
  // reviewer, showing what a finished record looks like. ------------------
  console.log("Seeding submission 2/3: financial report draft (CLASSIFIED + reviewed)...");
  const financialReportSubmission = await createSubmission({
    uploadedById: intern.id,
    fileName: "financial-report-q3-2026-draft.md",
    fileType: "markdown",
    rawContent: { text: FINANCIAL_REPORT_MD },
    userNotes: "Draft Q3 report, board hasn't signed off yet.",
    sourceMetadata: {
      rowCount: null,
      columnCount: null,
      documentType: "financial-report",
      detectedFields: { status: "DRAFT", scheduledPublishDate: "2026-08-10" },
    },
  });

  const classification = await createClassification({
    submissionId: financialReportSubmission.id,
    classificationLevel: "INTERNAL",
    confidenceScore: 0.86,
    evidence: {
      signals: [
        "Status field says 'DRAFT - NOT YET PUBLISHED'",
        "Scheduled publish date 2026-08-10 is in the future",
      ],
    },
    referencedGuidance: { rule: "unpublished-financials-are-internal" },
    explanation:
      "This is an unpublished quarterly financial report. Its scheduled publish date hasn't passed yet, so per policy it must stay Internal until the official release date.",
    modelVersion: "seed-script-v1",
  });

  console.log("Recording a reviewer APPROVE action on the financial report classification...");
  await addReviewAction({
    classificationId: classification.id,
    userId: reviewer.id,
    action: "APPROVE",
    comment: "Agreed - matches our draft-financials policy.",
  });

  // --- Submission 3: market data log - left PENDING like submission 1. --
  console.log("Seeding submission 3/3: market data log (PENDING)...");
  await createSubmission({
    uploadedById: admin.id,
    fileName: "market-data-usa.log",
    fileType: "log",
    rawContent: { text: MARKET_DATA_LOG },
    userNotes: null,
    sourceMetadata: {
      rowCount: 2,
      columnCount: null,
      documentType: "market-data-feed",
      detectedInstruments: ["IWM", "MGC"],
    },
  });

  // Demonstrate the same atomic "claim a job" query a real worker would
  // run: this grabs whichever PENDING submission is oldest (of the two we
  // left pending above) and flips it to PROCESSING in one statement.
  const claimed = await claimNextPendingSubmission();
  console.log(
    claimed
      ? `Claimed "${claimed.fileName}" for processing (status is now PROCESSING).`
      : "Nothing left to claim."
  );

  console.log("Seed complete.");
}

main()
  .catch((err) => {
    console.error("Seed failed:", err);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
