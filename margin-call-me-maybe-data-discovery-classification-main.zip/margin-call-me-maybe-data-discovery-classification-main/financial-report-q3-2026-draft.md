# Solstice Robotics Inc. — Q3 2026 Financial Results (DRAFT)

> **Status:** 🔒 DRAFT — NOT YET PUBLISHED
> **Scheduled Publish Date:** 2026-08-10
> **Prepared by:** Finance Reporting Team
> **Distribution:** Internal only — Board, Finance, Investor Relations (pre-release)

---

**Do not distribute externally before the scheduled publish date above.**
This report contains preliminary, unaudited figures for the quarter ended
30 September 2026 and is subject to change before the public release.

## Summary

| Metric | Q3 2026 (Draft) | Q3 2025 (Actual) | YoY |
|---|---|---|---|
| Revenue | $412.6M | $368.2M | +12.1% |
| Gross Margin | 58.3% | 56.9% | +1.4 pts |
| Operating Income | $71.4M | $58.7M | +21.6% |
| Net Income | $52.9M | $41.3M | +28.1% |
| Diluted EPS | $0.87 | $0.68 | +27.9% |
| Free Cash Flow | $63.2M | $49.5M | +27.7% |

## Segment Performance (Draft)

| Segment | Revenue | % of Total |
|---|---|---|
| Industrial Automation | $198.4M | 48.1% |
| Field Robotics | $132.7M | 32.2% |
| Software & Services | $81.5M | 19.7% |

## Management Commentary (Draft)

Preliminary results indicate continued strength in Industrial Automation,
driven by two large deployments that closed ahead of schedule late in the
quarter. Field Robotics grew modestly as expected. Software & Services
attach rates continue to trend upward across the installed base.

Guidance for Q4 2026 has not yet been finalized and will be included in the
version released on the scheduled publish date.

## Notes for Reviewers

- Figures above are **unaudited** and subject to final close adjustments.
- Do **not** forward this draft outside the distribution list above.
- The public version released on 2026-08-10 may differ from the numbers in
  this draft pending final review.

---
*This is a synthetic sample document created for a data classification
training exercise. The company, figures, and results are fictional.*

