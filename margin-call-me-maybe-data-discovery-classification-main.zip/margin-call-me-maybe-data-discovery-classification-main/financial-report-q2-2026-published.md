# Solstice Robotics Inc. — Q2 2026 Financial Results

> **Status:** ✅ Published
> **Published Date:** 2026-05-10
> **Prepared by:** Finance Reporting Team
> **Distribution:** Public — released via investor relations website and press release

---

This report contains final, audited figures for the quarter ended
30 June 2026 and was publicly released on the date above. It may be freely
shared, quoted, and redistributed.

## Summary

| Metric | Q2 2026 | Q2 2025 | YoY |
|---|---|---|---|
| Revenue | $389.1M | $342.5M | +13.6% |
| Gross Margin | 57.6% | 56.1% | +1.5 pts |
| Operating Income | $65.8M | $52.9M | +24.4% |
| Net Income | $48.3M | $37.6M | +28.5% |
| Diluted EPS | $0.79 | $0.62 | +27.4% |
| Free Cash Flow | $57.9M | $44.8M | +29.2% |

## Segment Performance

| Segment | Revenue | % of Total |
|---|---|---|
| Industrial Automation | $184.2M | 47.3% |
| Field Robotics | $126.9M | 32.6% |
| Software & Services | $78.0M | 20.1% |

## Management Commentary

"Q2 2026 was another strong quarter for Solstice Robotics, with continued
momentum across our Industrial Automation and Software & Services segments,"
said the company's CFO in the released statement. "We remain confident in
our full-year outlook and continue to invest in expanding our field
robotics footprint."

Q3 2026 guidance was reaffirmed at the time of this release and is expected
to be updated when Q3 results are published.

## Distribution Notes

- This report is final, audited, and has been publicly released.
- No restrictions apply to redistribution or citation of the figures above.

---
*This is a synthetic sample document created for a data classification
training exercise. The company, figures, and results are fictional.*

