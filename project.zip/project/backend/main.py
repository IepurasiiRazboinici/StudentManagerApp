import json
from datetime import date
from typing import Any, Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from classifier.custom_rules import (
    RuleCreateRequest,
    ReclassifyResponse,
    create_classification_rule,
    delete_classification_rule,
    list_classification_rules,
    preview_classification_rule,
    reclassify_dataset,
    update_classification_rule,
)
from classifier.models import (
    ClassifyRequest,
    ClassifyResponse,
    ClassifyTextRequest,
    ReviewDecisionRequest,
    ReviewDecisionResponse,
)
from classifier.service import classify_discovered_request, classify_uploaded_content, submit_review_decision


app = FastAPI(title="Data Discovery Classification API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def read_root() -> dict[str, str]:
    return {"message": "Data classification backend is running."}


@app.get("/api/message")
def get_message() -> dict[str, str]:
    return {"message": "Hello from the backend!"}


@app.post("/api/classify/discovered", response_model=ClassifyResponse)
def classify_discovered(request_body: ClassifyRequest) -> ClassifyResponse:
    return classify_discovered_request(request_body)

@app.post("/api/classify/text", response_model=ClassifyResponse)
async def classify_text(
    request: ClassifyTextRequest,
) -> ClassifyResponse:
    request_body = ClassifyRequest(
        prompt=request.prompt,
        use_llm=request.use_llm,
        llm_endpoint=request.llm_endpoint,
        llm_bearer_token=request.llm_bearer_token,
        llm_timeout_seconds=request.llm_timeout_seconds,
        llm_max_tokens=request.llm_max_tokens,
        llm_additional_payload=request.llm_additional_payload,
        current_date=request.current_date,
    )

    return classify_uploaded_content(
        "text_input",
        request.content.encode("utf-8"),
        request_body,
    )

@app.post("/api/classify/upload", response_model=ClassifyResponse)
async def classify_uploaded_file(
    file: UploadFile = File(...),
    prompt: Optional[str] = Form(None),
    use_llm: bool = Form(True),
    llm_endpoint: Optional[str] = Form(None),
    llm_bearer_token: Optional[str] = Form(None),
    llm_timeout_seconds: int = Form(45),
    llm_max_tokens: int = Form(650),
    llm_additional_payload_json: Optional[str] = Form(None),
    current_date: Optional[date] = Form(None),
) -> ClassifyResponse:
    try:
        additional_payload = json.loads(llm_additional_payload_json) if llm_additional_payload_json else {}
        if not isinstance(additional_payload, dict):
            raise ValueError("llm_additional_payload_json must decode to a JSON object")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    request_body = ClassifyRequest(
        prompt=prompt,
        use_llm=use_llm,
        llm_endpoint=llm_endpoint,
        llm_bearer_token=llm_bearer_token,
        llm_timeout_seconds=llm_timeout_seconds,
        llm_max_tokens=llm_max_tokens,
        llm_additional_payload=additional_payload,
        current_date=current_date,
    )
    content = await file.read()
    return classify_uploaded_content(file.filename or "uploaded_asset", content, request_body)



@app.post("/api/reviews/decision", response_model=ReviewDecisionResponse)
def save_review_decision(request_body: ReviewDecisionRequest) -> ReviewDecisionResponse:
    saved = submit_review_decision(request_body)
    return ReviewDecisionResponse(
        saved=True,
        review_key=saved["review_key"],
        corrected_classification=request_body.corrected_classification,
    )


@app.get("/api/classification-rules")
def list_rules() -> list[dict[str, Any]]:
    return list_classification_rules()


@app.post("/api/classification-rules")
def create_rule(request_body: RuleCreateRequest) -> dict[str, Any]:
    return create_classification_rule(request_body)


@app.post("/api/classification-rules/preview")
def preview_rule(request_body: RuleCreateRequest) -> dict[str, Any]:
    return preview_classification_rule(request_body).model_dump()


@app.patch("/api/classification-rules/{rule_id}")
def update_rule(rule_id: str, patch: dict[str, Any]) -> dict[str, Any]:
    updated = update_classification_rule(rule_id, patch)
    if updated is None:
        raise HTTPException(status_code=404, detail="Rule not found")
    return updated


@app.delete("/api/classification-rules/{rule_id}")
def delete_rule(rule_id: str) -> dict[str, bool]:
    deleted = delete_classification_rule(rule_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Rule not found")
    return {"ok": True}


@app.post("/api/datasets/{dataset_id}/reclassify", response_model=ReclassifyResponse)
def reclassify(dataset_id: str) -> ReclassifyResponse:
    return reclassify_dataset(dataset_id)
