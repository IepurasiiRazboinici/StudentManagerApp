from datetime import date

from main import ClassifyRequest, classify_discovered


if __name__ == "__main__":
    response = classify_discovered(
        ClassifyRequest(
            use_llm=False,
            current_date=date(2026, 7, 22),
        )
    )

    print(f"Discovered assets: {response.discovered_assets}")
    print("Distribution:")
    for label, count in sorted(response.distribution.items()):
        print(f"  - {label}: {count}")

    print("\nKey sample classifications:")
    observed = {result.asset_path.split("/")[-1]: result for result in response.results}
    expected = {
        "market-data-usa.log": "Restricted",
        "reuters.fids": "Corporate",
        "trades.csv": "Highly Restricted",
        "trades_sample.csv": "Highly Restricted",
        "financial-report-q3-2026-draft.md": "Highly Restricted",
        "financial-report-q2-2026-published.md": "Public",
    }

    failures = []
    for filename, expected_label in expected.items():
        result = observed.get(filename)
        if not result:
            failures.append(f"Missing classification result for {filename}")
            continue
        print(f"  - {result.asset_path}: {result.classification.value} (confidence={result.confidence})")
        if result.classification.value != expected_label:
            failures.append(
                f"{filename}: expected={expected_label}, got={result.classification.value}"
            )

    if failures:
        print("\nSmoke check failed:")
        for item in failures:
            print(f"  - {item}")
        raise SystemExit(1)

