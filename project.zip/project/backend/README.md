# Backend Classification API

This backend exposes an endpoint that discovers files in the sample data folder and classifies each asset into:


- Public
- Corporate
- Restricted
- Highly Restricted

Each result includes confidence, evidence, guidance references, and human-review metadata.

`Corporate` is the same tier as `Internal` in the challenge text (the backend accepts either label from LLM output/reviewer input and normalizes to `Corporate`).

## Code layout

The backend is now split into smaller modules under `backend/classifier/`:

- `models.py` - request/response and classification models
- `constants.py` - shared constants and taxonomy helpers
- `profiling.py` - asset discovery and file profiling
- `rules.py` - deterministic classification policy rules
- `custom_rules.py` - user-defined classification rules: persistence (`classification_rules.json`), the trigger-matching engine, and the `/api/classification-rules*` endpoint logic
- `llm_client.py` - optional external LLM call + merge logic
- `service.py` - orchestration used by the FastAPI endpoints

`main.py` is kept intentionally thin so it only defines the API routes.

## Classification rules

Rules created via `POST /api/classification-rules` (or the frontend's Rules
page) are persisted to `backend/classification_rules.json` and are actually
applied on every classification, not just stored for display:

- Each rule's trigger (`FILE_NAME`, `FIELD_NAME`, `FIELD_COMBINATION`,
  `EXPLICIT_MARKER`, `CONTENT_PATTERN`, `DOCUMENT_TYPE`, `METADATA_STATUS`) is
  evaluated against the real asset profile by `custom_rules.evaluate_rule_match`.
- When a rule matches, its target tier becomes an authoritative override of the
  deterministic result (ties across multiple matching rules are broken by
  priority, then confidence), and a `custom_rule_match` evidence item is added.
  The full list of matches is returned per-asset as `custom_rule_matches`.
- Matched rules are also forwarded to the external LLM as a `classification_rules`
  key inside the `input1` payload, so the model takes them into account too. This
  requires updating the **hosted service's own system prompt** — see
  `backend/EXTERNAL_LLM_SYSTEM_PROMPT.md` for the exact text to configure there
  (it cannot be changed from this repo, since it lives on the GenAI Service
  Builder side).
- `matchedFiles`/`matchStatus` on each rule are computed by scanning the sample
  data directory whenever a rule is created/updated.

## Endpoints

- `GET /` health-style message
- `GET /api/message` simple test message
- `POST /api/classify/discovered` classify discovered assets
- `POST /api/classify/upload` classify a user-uploaded file (multipart form)
- `POST /api/reviews/decision` persist a human reviewer correction for future classifications
- `GET /api/classification-rules` / `POST /api/classification-rules` / `PATCH /api/classification-rules/{id}` / `DELETE /api/classification-rules/{id}` manage user-defined classification rules
- `POST /api/classification-rules/preview` preview whether a (draft) rule matches a sample/named asset

## Request body (`POST /api/classify/discovered`)

```json
{
  "prompt": "Optional prompt sent to your external LLM API.",
  "asset_paths": [],
  "data_root": "Optional absolute path to data root",
  "postgres_dsn": "Optional PostgreSQL DSN, e.g. postgresql://user:pass@host:5432/db",
  "postgres_schema": "public",
  "postgres_tables": [],
  "postgres_sample_rows": 3,
  "use_llm": true,
  "llm_endpoint": "https://your-classifier/api",
  "llm_bearer_token": "Optional bearer token",
  "llm_max_tokens": 650,
  "llm_additional_payload": {},
  "llm_timeout_seconds": 15,
  "current_date": "2026-07-22"
}
```

Notes:
- If `llm_endpoint` is omitted, set env var `CLASSIFIER_LLM_ENDPOINT`.
- If no LLM endpoint is configured, only deterministic rules are used.
- `asset_paths` can be relative to `data_root` or absolute file paths.
- If `postgres_dsn` is supplied, table metadata/row samples are discovered and classified alongside file assets.
- The backend saves reviewer corrections to `backend/review_memory.json` and reuses them in future classifications.

## Run

```powershell
cd C:\Users\mmihet\IdeaProjects\Hackathon\backend
python -m pip install -r requirements.txt
python smoke_check.py
uvicorn main:app --reload --port 8000
```

## Example call

```powershell
$body = @{
  use_llm = $false
  current_date = "2026-07-22"
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://127.0.0.1:8000/api/classify/discovered" -Method Post -ContentType "application/json" -Body $body
```

## Example upload call

```powershell
$form = @{
  file = Get-Item "C:\Users\mmihet\IdeaProjects\Hackathon\data-discovery-classification-hackathon-main\data-discovery-classification-hackathon-main\trades_sample.csv"
  use_llm = "true"
  llm_endpoint = "https://genai-service-builder.int.refinitiv.com/api/v1/services/hackathon/hackathon"
  llm_bearer_token = "<YOUR_TOKEN>"
  llm_max_tokens = "650"
  prompt = "Classify into Public, Corporate, Restricted, or Highly Restricted. Return JSON with classification, confidence, explanation, evidence."
  current_date = "2026-07-22"
}

Invoke-RestMethod -Uri "http://127.0.0.1:8000/api/classify/upload" -Method Post -Form $form
```

## Save human review decision

Use `review_key` returned in each classification result.

```powershell
$body = @{
  review_key = "rk-xxxxxxxxxxxxxxxxxxxxxxxx"
  corrected_classification = "Highly Confidential"
  corrected_classification = "Highly Restricted"
  reviewer_id = "reviewer-01"
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://127.0.0.1:8000/api/reviews/decision" -Method Post -ContentType "application/json" -Body $body
```

