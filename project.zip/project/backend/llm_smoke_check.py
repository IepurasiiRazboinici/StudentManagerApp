import json
import threading
from datetime import date
from http.server import BaseHTTPRequestHandler, HTTPServer

from classifier.models import ClassifyRequest
from classifier.service import classify_uploaded_content


class _MockLlmHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        _ = self.rfile.read(int(self.headers.get("Content-Length", "0") or "0"))
        response = {
            "choices": [
                {
                    "message": {
                        "content": (
                            '{"classification":"Restricted",'
                            '"confidence":0.92,'
                            '"explanation":"Client-like allocation data detected by model.",'
                            '"evidence":["allocation terms", "account ids"]}'
                        )
                    }
                }
            ]
        }
        body = json.dumps(response).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *_args):
        return


if __name__ == "__main__":
    server = HTTPServer(("127.0.0.1", 0), _MockLlmHandler)
    host, port = server.server_address
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    try:
        test_file = (
            "C:\\Users\\mmihet\\IdeaProjects\\Hackathon\\"
            "data-discovery-classification-hackathon-main\\"
            "data-discovery-classification-hackathon-main\\trades_sample.csv"
        )
        with open(test_file, "rb") as handle:
            payload = handle.read()

        response = classify_uploaded_content(
            filename="trades_sample.csv",
            content=payload,
            request_body=ClassifyRequest(
                use_llm=True,
                llm_endpoint=f"http://{host}:{port}",
                current_date=date(2026, 7, 23),
            ),
        )

        result = response.results[0]
        print(f"classification={result.classification.value}")
        print(f"confidence={result.confidence}")
        print("signals=" + ",".join(item.signal for item in result.evidence[-2:]))
    finally:
        server.shutdown()
        server.server_close()

