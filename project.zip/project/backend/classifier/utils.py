from datetime import date
from typing import Any, Optional

from .models import ClassificationLevel


def normalize_classification_label(value: str) -> Optional[ClassificationLevel]:
    normalized = value.strip().lower().replace("_", " ")
    mapping = {
        "public": ClassificationLevel.PUBLIC,
        "corporate": ClassificationLevel.CORPORATE,
        "internal": ClassificationLevel.CORPORATE,
        "restricted": ClassificationLevel.RESTRICTED,
        "confidential": ClassificationLevel.RESTRICTED,
        "highly restricted": ClassificationLevel.HIGHLY_RESTRICTED,
        "highly confidential": ClassificationLevel.HIGHLY_RESTRICTED,
    }
    return mapping.get(normalized)


def normalize_confidence(value: Any) -> float:
    try:
        score = float(value)
    except (TypeError, ValueError):
        return 0.6

    if score > 1.0:
        score = score / 100.0
    if score < 0.0:
        return 0.0
    if score > 1.0:
        return 1.0
    return score


def more_restrictive(left: ClassificationLevel, right: ClassificationLevel) -> ClassificationLevel:
    rank = {
        ClassificationLevel.PUBLIC: 0,
        ClassificationLevel.CORPORATE: 1,
        ClassificationLevel.RESTRICTED: 2,
        ClassificationLevel.HIGHLY_RESTRICTED: 3,
    }
    return left if rank[left] >= rank[right] else right


def parse_iso_date(value: Optional[str]) -> Optional[date]:
    if not value:
        return None
    try:
        return date.fromisoformat(value)
    except ValueError:
        return None

