from __future__ import annotations

import json
import re
from datetime import UTC, datetime
from pathlib import Path
from threading import Lock
from typing import Any, Optional
from uuid import uuid4

from pydantic import BaseModel, Field

from .constants import CLASSIFICATION_RULES_FILE, DEFAULT_DATA_DIR
from .models import ClassificationLevel
from .utils import normalize_classification_label


class RuleCreateRequest(BaseModel):
    name: str
    description: str
    scope: str
    scopeFileId: str | None = None
    datasetId: str | None = None
    triggerType: str
    trigger: dict[str, Any]
    targetTier: str
    confidence: int = Field(ge=50, le=100)
    priority: str
    requireHumanReview: bool
    explanationTemplate: str
    enabled: bool = True


class RulePreviewResult(BaseModel):
    matches: bool
    matchedFields: list[str]
    currentClassification: str
    currentConfidence: int
    predictedClassification: str
    predictedConfidence: int
    requiresHumanReview: bool
    explanation: str


class ReclassifyResponse(BaseModel):
    jobId: str
    datasetId: str
    state: str
    progress: int


_SCOPE_LABEL = {
    "THIS_FILE": "This file",
    "ALL_FILES": "All files",
}


def _load_rules_from_disk(file_path: Path = CLASSIFICATION_RULES_FILE) -> dict[str, dict[str, Any]]:
    if not file_path.exists():
        return {}
    try:
        content = json.loads(file_path.read_text(encoding="utf-8"))
    except (TypeError, ValueError):
        return {}
    if not isinstance(content, list):
        return {}
    return {item["id"]: item for item in content if isinstance(item, dict) and item.get("id")}


def _save_rules_to_disk(rules: dict[str, dict[str, Any]], file_path: Path = CLASSIFICATION_RULES_FILE) -> None:
    file_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = file_path.with_suffix(file_path.suffix + ".tmp")
    tmp_path.write_text(json.dumps(list(rules.values()), indent=2), encoding="utf-8")
    tmp_path.replace(file_path)


class _RuleStore:
    def __init__(self) -> None:
        self._lock = Lock()
        self._rules: dict[str, dict[str, Any]] = _load_rules_from_disk()

    def _persist(self) -> None:
        _save_rules_to_disk(self._rules)

    def list_rules(self) -> list[dict[str, Any]]:
        with self._lock:
            return sorted(self._rules.values(), key=lambda item: item["updatedAt"], reverse=True)

    def get_rule(self, rule_id: str) -> dict[str, Any] | None:
        with self._lock:
            rule = self._rules.get(rule_id)
            return dict(rule) if rule is not None else None

    def list_enabled_rules(self) -> list[dict[str, Any]]:
        with self._lock:
            return [dict(rule) for rule in self._rules.values() if rule.get("enabled")]

    def create_rule(self, request_body: RuleCreateRequest) -> dict[str, Any]:
        now = datetime.now(UTC).isoformat()
        rule_id = f"custom-{uuid4().hex[:8]}"
        trigger_summary = _summarize_trigger(request_body.triggerType, request_body.trigger)
        rule = {
            "id": rule_id,
            "name": request_body.name,
            "description": request_body.description,
            "source": "CUSTOM",
            "scope": request_body.scope,
            "scopeFileId": request_body.scopeFileId,
            "scopeLabel": _SCOPE_LABEL.get(request_body.scope, request_body.scope),
            "triggerType": request_body.triggerType,
            "triggerSummary": trigger_summary,
            "trigger": request_body.trigger,
            "targetTier": request_body.targetTier,
            "confidence": request_body.confidence,
            "priority": request_body.priority,
            "requireHumanReview": request_body.requireHumanReview,
            "explanationTemplate": request_body.explanationTemplate,
            "enabled": request_body.enabled,
            "protected": False,
            "matchedFiles": 0,
            "matchStatus": "UNKNOWN",
            "updatedAt": now,
        }
        with self._lock:
            self._rules[rule_id] = rule
            self._persist()
        _recompute_match_stats(rule)
        with self._lock:
            self._rules[rule_id] = rule
            self._persist()
        return rule

    def update_rule(self, rule_id: str, patch: dict[str, Any]) -> dict[str, Any] | None:
        with self._lock:
            current = self._rules.get(rule_id)
            if current is None:
                return None
            if current.get("protected"):
                return None

            # Allow explicit clearing of scopeFileId when scope changes to ALL_FILES.
            for key, value in patch.items():
                if key == "scopeFileId":
                    current[key] = value
                elif value is not None:
                    current[key] = value
            if "scope" in patch:
                current["scopeLabel"] = _SCOPE_LABEL.get(str(current["scope"]), str(current["scope"]))
            if "triggerType" in current and "trigger" in current and "triggerSummary" not in patch:
                current["triggerSummary"] = _summarize_trigger(str(current["triggerType"]), current["trigger"])
            current["updatedAt"] = datetime.now(UTC).isoformat()
            self._rules[rule_id] = current
            self._persist()
        _recompute_match_stats(current)
        with self._lock:
            self._rules[rule_id] = current
            self._persist()
        return current

    def delete_rule(self, rule_id: str) -> bool:
        with self._lock:
            if rule_id not in self._rules:
                return False
            if self._rules[rule_id].get("protected"):
                return False
            del self._rules[rule_id]
            self._persist()
            return True


_STORE = _RuleStore()



def list_classification_rules() -> list[dict[str, Any]]:
    return _STORE.list_rules()


def create_classification_rule(request_body: RuleCreateRequest) -> dict[str, Any]:
    return _STORE.create_rule(request_body)


def update_classification_rule(rule_id: str, patch: dict[str, Any]) -> dict[str, Any] | None:
    return _STORE.update_rule(rule_id, patch)


def delete_classification_rule(rule_id: str) -> bool:
    return _STORE.delete_rule(rule_id)


def preview_classification_rule(request_body: RuleCreateRequest) -> RulePreviewResult:
    profile = _resolve_preview_profile(request_body.scopeFileId or request_body.datasetId)
    current_tier = "Restricted"
    current_confidence = 72

    matched, matched_fields = evaluate_rule_match(request_body.triggerType, request_body.trigger, profile)
    predicted_tier = request_body.targetTier if matched else current_tier
    predicted_confidence = request_body.confidence if matched else current_confidence
    sample_name = profile.get("asset_name", "sample_dataset")
    explanation = (
        f'Rule "{request_body.name}" matched "{sample_name}" (fields: {", ".join(matched_fields) or "n/a"}) '
        f"and would classify it as {predicted_tier}."
        if matched
        else f'Rule "{request_body.name}" does not match "{sample_name}".'
    )
    return RulePreviewResult(
        matches=matched,
        matchedFields=matched_fields,
        currentClassification=current_tier,
        currentConfidence=current_confidence,
        predictedClassification=predicted_tier,
        predictedConfidence=predicted_confidence,
        requiresHumanReview=request_body.requireHumanReview or request_body.targetTier == "HIGHLY_RESTRICTED",
        explanation=explanation,
    )


def reclassify_dataset(dataset_id: str) -> ReclassifyResponse:
    return ReclassifyResponse(
        jobId=f"job-{dataset_id}-{uuid4().hex[:6]}",
        datasetId=dataset_id,
        state="COMPLETE",
        progress=100,
    )


def _summarize_trigger(trigger_type: str, trigger: dict[str, Any]) -> str:
    if trigger_type == "FILE_NAME":
        operator = trigger.get("operator", "contains")
        return f'File name {operator} "{trigger.get("value", "")}"'.strip()
    if trigger_type == "FIELD_NAME":
        aliases = ", ".join(trigger.get("aliases", []))
        return f"Field aliases: {aliases}" if aliases else "Field name trigger"
    if trigger_type == "FIELD_COMBINATION":
        fields = trigger.get("fields", [])
        return f"All fields present: {', '.join(fields)}" if fields else "Field combination"
    if trigger_type == "EXPLICIT_MARKER":
        return f'Marker contains "{trigger.get("markerText", "")}"'.strip()
    if trigger_type == "CONTENT_PATTERN":
        return f'Content pattern "{trigger.get("pattern", "")}"'.strip()
    if trigger_type == "DOCUMENT_TYPE":
        return f'Document type is "{trigger.get("documentType", "")}"'.strip()
    if trigger_type == "METADATA_STATUS":
        return f'Metadata {trigger.get("key", "")}={trigger.get("expectedValue", "")}'.strip()
    return "Custom trigger"


# ---------------------------------------------------------------------------
# Trigger evaluation engine
#
# This is the single source of truth for whether a stored rule "fires" against
# a given asset `profile` (the same dict produced by classifier/profiling.py).
# It is used for BOTH the `/preview` endpoint and the real classification path
# in classifier/service.py, so a rule behaves identically in the preview UI and
# during an actual classification run.
# ---------------------------------------------------------------------------

def evaluate_rule_match(trigger_type: str, trigger: dict[str, Any], profile: dict[str, Any]) -> tuple[bool, list[str]]:
    asset_name = str(profile.get("asset_name", ""))
    columns = [str(c) for c in profile.get("columns", []) if c]
    sensitive_columns = [str(c) for c in profile.get("sensitive_columns_found", []) if c]
    all_fields = list(dict.fromkeys([*columns, *sensitive_columns]))
    preview_text = str(profile.get("preview", "") or "")
    text_signals = profile.get("text_signals", {}) or {}

    if trigger_type == "FILE_NAME":
        operator = str(trigger.get("operator", "contains")).lower()
        value = str(trigger.get("value", ""))
        if not value:
            return False, []
        haystack = asset_name.lower()
        needle = value.lower()
        if operator == "contains" and needle in haystack:
            return True, [asset_name]
        if operator == "starts_with" and haystack.startswith(needle):
            return True, [asset_name]
        if operator == "ends_with" and haystack.endswith(needle):
            return True, [asset_name]
        if operator == "equals" and haystack == needle:
            return True, [asset_name]
        if operator == "regex":
            try:
                if re.search(value, asset_name, flags=re.IGNORECASE):
                    return True, [asset_name]
            except re.error:
                return False, []
        return False, []

    if trigger_type == "FIELD_NAME":
        aliases = [str(a).strip() for a in trigger.get("aliases", []) if str(a).strip()]
        use_regex = bool(trigger.get("useRegex"))
        pattern = str(trigger.get("pattern", ""))
        matched: list[str] = []
        if use_regex and pattern:
            try:
                compiled = re.compile(pattern, flags=re.IGNORECASE)
            except re.error:
                compiled = None
            if compiled:
                matched = [field for field in all_fields if compiled.search(field)]
        else:
            lowered_aliases = [a.lower() for a in aliases]
            matched = [field for field in all_fields if field.lower() in lowered_aliases]
        return (len(matched) > 0), matched

    if trigger_type == "FIELD_COMBINATION":
        required_fields = [str(f).strip() for f in trigger.get("fields", []) if str(f).strip()]
        if not required_fields:
            return False, []
        lowered_all = {f.lower() for f in all_fields}
        matched_all = all(field.lower() in lowered_all for field in required_fields)
        return matched_all, (required_fields if matched_all else [])

    if trigger_type == "EXPLICIT_MARKER":
        marker_text = str(trigger.get("markerText", "")).strip()
        if not marker_text:
            return False, []
        found = marker_text.lower() in preview_text.lower()
        status_value = trigger.get("statusValue")
        if found and status_value:
            found = str(profile.get("status") or "").strip().lower() == str(status_value).strip().lower()
        return found, ([marker_text] if found else [])

    if trigger_type == "CONTENT_PATTERN":
        pattern = str(trigger.get("pattern", ""))
        if not pattern:
            return False, []
        mode = trigger.get("mode", "plain")
        case_sensitive = bool(trigger.get("caseSensitive"))
        try:
            if mode == "regex":
                flags = 0 if case_sensitive else re.IGNORECASE
                found = bool(re.search(pattern, preview_text, flags=flags))
            else:
                haystack = preview_text if case_sensitive else preview_text.lower()
                needle = pattern if case_sensitive else pattern.lower()
                found = needle in haystack
        except re.error:
            found = False
        return found, ([pattern] if found else [])

    if trigger_type == "DOCUMENT_TYPE":
        document_type = str(trigger.get("documentType", "")).strip().lower()
        if not document_type:
            return False, []
        asset_type = str(profile.get("asset_type", "")).strip().lower()
        suffix = str(profile.get("suffix", "")).strip(".").lower()
        found = document_type in {asset_type, suffix}
        return found, ([asset_name] if found else [])

    if trigger_type == "METADATA_STATUS":
        key = str(trigger.get("key", "")).strip()
        expected_value = str(trigger.get("expectedValue", "")).strip().lower()
        if not key:
            return False, []
        actual = profile.get(key)
        if actual is None:
            actual = text_signals.get(key)
        found = str(actual if actual is not None else "").strip().lower() == expected_value
        return found, ([key] if found else [])

    return False, []


# Maps the frontend's UPPERCASE tier enum to the backend's title-case taxonomy
# labels (also tolerant of a title-case value being passed in directly).
_FRONTEND_TIER_TO_LEVEL = {
    "PUBLIC": ClassificationLevel.PUBLIC,
    "CORPORATE": ClassificationLevel.CORPORATE,
    "RESTRICTED": ClassificationLevel.RESTRICTED,
    "HIGHLY_RESTRICTED": ClassificationLevel.HIGHLY_RESTRICTED,
}


def map_target_tier(value: str) -> Optional[ClassificationLevel]:
    normalized = str(value or "").strip().upper()
    if normalized in _FRONTEND_TIER_TO_LEVEL:
        return _FRONTEND_TIER_TO_LEVEL[normalized]
    return normalize_classification_label(str(value or ""))


def rule_applies_to_scope(rule: dict[str, Any], profile: dict[str, Any]) -> bool:
    if rule.get("scope") != "THIS_FILE":
        return True
    scope_file_id = rule.get("scopeFileId")
    if not scope_file_id:
        return True
    candidates = {str(profile.get("asset_path", "")), str(profile.get("asset_name", ""))}
    return str(scope_file_id) in candidates


def get_matching_rules_for_asset(profile: dict[str, Any]) -> list[dict[str, Any]]:
    """Return every enabled stored rule (system or custom) that fires against `profile`,
    each annotated with the fields/markers that matched. Used by classifier/service.py to
    fold user-defined rules into both the deterministic result and the LLM payload."""
    matches: list[dict[str, Any]] = []
    for rule in _STORE.list_enabled_rules():
        if not rule_applies_to_scope(rule, profile):
            continue
        matched, matched_fields = evaluate_rule_match(str(rule.get("triggerType", "")), rule.get("trigger") or {}, profile)
        if matched:
            enriched = dict(rule)
            enriched["matchedFields"] = matched_fields
            matches.append(enriched)
    return matches


def _resolve_preview_profile(scope_file_id: Optional[str]) -> dict[str, Any]:
    """Best-effort profile lookup for the `/preview` endpoint: try to profile the
    referenced sample asset from the repo's data directory, falling back to a
    generic synthetic profile so preview always returns something useful."""
    from .profiling import profile_asset, resolve_assets  # local import avoids a cycle at module load time

    fallback = {
        "asset_name": "sample_dataset.csv",
        "asset_path": "sample_dataset.csv",
        "asset_type": "csv",
        "suffix": ".csv",
        "columns": ["account_id", "trade_quantity", "execid"],
        "sensitive_columns_found": ["account_id", "execid"],
        "preview": "Restricted sample content for rule preview purposes.",
        "text_signals": {},
        "status": None,
    }

    if not scope_file_id:
        return fallback

    try:
        assets = resolve_assets(DEFAULT_DATA_DIR, [])
    except OSError:
        return fallback

    for asset in assets:
        if asset.name == scope_file_id or asset.as_posix().endswith(str(scope_file_id)):
            try:
                return profile_asset(asset, DEFAULT_DATA_DIR, datetime.now(UTC).date())
            except OSError:
                return fallback
    return fallback


def _recompute_match_stats(rule: dict[str, Any]) -> None:
    """Scan the sample data directory and update `matchedFiles`/`matchStatus` on the
    rule in place. Best-effort only — failures (e.g. missing sample data dir on a
    fresh checkout) must never break rule create/update."""
    from .profiling import profile_asset, resolve_assets  # local import avoids a cycle at module load time

    try:
        assets = resolve_assets(DEFAULT_DATA_DIR, [])
    except OSError:
        return

    matched_count = 0
    today = datetime.now(UTC).date()
    for asset in assets:
        try:
            profile = profile_asset(asset, DEFAULT_DATA_DIR, today)
        except OSError:
            continue
        if not rule_applies_to_scope(rule, profile):
            continue
        matched, _ = evaluate_rule_match(str(rule.get("triggerType", "")), rule.get("trigger") or {}, profile)
        if matched:
            matched_count += 1

    rule["matchedFiles"] = matched_count
    rule["matchStatus"] = "MATCHED" if matched_count > 0 else "NOT_MATCHED"


