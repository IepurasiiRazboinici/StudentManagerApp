import json
import re
from typing import Any

from .constants import SENSITIVE_TRADE_COLUMNS

_VALID_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _is_safe_identifier(value: str) -> bool:
    return bool(_VALID_IDENTIFIER.fullmatch(value or ""))


def discover_and_profile_postgres_tables(
    dsn: str,
    schema: str,
    requested_tables: list[str],
    sample_rows: int,
) -> list[dict[str, Any]]:
    """Return table profiles from PostgreSQL; gracefully return [] when driver/connection fails."""
    try:
        import psycopg  # type: ignore[import-not-found]
        from psycopg import sql  # type: ignore[import-not-found]
    except Exception:
        return []

    safe_schema = schema.strip() or "public"
    if not _is_safe_identifier(safe_schema):
        return []

    table_filter = [name.strip() for name in requested_tables if _is_safe_identifier(name.strip())]

    profiles: list[dict[str, Any]] = []
    try:
        with psycopg.connect(dsn, connect_timeout=8) as conn:
            with conn.cursor() as cur:
                if table_filter:
                    cur.execute(
                        """
                        SELECT table_name
                        FROM information_schema.tables
                        WHERE table_schema = %s
                          AND table_type = 'BASE TABLE'
                          AND table_name = ANY(%s)
                        ORDER BY table_name
                        """,
                        (safe_schema, table_filter),
                    )
                else:
                    cur.execute(
                        """
                        SELECT table_name
                        FROM information_schema.tables
                        WHERE table_schema = %s
                          AND table_type = 'BASE TABLE'
                        ORDER BY table_name
                        """,
                        (safe_schema,),
                    )
                table_names = [str(row[0]) for row in cur.fetchall()]

            for table_name in table_names:
                if not _is_safe_identifier(table_name):
                    continue

                with conn.cursor() as cur:
                    cur.execute(
                        """
                        SELECT column_name
                        FROM information_schema.columns
                        WHERE table_schema = %s AND table_name = %s
                        ORDER BY ordinal_position
                        """,
                        (safe_schema, table_name),
                    )
                    columns = [str(row[0]) for row in cur.fetchall()]

                with conn.cursor() as cur:
                    cur.execute(
                        sql.SQL("SELECT COUNT(*) FROM {}.{}").format(
                            sql.Identifier(safe_schema),
                            sql.Identifier(table_name),
                        )
                    )
                    row_count = int(cur.fetchone()[0])

                sampled_rows: list[dict[str, Any]] = []
                if sample_rows > 0:
                    with conn.cursor() as cur:
                        cur.execute(
                            sql.SQL("SELECT * FROM {}.{} LIMIT {}").format(
                                sql.Identifier(safe_schema),
                                sql.Identifier(table_name),
                                sql.Literal(sample_rows),
                            )
                        )
                        raw_rows = cur.fetchall()
                        if cur.description:
                            result_columns = [desc.name for desc in cur.description]
                            for row in raw_rows:
                                sampled_rows.append(
                                    {
                                        key: ("" if value is None else str(value))
                                        for key, value in zip(result_columns, row)
                                    }
                                )

                serialized = json.dumps(sampled_rows)
                account_id_hits = len(re.findall(r"ACCT[_-]?\d+", serialized, flags=re.IGNORECASE))
                sensitive_columns_found = [
                    col for col in columns if col and col.lower() in SENSITIVE_TRADE_COLUMNS
                ]

                profiles.append(
                    {
                        "asset_path": f"postgres://{safe_schema}.{table_name}",
                        "asset_name": f"{safe_schema}.{table_name}",
                        "suffix": ".table",
                        "asset_type": "postgres_table",
                        "source_type": "postgres",
                        "columns": columns,
                        "row_count": row_count,
                        "sample_rows": sampled_rows[:2],
                        "account_id_hits": account_id_hits,
                        "sensitive_columns_found": sensitive_columns_found,
                        "preview": json.dumps(sampled_rows[:1])[:800],
                        "text_signals": {},
                    }
                )
    except Exception:
        return []

    return profiles


