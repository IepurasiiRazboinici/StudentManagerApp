import csv
import json
import re
from datetime import date
from pathlib import Path
from typing import Any

from .constants import AMBIGUITY_MARKERS, DERIVED_FID_NAMES, SENSITIVE_TRADE_COLUMNS


def resolve_assets(root: Path, asset_paths: list[str]) -> list[Path]:
    if asset_paths:
        resolved = []
        for path_value in asset_paths:
            candidate = Path(path_value)
            if not candidate.is_absolute():
                candidate = root / candidate
            if candidate.exists() and candidate.is_file():
                resolved.append(candidate)
        return sorted(resolved)

    if not root.exists():
        return []

    return sorted([path for path in root.rglob("*") if path.is_file()])


def profile_asset(asset: Path, root: Path, today: date) -> dict[str, Any]:
    suffix = asset.suffix.lower()
    rel_path = asset.relative_to(root).as_posix() if asset.is_relative_to(root) else str(asset)
    profile: dict[str, Any] = {
        "asset_path": rel_path,
        "asset_name": asset.name,
        "suffix": suffix,
        "asset_type": asset_type_from_suffix(suffix),
        "size_bytes": asset.stat().st_size,
        "today": str(today),
    }

    if asset.name in {"trades.csv", "trades_sample.csv"}:
        profile.update(profile_trades_csv(asset))
    elif suffix == ".csv":
        profile.update(profile_csv(asset))
    elif asset.name == "market-data-usa.log":
        profile.update(profile_market_data_log(asset))
    elif asset.name == "reuters.fids":
        profile.update(profile_fids(asset))
    elif suffix == ".md":
        profile.update(profile_markdown(asset))
    elif suffix == ".txt":
        profile.update(profile_text(asset))
    else:
        profile.update(profile_text(asset, max_chars=3500))

    return profile


def asset_type_from_suffix(suffix: str) -> str:
    if suffix == ".csv":
        return "csv"
    if suffix == ".md":
        return "markdown"
    if suffix in {".txt", ".log", ".fids"}:
        return "text"
    return "file"


def profile_trades_csv(asset: Path) -> dict[str, Any]:
    return profile_csv(asset)


def profile_csv(asset: Path) -> dict[str, Any]:
    row_count = 0
    account_id_hits = 0
    columns: list[str] = []
    sensitive_columns_found: list[str] = []
    sample_rows: list[dict[str, str]] = []

    with asset.open("r", encoding="utf-8", errors="ignore", newline="") as handle:
        reader = csv.DictReader(handle)
        columns = reader.fieldnames or []
        sensitive_columns_found = [col for col in columns if col and col.lower() in SENSITIVE_TRADE_COLUMNS]
        for row in reader:
            row_count += 1
            serialized = json.dumps(row)
            account_id_hits += len(re.findall(r"ACCT[_-]?\d+", serialized, flags=re.IGNORECASE))
            if len(sample_rows) < 2:
                top_keys = list(row.keys())[:3]
                sample_rows.append({key: row.get(key, "") for key in top_keys if key})

    return {
        "row_count": row_count,
        "columns": columns,
        "account_id_hits": account_id_hits,
        "sensitive_columns_found": sensitive_columns_found,
        "sample_rows": sample_rows,
    }


def profile_market_data_log(asset: Path) -> dict[str, Any]:
    total_lines = 0
    instrument_count = 0
    dot_o_instruments = set()
    derived_presence: dict[str, int] = {fid: 0 for fid in DERIVED_FID_NAMES}
    derived_non_empty: dict[str, int] = {fid: 0 for fid in DERIVED_FID_NAMES}

    pattern = re.compile(r"DATALOG\s*-\s*([^,]+),(.*)$")
    with asset.open("r", encoding="utf-8", errors="ignore") as handle:
        for line in handle:
            total_lines += 1
            match = pattern.search(line)
            if not match:
                continue
            instrument_count += 1
            ric = match.group(1).strip()
            is_dot_o = ".O" in ric
            if is_dot_o:
                dot_o_instruments.add(ric)

            for token in match.group(2).split(","):
                if "=" not in token:
                    continue
                fid, raw_value = token.split("=", 1)
                fid = fid.strip()
                value = raw_value.strip()
                if fid in DERIVED_FID_NAMES and is_dot_o:
                    derived_presence[fid] += 1
                    if value:
                        derived_non_empty[fid] += 1

    return {
        "line_count": total_lines,
        "instrument_count": instrument_count,
        "dot_o_instrument_count": len(dot_o_instruments),
        "derived_fid_presence": derived_presence,
        "derived_fid_non_empty": derived_non_empty,
    }


def profile_fids(asset: Path) -> dict[str, Any]:
    text = asset.read_text(encoding="utf-8", errors="ignore")
    fid_count = len(re.findall(r"\b\d{1,7}\b", text))
    return {
        "fid_reference_entries": fid_count,
        "contains_vwap": "VWAP" in text,
        "contains_theoretical_fields": "THEO_PRC" in text and "THEO_VOL" in text,
    }


def profile_markdown(asset: Path) -> dict[str, Any]:
    text = asset.read_text(encoding="utf-8", errors="ignore")
    return profile_document_text(text)


def profile_text(asset: Path, max_chars: int = 6000) -> dict[str, Any]:
    text = asset.read_text(encoding="utf-8", errors="ignore")
    if len(text) > max_chars:
        text = text[:max_chars]
    return profile_document_text(text)


def profile_document_text(text: str) -> dict[str, Any]:
    status_match = re.search(r"\*\*Status:\*\*\s*(.+)", text)
    publish_match = re.search(r"\*\*Published Date:\*\*\s*(\d{4}-\d{2}-\d{2})", text)
    schedule_match = re.search(r"\*\*Scheduled Publish Date:\*\*\s*(\d{4}-\d{2}-\d{2})", text)

    lower_text = text.lower()
    signals = {
        "contains_internal_only": "internal only" in lower_text,
        "contains_not_yet_published": "not yet published" in lower_text,
        "contains_public_distribution": "distribution: public" in lower_text,
        "contains_do_not_distribute": "do not distribute" in lower_text,
        "contains_draft_marker": "draft" in lower_text or "embargo" in lower_text,
        "contains_published_marker": "published" in lower_text,
        "contains_audited_marker": "audited" in lower_text,
        "contains_press_release_marker": "press release" in lower_text or "investor relations" in lower_text,
        "contains_tribal_knowledge_marker": any(marker in lower_text for marker in AMBIGUITY_MARKERS),
        "contains_explicit_restricted_marker": bool(re.search(r"\b(confidential|restricted)\b", lower_text)),
        "contains_explicit_highly_restricted_marker": bool(re.search(r"\b(highly confidential|highly restricted)\b", lower_text)),
    }

    return {
        "preview": text[:800],
        "status": status_match.group(1).strip() if status_match else None,
        "published_date": publish_match.group(1) if publish_match else None,
        "scheduled_publish_date": schedule_match.group(1) if schedule_match else None,
        "text_signals": signals,
    }

