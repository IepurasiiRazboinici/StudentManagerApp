import os
import tempfile
from datetime import UTC, date, datetime
from pathlib import Path
from typing import Any, Optional

from .constants import DEFAULT_DATA_DIR, DEFAULT_LLM_BEARER_TOKEN, DEFAULT_LLM_ENDPOINT
from .custom_rules import get_matching_rules_for_asset, map_target_tier
from .llm_client import classify_with_external_llm, convert_llm_evidence_to_items, merge_classification_results
from .models import (
    AssetClassification,
    ClassifyRequest,
    ClassifyResponse,
    CustomRuleMatch,
    EvidenceItem,
    ReviewDecisionRequest,
    SourceClassification,
    TAXONOMY,
)
from .postgres import discover_and_profile_postgres_tables
from .profiling import profile_asset, resolve_assets
from .review_memory import build_review_key, find_memory_examples, parse_memory_classification, record_decision
from .rules import classify_with_rules
from .utils import normalize_classification_label, normalize_confidence


def resolve_llm_config(request_body: ClassifyRequest) -> tuple[Optional[str], Optional[str]]:
    """Resolve the LLM endpoint/token to use, preferring (in order): the request
    body, environment variables, then the hardcoded defaults in constants.py.

    Hardcoding the defaults means the ONLY configuration required to enable
    end-to-end AI classification is updating DEFAULT_LLM_ENDPOINT /
    DEFAULT_LLM_BEARER_TOKEN in classifier/constants.py (or setting the
    CLASSIFIER_LLM_ENDPOINT / CLASSIFIER_LLM_BEARER_TOKEN env vars).
    """
    llm_endpoint = request_body.llm_endpoint or os.getenv("CLASSIFIER_LLM_ENDPOINT") or DEFAULT_LLM_ENDPOINT
    llm_bearer_token = request_body.llm_bearer_token or os.getenv("CLASSIFIER_LLM_BEARER_TOKEN") or DEFAULT_LLM_BEARER_TOKEN
    return llm_endpoint, llm_bearer_token


def classify_discovered_request(request_body: ClassifyRequest) -> ClassifyResponse:
    root = Path(request_body.data_root) if request_body.data_root else DEFAULT_DATA_DIR
    today = request_body.current_date or date.today()
    llm_endpoint, llm_bearer_token = resolve_llm_config(request_body)

    assets = resolve_assets(root, request_body.asset_paths)
    file_results = classify_assets(
        assets=assets,
        root=root,
        today=today,
        request_body=request_body,
        llm_endpoint=llm_endpoint,
        llm_bearer_token=llm_bearer_token,
    )

    postgres_results: list[AssetClassification] = []
    if request_body.postgres_dsn:
        db_profiles = discover_and_profile_postgres_tables(
            dsn=request_body.postgres_dsn,
            schema=request_body.postgres_schema,
            requested_tables=request_body.postgres_tables,
            sample_rows=request_body.postgres_sample_rows,
        )
        postgres_results = classify_profiles(
            profiles=db_profiles,
            today=today,
            request_body=request_body,
            llm_endpoint=llm_endpoint,
            llm_bearer_token=llm_bearer_token,
        )

    results = [*file_results, *postgres_results]
    return build_response(results, discovered_assets=len(assets) + len(postgres_results))


def classify_uploaded_content(filename: str, content: bytes, request_body: ClassifyRequest) -> ClassifyResponse:
    today = request_body.current_date or date.today()
    llm_endpoint, llm_bearer_token = resolve_llm_config(request_body)

    with tempfile.TemporaryDirectory(prefix="uploaded-classify-") as temp_dir:
        temp_root = Path(temp_dir)
        target_path = temp_root / Path(filename or "uploaded_asset").name
        target_path.write_bytes(content)
        results = classify_assets(
            assets=[target_path],
            root=temp_root,
            today=today,
            request_body=request_body,
            llm_endpoint=llm_endpoint,
            llm_bearer_token=llm_bearer_token,
        )

    return build_response(results, discovered_assets=len(results))


def classify_assets(
    assets: list[Path],
    root: Path,
    today: date,
    request_body: ClassifyRequest,
    llm_endpoint: Optional[str],
    llm_bearer_token: Optional[str],
) -> list[AssetClassification]:
    profiles = [profile_asset(asset, root, today) for asset in assets]
    return classify_profiles(
        profiles=profiles,
        today=today,
        request_body=request_body,
        llm_endpoint=llm_endpoint,
        llm_bearer_token=llm_bearer_token,
    )


def classify_profiles(
    profiles: list[dict],
    today: date,
    request_body: ClassifyRequest,
    llm_endpoint: Optional[str],
    llm_bearer_token: Optional[str],
) -> list[AssetClassification]:
    results: list[AssetClassification] = []
    for profile in profiles:
        rule_result = classify_with_rules(profile, today)
        review_key = build_review_key(profile)
        rule_result = rule_result.model_copy(update={"review_key": review_key})

        rule_snapshot = SourceClassification(
            classification=rule_result.classification,
            confidence=rule_result.confidence,
            explanation=rule_result.explanation,
            confidence_reasoning=rule_result.confidence_reasoning,
            evidence=list(rule_result.evidence),
        )

        # Fold in any user-defined classification rules (`/api/classification-rules`)
        # that match this asset. A matched custom rule is authoritative for its
        # target tier (mirroring how explicit policy markers work in rules.py) —
        # when several rules match and disagree, the highest-priority/highest-
        # confidence rule wins. All matches are also forwarded to the external LLM
        # below so it takes them into account too.
        explicit_policy_signals = {
            "explicit_highly_restricted_marker",
            "explicit_restricted_marker",
            "explicit_internal_marker",
            "explicit_public_marker",
            "pre_release_mnpi",
            "published_public_release",
        }
        explicit_policy_applied = any(item.signal in explicit_policy_signals for item in rule_result.evidence)

        matched_custom_rules = get_matching_rules_for_asset(profile)
        custom_rule_matches: list[CustomRuleMatch] = []
        llm_classification_rules: list[dict[str, Any]] = []
        if matched_custom_rules:
            # Matches the frontend's RulePriority values (RuleForm.tsx): NORMAL/HIGH/CRITICAL.
            # Also tolerates MEDIUM/LOW in case a rule is created directly via the API.
            _PRIORITY_RANK = {"CRITICAL": 4, "HIGH": 3, "NORMAL": 2, "MEDIUM": 2, "LOW": 1}
            combined_evidence = list(rule_result.evidence)
            force_review = False
            review_reasons: list[str] = []
            winner: Optional[dict[str, Any]] = None
            winner_level: Optional[Any] = None
            winner_rank = (-1, -1)

            for rule in matched_custom_rules:
                target_level = map_target_tier(str(rule.get("targetTier", "")))
                if target_level is None:
                    continue
                matched_fields = rule.get("matchedFields", [])
                explanation_text = str(rule.get("explanationTemplate") or "").strip() or (
                    f'Custom rule "{rule.get("name")}" matched this asset.'
                )
                combined_evidence.append(
                    EvidenceItem(
                        signal="custom_rule_match",
                        detail=f"{explanation_text} (matched: {', '.join(matched_fields) or 'n/a'})"[:500],
                        source=f"custom_rule:{rule.get('id')}",
                    )
                )
                if rule.get("requireHumanReview"):
                    force_review = True
                    review_reasons.append(f'Custom rule "{rule.get("name")}" requires human review.')

                confidence_value = int(rule.get("confidence", 50))
                rank = (_PRIORITY_RANK.get(str(rule.get("priority", "")).upper(), 0), confidence_value)
                if rank > winner_rank:
                    winner_rank = rank
                    winner = rule
                    winner_level = target_level

                custom_rule_matches.append(
                    CustomRuleMatch(
                        rule_id=str(rule.get("id")),
                        rule_name=str(rule.get("name")),
                        target_classification=target_level,
                        confidence=confidence_value,
                        priority=str(rule.get("priority", "MEDIUM")),
                        require_human_review=bool(rule.get("requireHumanReview")),
                        matched_fields=[str(f) for f in matched_fields],
                        explanation=explanation_text,
                    )
                )
                llm_classification_rules.append(
                    {
                        "id": rule.get("id"),
                        "name": rule.get("name"),
                        "description": rule.get("description"),
                        "matched_fields": matched_fields,
                        "target_classification": target_level.value,
                        "confidence": round(confidence_value / 100, 2),
                        "priority": rule.get("priority"),
                        "require_human_review": rule.get("requireHumanReview"),
                    }
                )

            update: dict[str, Any] = {"evidence": combined_evidence}
            if winner_level is not None and not explicit_policy_applied:
                update["classification"] = winner_level
                update["explanation"] = (
                    f'{rule_result.explanation} Overridden by custom rule "{winner.get("name")}": '
                    f"{str(winner.get('explanationTemplate') or '').strip()}"
                ).strip()
            if force_review:
                existing_review = rule_result.human_review
                combined_reason = "; ".join([r for r in [existing_review.reason, *review_reasons] if r])
                update["human_review"] = existing_review.model_copy(
                    update={"required": True, "reason": combined_reason, "suggested_action": "review_and_approve"}
                )
            rule_result = rule_result.model_copy(update=update)

        exact_memory, remembered_examples = find_memory_examples(review_key, profile)

        ai_attempted = bool(request_body.use_llm and llm_endpoint)
        ai_snapshot: Optional[SourceClassification] = None

        llm_result = None
        llm_raw_output: Optional[str] = None
        llm_error: Optional[str] = None
        if request_body.use_llm and llm_endpoint:
            llm_result, llm_raw_output, llm_error = classify_with_external_llm(
                endpoint=llm_endpoint,
                bearer_token=llm_bearer_token,
                timeout_seconds=request_body.llm_timeout_seconds,
                max_tokens=request_body.llm_max_tokens,
                prompt=request_body.prompt,
                profile=profile,
                additional_payload=request_body.llm_additional_payload,
                remembered_examples=remembered_examples,
                classification_rules=llm_classification_rules,
            )

            if llm_result is None:
                llm_evidence = list(rule_result.evidence)
                detail = "LLM endpoint was called, but response could not be parsed into classification JSON."
                if llm_error:
                    detail = f"LLM endpoint call failed: {llm_error}"
                llm_evidence.append(
                    EvidenceItem(
                        signal="llm_call_no_usable_payload",
                        detail=detail,
                        source="external_llm",
                    )
                )
                rule_result = rule_result.model_copy(update={"evidence": llm_evidence})
            else:
                ai_label = normalize_classification_label(str(llm_result.get("classification", "")))
                if ai_label:
                    ai_snapshot = SourceClassification(
                        classification=ai_label,
                        confidence=normalize_confidence(llm_result.get("confidence")),
                        explanation=str(llm_result.get("explanation", "")).strip()
                        or "The model did not return an explanation.",
                        confidence_reasoning=str(llm_result.get("confidence_reasoning") or "").strip() or None,
                        evidence=convert_llm_evidence_to_items(
                            llm_result.get("evidence") if isinstance(llm_result.get("evidence"), list) else []
                        ),
                    )

        merged = merge_classification_results(rule_result, llm_result)
        classification_source = "rules"
        if ai_snapshot is not None:
            classification_source = (
                "agreement" if ai_snapshot.classification == rule_snapshot.classification else "conflict"
            )
        merged = merged.model_copy(
            update={
                "review_key": review_key,
                "rule_classification": rule_snapshot,
                "ai_classification": ai_snapshot,
                "ai_attempted": ai_attempted,
                "ai_used": ai_snapshot is not None,
                "classification_source": classification_source,
                # Always propagate raw LLM output/error, regardless of whether it
                # parsed into a structured classification or how it merged with
                # the deterministic rules, so the frontend can always show it.
                "ai_raw_output": llm_raw_output,
                "ai_error": llm_error,
                "custom_rule_matches": custom_rule_matches,
            }
        )

        if exact_memory:
            memory_label = parse_memory_classification(str(exact_memory.get("corrected_classification", "")))
            if memory_label:
                memory_evidence = list(merged.evidence)
                memory_note = str(exact_memory.get("reviewer_note") or "").strip()
                memory_evidence.append(
                    EvidenceItem(
                        signal="human_review_memory",
                        detail=f"Applied stored reviewer decision ({memory_label.value}). Note: {memory_note[:240]}",
                        source="review_memory.json",
                    )
                )
                merged = merged.model_copy(
                    update={
                        "classification": memory_label,
                        "confidence": 0.99,
                        "evidence": memory_evidence,
                    }
                )

        results.append(merged)

    return results


def build_distribution(results: list[AssetClassification]) -> dict[str, int]:
    distribution: dict[str, int] = {}
    for item in results:
        distribution[item.classification.value] = distribution.get(item.classification.value, 0) + 1
    return distribution


def build_response(results: list[AssetClassification], discovered_assets: int) -> ClassifyResponse:
    return ClassifyResponse(
        generated_at=datetime.now(UTC),
        taxonomy=TAXONOMY,
        discovered_assets=discovered_assets,
        results=results,
        distribution=build_distribution(results),
    )


def submit_review_decision(review: ReviewDecisionRequest) -> dict[str, str]:
    saved = record_decision(review)
    return {
        "review_key": str(saved.get("review_key", "")),
        "corrected_classification": str(saved.get("corrected_classification", "")),
    }


