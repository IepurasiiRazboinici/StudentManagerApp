from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[2]
_PRIMARY_DATA_DIR = _REPO_ROOT / "data-discovery-classification-hackathon-main" / "data-discovery-classification-hackathon-main"
_FALLBACK_DATA_DIR = _REPO_ROOT / "data_discovery_classification_repo"

# Some checkouts of this project use the original hackathon folder name, others
# (like this repo) vendor the same sample assets under `data_discovery_classification_repo`.
# Prefer the former for backward compatibility, but fall back to whichever one
# actually exists on disk so discovery/rule-matching still works either way.
DEFAULT_DATA_DIR = _PRIMARY_DATA_DIR if _PRIMARY_DATA_DIR.exists() else _FALLBACK_DATA_DIR

DERIVED_FID_NAMES = {"3404": "VWAP", "3396": "THEO_PRC", "4107": "THEO_VOL"}

# Hardcoded default LLM connection for this hackathon project.
#
# These are used whenever a classify request does not explicitly provide
# `llm_endpoint` / `llm_bearer_token`, and the `CLASSIFIER_LLM_ENDPOINT` /
# `CLASSIFIER_LLM_BEARER_TOKEN` environment variables are not set. This is the
# ONLY configuration needed to enable end-to-end AI/LLM classification: update
# the two values below to point at your own LLM service.
DEFAULT_LLM_ENDPOINT = "https://genai-service-builder.int.refinitiv.com/api/v1/services/hackathonanalyzer2/analyzer2"
DEFAULT_LLM_BEARER_TOKEN = "gsb-gBjN68CbsgDAe2hQ5VJacVFbWIqU1kMZYt8C88GyCrC7lpv9XfNssVY9Jirx7Md-U7GNra9-f8pcS9fRsT3_4w"

SENSITIVE_TRADE_COLUMNS = {
    "execid",
    "ownergroup",
    "fundallocation",
    "totalfundallocation",
    "lastshares",
    "lastpx",
    "executionexchange",
}

AMBIGUITY_MARKERS = [
    "tribal knowledge",
    "not fully documented",
    "not sure",
    "not sure if still maintained",
    "never found a clean legend",
    "incomplete",
]


REVIEW_MEMORY_FILE = Path(__file__).resolve().parents[1] / "review_memory.json"

# Persisted store for user-defined classification rules (see classifier/custom_rules.py).
# Kept alongside review_memory.json so both survive backend restarts without a DB.
CLASSIFICATION_RULES_FILE = Path(__file__).resolve().parents[1] / "classification_rules.json"


