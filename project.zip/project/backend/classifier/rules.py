import re
from datetime import date
from typing import Any, Optional

from .constants import DERIVED_FID_NAMES
from .models import AssetClassification, ClassificationLevel, EvidenceItem, HumanReviewRecommendation
from .utils import more_restrictive, parse_iso_date


def classify_with_rules(profile: dict[str, Any], today: date) -> AssetClassification:
    asset_name = profile["asset_name"]
    asset_path = profile["asset_path"]
    asset_type = profile["asset_type"]
    evidence: list[EvidenceItem] = []
    references: list[str] = []
    overrides: list[dict[str, Any]] = []
    review_reasons: list[str] = []
    candidate_levels: list[ClassificationLevel] = []
    explicit_levels: list[ClassificationLevel] = []

    def add_candidate(level: ClassificationLevel, signal: str, detail: str, ref: Optional[str] = None) -> None:
        candidate_levels.append(level)
        evidence.append(EvidenceItem(signal=signal, detail=detail, source=asset_path))
        if ref:
            references.append(ref)

    signals = profile.get("text_signals", {})
    preview = (profile.get("preview") or "").lower()

    if signals.get("contains_explicit_highly_restricted_marker"):
        explicit_levels.append(ClassificationLevel.HIGHLY_RESTRICTED)
        evidence.append(EvidenceItem(
            signal="explicit_highly_restricted_marker",
            detail="Document includes explicit 'highly restricted/confidential' style marker.",
            source=asset_path,
        ))
    if signals.get("contains_explicit_restricted_marker"):
        explicit_levels.append(ClassificationLevel.RESTRICTED)
        evidence.append(EvidenceItem(
            signal="explicit_restricted_marker",
            detail="Document includes explicit restricted/confidential marker.",
            source=asset_path,
        ))
    if signals.get("contains_internal_only"):
        explicit_levels.append(ClassificationLevel.CORPORATE)
        evidence.append(EvidenceItem(
            signal="explicit_internal_marker",
            detail="Document explicitly says 'Internal only'.",
            source=asset_path,
        ))
    if signals.get("contains_public_distribution"):
        explicit_levels.append(ClassificationLevel.PUBLIC)
        evidence.append(EvidenceItem(
            signal="explicit_public_marker",
            detail="Document explicitly marks distribution as public.",
            source=asset_path,
        ))

    published_value = profile.get("published_date")
    scheduled_value = profile.get("scheduled_publish_date")
    parsed_published = parse_iso_date(published_value)
    parsed_scheduled = parse_iso_date(scheduled_value)
    is_pre_release_financial = (
        signals.get("contains_draft_marker")
        or signals.get("contains_not_yet_published")
        or signals.get("contains_do_not_distribute")
        or (parsed_scheduled and parsed_scheduled > today)
    )
    is_published_release = (
        signals.get("contains_published_marker")
        and (parsed_published is None or parsed_published <= today)
        and (
            signals.get("contains_audited_marker")
            or signals.get("contains_press_release_marker")
            or signals.get("contains_public_distribution")
        )
    )

    if is_pre_release_financial:
        explicit_levels.append(ClassificationLevel.HIGHLY_RESTRICTED)
        evidence.append(EvidenceItem(
            signal="pre_release_mnpi",
            detail="Pre-release financial markers detected; treat as MNPI until publication.",
            source=asset_path,
        ))
        references.append("README.md#sample-financial-reports-time-based-classification")
    elif is_published_release:
        explicit_levels.append(ClassificationLevel.PUBLIC)
        evidence.append(EvidenceItem(
            signal="published_public_release",
            detail="Published/audited external release markers detected.",
            source=asset_path,
        ))
        references.append("README.md#sample-financial-reports-time-based-classification")

    account_hits = int(profile.get("account_id_hits", 0) or 0)
    sensitive_columns = profile.get("sensitive_columns_found", [])
    if account_hits > 0 or sensitive_columns:
        add_candidate(
            ClassificationLevel.HIGHLY_RESTRICTED,
            "account_client_fund_identifiers",
            f"Detected account/fund-sensitive signals (account hits={account_hits}, columns={sensitive_columns}).",
            "README.md#classifying-the-sample-data-reference",
        )
    if any(keyword in preview for keyword in ["fundallocation", "totalfundallocation", "ownergroup", "execid"]):
        add_candidate(
            ClassificationLevel.HIGHLY_RESTRICTED,
            "trade_allocation_terms",
            "Trade/allocation identifiers in content indicate client/fund-level sensitivity.",
            "README.md#classifying-the-sample-data-reference",
        )

    if asset_name == "market-data-usa.log":
        add_candidate(
            ClassificationLevel.CORPORATE,
            "vendor_feed_dump",
            "Raw vendor feed dump is internal by default.",
            "README.md#classifying-the-sample-data-reference",
        )
        derived_presence = profile.get("derived_fid_presence", {})
        derived_non_empty = profile.get("derived_fid_non_empty", {})
        derived_hits: list[str] = []
        for fid, field_name in DERIVED_FID_NAMES.items():
            if derived_presence.get(fid, 0):
                derived_hits.append(
                    f"{field_name}({fid}) present={derived_presence.get(fid, 0)}, non_empty={derived_non_empty.get(fid, 0)}"
                )

        if derived_hits and profile.get("dot_o_instrument_count", 0) > 0:
            add_candidate(
                ClassificationLevel.RESTRICTED,
                "licensed_derived_fields_restricted",
                "Licensed/derived vendor fields are present and require Restricted handling for distribution.",
                "knowledge-base/confluence-nasdaq-derived-fields-licensing.md",
            )
            evidence.append(EvidenceItem(
                signal="licensed_derived_fields",
                detail="Derived vendor fields found on .O instruments: " + "; ".join(derived_hits[:3]),
                source=asset_path,
            ))
            references.append("knowledge-base/confluence-nasdaq-derived-fields-licensing.md")
            overrides.append(
                {
                    "scope": "field_level",
                    "classification": ClassificationLevel.RESTRICTED.value,
                    "fields": [name for name in DERIVED_FID_NAMES.values() if any(name in hit for hit in derived_hits)],
                    "reason": "Strip or mask licensed derived fields for lower-tier external use.",
                }
            )
            review_reasons.append(
                "Field-level licensing restrictions detected; confirm masking/stripping strategy before external sharing."
            )

    if asset_name == "reuters.fids" or asset_path.startswith("knowledge-base/"):
        add_candidate(
            ClassificationLevel.CORPORATE,
            "internal_reference_policy_doc",
            "Schema/reference/policy documentation classified as Corporate.",
            "README.md#classifying-the-sample-data-reference",
        )

    if re.search(r"\b(password|secret|private key|token)\b", preview):
        add_candidate(
            ClassificationLevel.HIGHLY_RESTRICTED,
            "security_credential_terms",
            "Potential credential/security-critical terms found.",
        )

    if signals.get("contains_tribal_knowledge_marker"):
        review_reasons.append("Ambiguity/tribal-knowledge markers detected; data steward review is mandatory.")
        evidence.append(EvidenceItem(
            signal="ambiguity_marker",
            detail="Notes indicate incomplete/tribal documentation requiring human validation.",
            source=asset_path,
        ))

    explicit_level: Optional[ClassificationLevel] = None
    if explicit_levels:
        explicit_level = explicit_levels[0]
        for level in explicit_levels[1:]:
            explicit_level = more_restrictive(explicit_level, level)
        if len({level.value for level in explicit_levels}) > 1:
            review_reasons.append("Conflicting explicit status/distribution markers detected.")

    fallback_level = (
        ClassificationLevel.RESTRICTED
        if asset_type in {"csv", "text", "postgres_table"}
        else ClassificationLevel.CORPORATE
    )
    chosen_level = fallback_level
    if explicit_level is not None:
        chosen_level = explicit_level
    elif candidate_levels:
        chosen_level = candidate_levels[0]
        for level in candidate_levels[1:]:
            chosen_level = more_restrictive(chosen_level, level)
    else:
        evidence.append(EvidenceItem(
            signal="conservative_default",
            detail="No decisive rule hit; defaulting to conservative classification.",
            source=asset_path,
        ))
        review_reasons.append("No strong policy signal found; conservative default requires reviewer confirmation.")

    if explicit_level is not None:
        confidence = 0.97
        explanation = "Explicit status/distribution markers were present, so the explicit policy tier is applied directly."
    elif review_reasons:
        confidence = 0.84
        explanation = "Classification uses conservative policy rules with mandatory follow-up review."
    else:
        confidence = 0.9
        explanation = "Classification is based on deterministic policy rules and supporting evidence."

    result: AssetClassification = build_result(
        asset_path,
        asset_type,
        chosen_level,
        confidence,
        evidence,
        references,
        explanation,
        overrides,
        forced_review_reason="; ".join(review_reasons) if review_reasons else None,
    )
    return result


def build_result(
    asset_path: str,
    asset_type: str,
    classification: ClassificationLevel,
    confidence: float,
    evidence: list[EvidenceItem],
    references: list[str],
    explanation: str,
    field_overrides: list[dict[str, Any]],
    forced_review_reason: Optional[str] = None,
) -> AssetClassification:
    review_required = confidence < 0.8 or bool(field_overrides) or bool(forced_review_reason)
    review_reason = forced_review_reason
    if not review_reason and confidence < 0.8:
        review_reason = "Low confidence; reviewer should confirm classification."
    elif not review_reason and field_overrides:
        review_reason = "Field-level overrides detected; confirm downstream sharing controls."

    return AssetClassification(
        asset_path=asset_path,
        asset_type=asset_type,
        classification=classification,
        confidence=round(confidence, 3),
        evidence=evidence,
        guidance_references=references,
        explanation=explanation,
        human_review=HumanReviewRecommendation(
            required=review_required,
            reason=review_reason,
            suggested_action="review_and_approve" if review_required else "approve",
        ),
        field_overrides=field_overrides,
    )

