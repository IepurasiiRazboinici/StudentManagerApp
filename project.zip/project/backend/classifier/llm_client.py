import json
from typing import Any, Optional
from urllib import error, request

from .models import AssetClassification, EvidenceItem, RemediationSuggestion
from .models import ClassificationLevel
from .models import HumanReviewRecommendation
from .utils import more_restrictive, normalize_classification_label, normalize_confidence


def classify_with_external_llm(
    endpoint: str,
    bearer_token: Optional[str],
    timeout_seconds: int,
    max_tokens: int,
    prompt: Optional[str],
    profile: dict[str, Any],
    additional_payload: dict[str, Any],
    remembered_examples: list[dict[str, Any]] | None = None,
    classification_rules: list[dict[str, Any]] | None = None,
) -> tuple[Optional[dict[str, Any]], Optional[str], Optional[str]]:
    """Call the external LLM and return `(classification_payload, raw_output, error)`.

    `classification_payload` is the structured dict used for merging with the rule
    engine, and is `None` whenever the model's response couldn't be parsed into a
    classification. `raw_output` and `error` are captured independently so the
    caller can ALWAYS show the model's actual output (or failure reason) to the
    user, regardless of whether structured parsing succeeded or of what the
    deterministic rules decided.
    """
    instruction = prompt or (
        "Classify the asset into one of: Public, Corporate, Restricted, Highly Restricted. "
        "Return JSON with keys classification, confidence, explanation, evidence. "
        "Be extremely concise so the full JSON response fits in a small output budget: "
        "limit evidence to at most 2 items, limit remediation_suggestions to at most 2 items, "
        "and keep every text field (explanation, confidence_reasoning, detail, reason) "
        "under 200 characters. Do not include any text before or after the JSON object."
    )

    memory_context = _build_memory_context(remembered_examples or [])
    if memory_context:
        instruction = f"{instruction}\n\nUse remembered human decisions as additional guidance:\n{memory_context}"

    if classification_rules:
        instruction = (
            f"{instruction}\n\nThe caller has already matched the classification_rules below against this "
            "asset. Treat each as an authoritative override for its target_classification unless an explicit "
            "stricter marker is found in the asset itself; cite the rule's name in an evidence item with "
            "signal \"custom_rule_match\"."
        )

    inner_payload = {
        "prompt": instruction,
        "asset": profile,
        "taxonomy": [
            ClassificationLevel.PUBLIC.value,
            ClassificationLevel.CORPORATE.value,
            ClassificationLevel.RESTRICTED.value,
            ClassificationLevel.HIGHLY_RESTRICTED.value,
        ],
        "max_tokens": max_tokens,
        "remembered_examples": remembered_examples or [],
    }

    if classification_rules:
        inner_payload["classification_rules"] = classification_rules

    if additional_payload:
        inner_payload.update(additional_payload)

    # The hosted analyzer service's prompt template substitutes the entire
    # request body into a single "{{ input1 }}" placeholder in its user turn,
    # rather than reading top-level keys like "asset"/"prompt" directly.
    # See service system prompt: it expects one wrapped object under "input1".
    #
    # The service ALSO reads a top-level "max_tokens" to cap its own generation
    # length (confirmed via the hosted service's example request:
    # `{"max_tokens":100,"input1":""}`) — this is independent from the
    # `max_tokens` mirrored inside `input1` above (which is only descriptive
    # context for the model's own instructions).
    payload = {"input1": inner_payload, "max_tokens": max_tokens}

    headers = {"Content-Type": "application/json"}
    if bearer_token:
        headers["Authorization"] = f"Bearer {bearer_token}"

    req = request.Request(
        endpoint,
        data=json.dumps(payload).encode("utf-8"),
        headers=headers,
        method="POST",
    )

    try:
        with request.urlopen(req, timeout=timeout_seconds) as response:
            body = response.read().decode("utf-8")
    except (error.URLError, TimeoutError) as exc:
        return None, None, f"LLM request failed: {exc}"

    try:
        result = json.loads(body)
    except (json.JSONDecodeError, ValueError):
        # Not even valid JSON — still surface the raw body so the reviewer can see
        # exactly what the model returned instead of a silent fallback.
        return None, body[:4000] if body else None, None

    payload = extract_llm_response_payload(result)
    raw_output = _extract_raw_text_for_display(result)
    return payload, raw_output, None


def _extract_raw_text_for_display(result: Any) -> Optional[str]:
    """Best-effort extraction of human-readable text from the LLM response, used
    purely for transparency/debugging display — independent of whether the text
    could be parsed into a structured classification payload."""
    if isinstance(result, dict):
        choices = result.get("choices")
        if isinstance(choices, list):
            texts: list[str] = []
            for choice in choices:
                if not isinstance(choice, dict):
                    continue
                message = choice.get("message")
                if isinstance(message, dict):
                    content_text = _extract_content_text(message.get("content"))
                    if content_text:
                        texts.append(content_text)
                content_text = _extract_content_text(choice.get("content"))
                if content_text:
                    texts.append(content_text)
            if texts:
                return "\n".join(texts)[:4000]

        for key in ("output", "result", "response", "text", "message"):
            value = result.get(key)
            if isinstance(value, str) and value.strip():
                return value[:4000]

        content_text = _extract_content_text(result.get("content"))
        if content_text:
            return content_text[:4000]

    try:
        return json.dumps(result, indent=2)[:4000]
    except (TypeError, ValueError):
        return str(result)[:4000]


def _build_memory_context(remembered_examples: list[dict[str, Any]]) -> str:
    if not remembered_examples:
        return ""
    lines = []
    for idx, example in enumerate(remembered_examples[:3], start=1):
        label = example.get("corrected_classification", "Unknown")
        note = str(example.get("reviewer_note") or "").strip()
        key = example.get("review_key", "n/a")
        lines.append(f"{idx}. key={key}; corrected_classification={label}; note={note[:180]}")
    return "\n".join(lines)


def extract_llm_response_payload(result: Any) -> Optional[dict[str, Any]]:
    if not isinstance(result, dict):
        return None

    direct = extract_direct_classification_payload(result)
    if direct:
        return direct

    wrapped_keys = ["output", "result", "response", "text", "message"]
    for key in wrapped_keys:
        value = result.get(key)
        if isinstance(value, dict):
            nested = extract_direct_classification_payload(value)
            if nested:
                return nested
        if isinstance(value, str):
            parsed = extract_json_object_from_text(value)
            if parsed:
                nested = extract_direct_classification_payload(parsed)
                if nested:
                    return nested

    choices = result.get("choices")
    if isinstance(choices, list):
        for choice in choices:
            if not isinstance(choice, dict):
                continue
            nested = extract_direct_classification_payload(choice)
            if nested:
                return nested

            for key in ["message", "delta"]:
                value = choice.get(key)
                if isinstance(value, dict):
                    nested = extract_direct_classification_payload(value)
                    if nested:
                        return nested
                    content_candidate = _extract_content_text(value.get("content"))
                    if content_candidate:
                        parsed = extract_json_object_from_text(content_candidate)
                        if parsed:
                            nested = extract_direct_classification_payload(parsed)
                            if nested:
                                return nested

            content_candidate = _extract_content_text(choice.get("content"))
            if content_candidate:
                parsed = extract_json_object_from_text(content_candidate)
                if parsed:
                    nested = extract_direct_classification_payload(parsed)
                    if nested:
                        return nested

    content_candidate = _extract_content_text(result.get("content"))
    if content_candidate:
        parsed = extract_json_object_from_text(content_candidate)
        if parsed:
            nested = extract_direct_classification_payload(parsed)
            if nested:
                return nested

    return None


def _extract_content_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
                continue
            if isinstance(item, dict):
                text_value = item.get("text")
                if isinstance(text_value, str):
                    parts.append(text_value)
                    continue
                nested_text = item.get("content")
                if isinstance(nested_text, str):
                    parts.append(nested_text)
        return "\n".join(parts).strip()
    if isinstance(content, dict):
        text_value = content.get("text")
        if isinstance(text_value, str):
            return text_value
        nested_content = content.get("content")
        if isinstance(nested_content, str):
            return nested_content
    return ""


def extract_direct_classification_payload(candidate: dict[str, Any]) -> Optional[dict[str, Any]]:
    if "classification" not in candidate:
        return None

    return {
        "classification": candidate.get("classification"),
        "confidence": candidate.get("confidence", 0.6),
        "confidence_reasoning": candidate.get("confidence_reasoning"),
        "explanation": candidate.get("explanation", ""),
        "evidence": candidate.get("evidence", []),
        "remediation_suggestions": candidate.get("remediation_suggestions", []),
    }


def extract_json_object_from_text(text: str) -> Optional[dict[str, Any]]:
    text = text.strip()
    if not text:
        return None

    try:
        parsed = json.loads(text)
        return parsed if isinstance(parsed, dict) else None
    except (TypeError, ValueError):
        pass

    start = text.find("{")
    end = text.rfind("}")
    if start == -1:
        return None

    if end > start:
        try:
            parsed = json.loads(text[start:end + 1])
            return parsed if isinstance(parsed, dict) else None
        except (TypeError, ValueError):
            pass

    # The response may have been truncated mid-object (hit an output token
    # cap) before the closing braces were emitted. Attempt a best-effort
    # repair by trimming to the last safely-closable point and appending the
    # missing closing brackets/quotes, so we can still recover top-level
    # fields like classification/confidence/explanation even if a trailing
    # array (e.g. remediation_suggestions) was cut off.
    return _repair_truncated_json_object(text[start:])


def _repair_truncated_json_object(fragment: str) -> Optional[dict[str, Any]]:
    stack: list[str] = []
    in_string = False
    escape = False
    last_safe_index = -1

    for index, char in enumerate(fragment):
        if in_string:
            if escape:
                escape = False
            elif char == "\\":
                escape = True
            elif char == '"':
                in_string = False
            continue

        if char == '"':
            in_string = True
        elif char in "{[":
            stack.append(char)
        elif char in "}]":
            if stack:
                stack.pop()
        elif char in ",":
            if stack and stack[-1] == "{":
                last_safe_index = index

        if not in_string and not stack:
            last_safe_index = index

    if in_string:
        # Truncated inside a string literal: cut back to the last complete
        # key/value boundary we recorded, then close it out.
        if last_safe_index == -1:
            return None
        fragment = fragment[: last_safe_index + 1]
        stack = []
        in_string = False
        escape = False
        for char in fragment:
            if in_string:
                if escape:
                    escape = False
                elif char == "\\":
                    escape = True
                elif char == '"':
                    in_string = False
                continue
            if char == '"':
                in_string = True
            elif char in "{[":
                stack.append(char)
            elif char in "}]":
                if stack:
                    stack.pop()

    closing = "".join("}" if opener == "{" else "]" for opener in reversed(stack))
    candidate = fragment.rstrip().rstrip(",") + closing

    try:
        parsed = json.loads(candidate)
        return parsed if isinstance(parsed, dict) else None
    except (TypeError, ValueError):
        return None


def merge_classification_results(
    rule_result: AssetClassification,
    llm_result: Optional[dict[str, Any]],
) -> AssetClassification:
    if not llm_result:
        return rule_result

    llm_label = normalize_classification_label(str(llm_result.get("classification", "")))
    if not llm_label:
        return rule_result

    llm_confidence = normalize_confidence(llm_result.get("confidence"))
    llm_explanation = str(llm_result.get("explanation", "")).strip()
    llm_confidence_reasoning = str(llm_result.get("confidence_reasoning") or "").strip()
    llm_evidence = llm_result.get("evidence") if isinstance(llm_result.get("evidence"), list) else []
    llm_remediations = llm_result.get("remediation_suggestions") if isinstance(llm_result.get("remediation_suggestions"), list) else []

    # Convert LLM evidence list to EvidenceItem objects if needed
    evidence_items = _convert_llm_evidence_to_items(llm_evidence)

    if llm_label == rule_result.classification:
        merged_confidence = min(0.99, (rule_result.confidence + llm_confidence) / 2 + 0.03)
        merged_evidence = list(rule_result.evidence)
        merged_remediations = _convert_remediation_suggestions(llm_remediations)

        if llm_explanation:
            merged_evidence.append(
                EvidenceItem(
                    signal="llm_confirmation",
                    detail=llm_explanation[:500],
                    source="external_llm",
                )
            )

        # Add LLM's detailed evidence items
        merged_evidence.extend(evidence_items)

        return rule_result.model_copy(
            update={
                "confidence": round(merged_confidence, 3),
                "confidence_reasoning": llm_confidence_reasoning or rule_result.confidence_reasoning,
                "evidence": merged_evidence,
                "remediation_suggestions": merged_remediations,
            }
        )

    stricter = more_restrictive(rule_result.classification, llm_label)
    conflict_evidence = list(rule_result.evidence)
    llm_evidence_details = _summarize_llm_evidence_details(evidence_items, llm_evidence)
    conflict_evidence.append(
        EvidenceItem(
            signal="rule_llm_conflict",
            detail=(
                llm_evidence_details
                or llm_explanation[:500]
                or "Rule and LLM returned different classifications; human review required."
            ),
            source="external_llm",
        )
    )

    # Add LLM's detailed evidence items
    conflict_evidence.extend(evidence_items)

    merged_remediations = _convert_remediation_suggestions(llm_remediations)

    return rule_result.model_copy(
        update={
            "classification": stricter,
            "confidence": round(min(rule_result.confidence, llm_confidence), 3),
            "confidence_reasoning": llm_confidence_reasoning or rule_result.confidence_reasoning,
            "evidence": conflict_evidence,
            "remediation_suggestions": merged_remediations,
            "explanation": (
                f"{rule_result.explanation} LLM returned a conflicting class; "
                "stricter class selected pending human review."
            ),
            "human_review": HumanReviewRecommendation(
                required=True,
                reason="Rule and LLM disagree on sensitivity level.",
                suggested_action="review_and_override_if_needed",
            ),
        }
    )


def convert_llm_evidence_to_items(evidence_list: list[Any]) -> list[EvidenceItem]:
    """Convert LLM evidence (strings or dicts) to EvidenceItem objects."""
    items = []
    for evidence in evidence_list:
        if isinstance(evidence, str):
            items.append(
                EvidenceItem(
                    signal="llm_evidence",
                    detail=evidence[:500],
                    source="external_llm",
                )
            )
        elif isinstance(evidence, dict):
            items.append(
                EvidenceItem(
                    signal=evidence.get("signal", "llm_evidence"),
                    detail=str(evidence.get("detail", ""))[:500],
                    source="external_llm",
                    severity=evidence.get("severity"),
                )
            )
    return items


# Backward-compatible alias for internal call sites.
_convert_llm_evidence_to_items = convert_llm_evidence_to_items


def _summarize_llm_evidence_details(
    evidence_items: list[EvidenceItem],
    raw_evidence: list[Any],
) -> str:
    details: list[str] = []

    for item in evidence_items:
        detail = item.detail.strip()
        if detail and detail not in details:
            details.append(detail)

    if not details:
        for evidence in raw_evidence:
            if isinstance(evidence, str):
                detail = evidence.strip()
            elif isinstance(evidence, dict):
                detail = str(evidence.get("detail", "")).strip()
            else:
                detail = ""

            if detail and detail not in details:
                details.append(detail)

    return " ".join(details)[:500]


def _convert_remediation_suggestions(remediations: list[Any]) -> list[RemediationSuggestion]:
    """Convert LLM remediation suggestions to RemediationSuggestion objects."""
    items = []
    for rem in remediations:
        if isinstance(rem, dict):
            items.append(
                RemediationSuggestion(
                    field_name=str(rem.get("field_name", "")),
                    transformation=str(rem.get("transformation", "")),
                    reason=str(rem.get("reason", "")),
                    impact=str(rem.get("impact", "")) if rem.get("impact") else None,
                )
            )
    return items


