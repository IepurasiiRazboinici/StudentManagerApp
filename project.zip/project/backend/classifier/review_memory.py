import json
import threading
from datetime import UTC, datetime
from hashlib import sha256
from pathlib import Path
from typing import Any

from .constants import REVIEW_MEMORY_FILE
from .models import ClassificationLevel, ReviewDecisionRequest


_LOCK = threading.Lock()


def build_review_key(profile: dict[str, Any]) -> str:
    payload = {
        "asset_type": profile.get("asset_type"),
        "suffix": profile.get("suffix"),
        "columns": sorted(str(col).lower() for col in profile.get("columns", []) if col),
        "sensitive_columns_found": sorted(
            str(col).lower() for col in profile.get("sensitive_columns_found", []) if col
        ),
        "text_signals": profile.get("text_signals", {}),
        "has_account_hits": int(profile.get("account_id_hits", 0) or 0) > 0,
        "has_derived_fields": bool(profile.get("derived_fid_presence")),
    }
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    digest = sha256(canonical.encode("utf-8")).hexdigest()
    return f"rk-{digest[:24]}"


def load_memory(file_path: Path = REVIEW_MEMORY_FILE) -> list[dict[str, Any]]:
    if not file_path.exists():
        return []
    try:
        content = json.loads(file_path.read_text(encoding="utf-8"))
    except (TypeError, ValueError):
        return []
    if isinstance(content, list):
        return [item for item in content if isinstance(item, dict)]
    return []


def save_memory_atomic(entries: list[dict[str, Any]], file_path: Path = REVIEW_MEMORY_FILE) -> None:
    file_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = file_path.with_suffix(file_path.suffix + ".tmp")
    tmp_path.write_text(json.dumps(entries, indent=2), encoding="utf-8")
    tmp_path.replace(file_path)


def record_decision(review: ReviewDecisionRequest, file_path: Path = REVIEW_MEMORY_FILE) -> dict[str, Any]:
    with _LOCK:
        entries = load_memory(file_path)
        now = datetime.now(UTC).isoformat()

        entry = {
            "review_key": review.review_key,
            "corrected_classification": review.corrected_classification.value,
            "reviewer_note": review.reviewer_note,
            "reviewer_id": review.reviewer_id,
            "asset_type": review.asset_type,
            "asset_path": review.asset_path,
            "updated_at": now,
        }

        updated = False
        for idx, existing in enumerate(entries):
            if existing.get("review_key") == review.review_key:
                created_at = existing.get("created_at") or now
                entry["created_at"] = created_at
                entries[idx] = entry
                updated = True
                break

        if not updated:
            entry["created_at"] = now
            entries.append(entry)

        save_memory_atomic(entries, file_path)
        return entry


def find_memory_examples(
    review_key: str,
    profile: dict[str, Any],
    limit: int = 3,
    file_path: Path = REVIEW_MEMORY_FILE,
) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
    entries = load_memory(file_path)
    if not entries:
        return None, []

    exact = next((item for item in entries if item.get("review_key") == review_key), None)

    asset_type = str(profile.get("asset_type", ""))
    profile_columns = set(str(col).lower() for col in profile.get("columns", []) if col)
    similar: list[tuple[int, dict[str, Any]]] = []

    for entry in entries:
        if entry.get("review_key") == review_key:
            continue
        score = 0
        if entry.get("asset_type") == asset_type:
            score += 2
        entry_columns = set(str(col).lower() for col in (entry.get("columns") or []))
        overlap = len(profile_columns.intersection(entry_columns))
        score += min(overlap, 3)
        if score > 0:
            similar.append((score, entry))

    similar.sort(key=lambda item: item[0], reverse=True)
    top_examples = [entry for _, entry in similar[:limit]]

    # Fallback examples when scoring does not find anything similar.
    if not top_examples:
        top_examples = [entry for entry in entries if entry.get("review_key") != review_key][:limit]

    return exact, top_examples


def parse_memory_classification(value: str) -> ClassificationLevel | None:
    try:
        return ClassificationLevel(value)
    except ValueError:
        return None

