from datetime import date, datetime
from enum import Enum
from typing import Any, Optional, Dict
from pydantic import BaseModel, Field, field_validator


class ClassificationLevel(str, Enum):
    PUBLIC = "Public"
    CORPORATE = "Corporate"
    RESTRICTED = "Restricted"
    HIGHLY_RESTRICTED = "Highly Restricted"


TAXONOMY = [member.value for member in ClassificationLevel.__members__.values()]


class EvidenceItem(BaseModel):
    signal: str
    detail: str
    source: str
    severity: Optional[str] = None  # CRITICAL, HIGH, MEDIUM, LOW


class RemediationSuggestion(BaseModel):
    field_name: str
    transformation: str  # REMOVE_FIELD, MASK_VALUE, PSEUDONYMISE, etc.
    reason: str
    impact: Optional[str] = None  # e.g., "Utility retained: 85%"


class HumanReviewRecommendation(BaseModel):
    required: bool
    reason: Optional[str] = None
    suggested_action: str = "approve"


class CustomRuleMatch(BaseModel):
    """A user-defined classification rule (see classifier/custom_rules.py) that
    matched this asset, kept separate from the deterministic/LLM evidence so the
    frontend can show exactly which stored rule(s) influenced the result."""

    rule_id: str
    rule_name: str
    target_classification: ClassificationLevel
    confidence: int = Field(ge=0, le=100)
    priority: str
    require_human_review: bool
    matched_fields: list[str] = Field(default_factory=list)
    explanation: str


class SourceClassification(BaseModel):
    """A single classification opinion (from rules OR from the external LLM), kept
    separate from the merged/final result so the frontend can always show the raw
    AI output next to the deterministic rule-based output."""

    classification: ClassificationLevel
    confidence: float = Field(ge=0.0, le=1.0)
    explanation: str
    confidence_reasoning: Optional[str] = None
    evidence: list[EvidenceItem] = Field(default_factory=list)


class AssetClassification(BaseModel):
    review_key: Optional[str] = None
    asset_path: str
    asset_type: str
    classification: ClassificationLevel
    confidence: float = Field(ge=0.0, le=1.0)
    confidence_reasoning: Optional[str] = None  # Why the LLM/rules chose this confidence
    evidence: list[EvidenceItem]
    guidance_references: list[str]
    explanation: str
    remediation_suggestions: list[RemediationSuggestion] = Field(default_factory=list)
    human_review: HumanReviewRecommendation
    field_overrides: list[dict[str, Any]] = Field(default_factory=list)

    # User-defined classification rules (from /api/classification-rules) that matched
    # this asset and were folded into the final classification/evidence/human_review
    # above, and also forwarded to the external LLM as additional guidance.
    custom_rule_matches: list[CustomRuleMatch] = Field(default_factory=list)

    # --- AI/rules breakdown -------------------------------------------------
    # `classification`/`confidence`/`explanation`/`evidence` above remain the
    # final MERGED result (unchanged for backward compatibility). The fields
    # below expose the two contributing opinions separately so the UI can
    # always render the raw AI classification alongside the deterministic one.
    rule_classification: Optional[SourceClassification] = None
    ai_classification: Optional[SourceClassification] = None
    ai_attempted: bool = False  # An LLM call was configured and attempted
    ai_used: bool = False  # The LLM call succeeded and returned a usable classification
    classification_source: str = "rules"  # "rules" | "agreement" | "conflict"

    # `ai_classification` above is only populated when the LLM's response could be
    # parsed into a full structured classification. The two fields below are always
    # captured whenever an LLM call was attempted (`ai_attempted`), independent of
    # whether parsing succeeded, so the UI can always surface *something* from the
    # model: the raw text it produced, or the error that stopped the call, even for
    # documents where the deterministic rules alone decided the final tier.
    ai_raw_output: Optional[str] = None  # Best-effort raw/unparsed text returned by the LLM
    ai_error: Optional[str] = None  # Populated when the LLM request itself failed (network/timeout)


class ClassifyRequest(BaseModel):
    prompt: Optional[str] = None
    asset_paths: list[str] = Field(default_factory=list)
    data_root: Optional[str] = None
    postgres_dsn: Optional[str] = None
    postgres_schema: str = "public"
    postgres_tables: list[str] = Field(default_factory=list)
    postgres_sample_rows: int = Field(default=3, ge=0, le=25)
    use_llm: bool = True
    llm_endpoint: Optional[str] = None
    llm_bearer_token: Optional[str] = None
    # The hosted analyzer endpoint typically takes ~15-20s to respond for a
    # single asset, so the default must comfortably exceed that to avoid
    # silent timeouts that fall back to the rule-only classification.
    llm_timeout_seconds: int = 45
    llm_max_tokens: int = 650
    llm_additional_payload: dict[str, Any] = Field(default_factory=dict)
    current_date: Optional[date] = None

class ClassifyTextRequest(BaseModel):
    content: str
    prompt: Optional[str] = None
    use_llm: bool = True
    llm_endpoint: Optional[str] = None
    llm_bearer_token: Optional[str] = None
    llm_timeout_seconds: int = 45
    llm_max_tokens: int = 650
    llm_additional_payload: Dict[str, Any] = {}
    current_date: Optional[date] = None

class ClassifyTextRequest(BaseModel):
    content: str
    prompt: Optional[str] = None
    use_llm: bool = True
    llm_endpoint: Optional[str] = None
    llm_bearer_token: Optional[str] = None
    llm_timeout_seconds: int = 45
    llm_max_tokens: int = 650
    llm_additional_payload: dict[str, Any] = Field(default_factory=dict)
    current_date: Optional[date] = None


class ClassifyResponse(BaseModel):
    generated_at: datetime
    taxonomy: list[str]
    discovered_assets: int
    results: list[AssetClassification]
    distribution: dict[str, int]


class ReviewDecisionRequest(BaseModel):
    review_key: str
    corrected_classification: ClassificationLevel
    reviewer_note: str = ""
    reviewer_id: Optional[str] = None
    asset_type: Optional[str] = None
    asset_path: Optional[str] = None

    @field_validator("corrected_classification", mode="before")
    @classmethod
    def _normalize_review_label(cls, value: Any) -> Any:
        if isinstance(value, ClassificationLevel):
            return value
        if not isinstance(value, str):
            return value

        normalized = value.strip().lower().replace("_", " ")
        alias_map = {
            "public": ClassificationLevel.PUBLIC,
            "corporate": ClassificationLevel.CORPORATE,
            "internal": ClassificationLevel.CORPORATE,
            "restricted": ClassificationLevel.RESTRICTED,
            "confidential": ClassificationLevel.RESTRICTED,
            "highly restricted": ClassificationLevel.HIGHLY_RESTRICTED,
            "highly confidential": ClassificationLevel.HIGHLY_RESTRICTED,
        }
        return alias_map.get(normalized, value)


class ReviewDecisionResponse(BaseModel):
    saved: bool
    review_key: str
    corrected_classification: ClassificationLevel

