import { useUiStore } from '@/stores/uiStore'
import { useClassificationRules } from '@/hooks'
import { Drawer, KeyValue, PriorityBadge, TierBadge, StatusBadge, SystemLock } from '@/components/common'
import { SCOPE_LABEL, TRIGGER_TYPE_LABEL } from '@/utils/labels'
import { formatDateTime } from '@/utils/format'

export function RuleDetailsDrawer() {
  const ruleId = useUiStore((s) => s.ruleDetailsId)
  const close = useUiStore((s) => s.closeRuleDetails)
  const { data: rules } = useClassificationRules()
  const rule = rules?.find((r) => r.id === ruleId)

  return (
    <Drawer
      open={Boolean(ruleId)}
      onClose={close}
      title={rule ? rule.name : 'Rule'}
      subtitle={rule?.protected ? 'Read-only system rule' : 'Custom rule'}
      className="drawer-rule-details"
      bodyClassName="drawer-rule-details-body"
    >
      {rule ? (
        <div className="rule-details">
          <section className="rule-details-hero" aria-label="Rule summary">
            <div className="rule-details-hero-copy">
              <div className="rule-details-badges">
                {rule.protected ? <SystemLock /> : <StatusBadge tone="teal">Custom</StatusBadge>}
                <TierBadge tier={rule.targetTier} />
                <PriorityBadge priority={rule.priority} />
                <StatusBadge tone={rule.enabled ? 'green' : 'neutral'}>{rule.enabled ? 'Enabled' : 'Disabled'}</StatusBadge>
              </div>
              <p className="rule-details-description">{rule.description}</p>
            </div>

            <div className="rule-details-highlights" aria-label="Rule highlights">
              <div className="rule-details-highlight-card">
                <span>Target tier</span>
                <strong>{rule.targetTier.replaceAll('_', ' ')}</strong>
              </div>
              <div className="rule-details-highlight-card">
                <span>Matched files</span>
                <strong>{rule.matchedFiles}</strong>
              </div>
              <div className="rule-details-highlight-card">
                <span>Updated</span>
                <strong>{formatDateTime(rule.updatedAt)}</strong>
              </div>
            </div>
          </section>

          <section className="rule-details-section">
            <div className="rule-details-section-head">
              <span className="eyebrow">Configuration</span>
              <h3>How this rule is applied</h3>
              <p>Review the trigger, scope and operational settings before enabling or editing this rule.</p>
            </div>

            <div className="key-value-grid rule-details-grid">
              <KeyValue label="Trigger type" value={TRIGGER_TYPE_LABEL[rule.triggerType]} />
              <KeyValue label="Trigger" value={<span className="mono">{rule.triggerSummary}</span>} />
              <KeyValue label="Scope" value={SCOPE_LABEL[rule.scope]} />
              <KeyValue label="Confidence" value={`${rule.confidence}%`} />
              <KeyValue label="Human review" value={rule.requireHumanReview ? 'Required' : 'Not required'} />
              <KeyValue label="Matched files" value={rule.matchedFiles} />
              <KeyValue label="Updated" value={formatDateTime(rule.updatedAt)} />
            </div>
          </section>

          {rule.explanationTemplate ? (
            <section className="rule-details-section">
              <div className="rule-details-section-head">
                <span className="eyebrow">Decision guidance</span>
                <h3>Explanation template</h3>
                <p>This text is shown to explain why the rule influenced a classification outcome.</p>
              </div>

              <div className="rule-details-callout">
                <p>{rule.explanationTemplate}</p>
              </div>
            </section>
          ) : null}

          {rule.protected ? (
            <div className="rule-details-note">
              <p className="muted">System rules are implemented by the service and cannot be edited or deleted.</p>
            </div>
          ) : null}
        </div>
      ) : null}
    </Drawer>
  )
}
