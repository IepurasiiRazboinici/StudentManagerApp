import { beforeEach, describe, expect, it, vi } from 'vitest'
import { screen } from '@testing-library/react'
import { renderWithProviders } from '@/test/utils'
import type { ClassificationRule } from '@/types'
import { useUiStore } from '@/stores/uiStore'
import { RuleDetailsDrawer } from './RuleDetailsDrawer'

const rule: ClassificationRule = {
  id: 'custom-1',
  name: 'Escalate ownergroup identity mappings',
  description:
    'Flags mapping datasets that may connect internal owner groups to identifiable counterparties so reviewers can confirm provenance before distribution.',
  source: 'CUSTOM',
  scope: 'THIS_FILE',
  scopeLabel: 'This file',
  scopeFileId: 'file-ownergroup',
  triggerType: 'FIELD_COMBINATION',
  triggerSummary: 'ownergroup + internal_code + entity_alias',
  targetTier: 'RESTRICTED',
  confidence: 84,
  priority: 'HIGH',
  requireHumanReview: true,
  explanationTemplate: 'Possible identity mapping detected across ownergroup, internal_code and entity_alias.',
  enabled: true,
  protected: false,
  matchedFiles: 3,
  matchStatus: 'MATCHED',
  updatedAt: '2026-07-23T09:15:00Z',
}

vi.mock('@/hooks', () => ({
  useClassificationRules: () => ({ data: [rule] }),
}))

describe('RuleDetailsDrawer', () => {
  beforeEach(() => {
    useUiStore.setState({ ruleDetailsId: 'custom-1' })
  })

  it('renders the refactored spaced detail sections for a selected rule', () => {
    renderWithProviders(<RuleDetailsDrawer />)

    expect(screen.getByRole('dialog')).toBeInTheDocument()
    expect(screen.getByRole('heading', { name: /how this rule is applied/i })).toBeInTheDocument()
    expect(screen.getByRole('heading', { name: /explanation template/i })).toBeInTheDocument()
    expect(screen.getByText(/review the trigger, scope and operational settings/i)).toBeInTheDocument()
    expect(screen.getByText(/possible identity mapping detected across ownergroup/i)).toBeInTheDocument()

    const summaryRegion = screen.getByLabelText(/rule summary/i)
    expect(summaryRegion).toHaveTextContent(/matched files/i)
    expect(summaryRegion).toHaveTextContent(/updated/i)
  })
})

