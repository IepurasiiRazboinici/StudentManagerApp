import { useUiStore } from '@/stores/uiStore'
import { Drawer } from '@/components/common'
import { RuleForm } from './RuleForm'

export function AddRuleDrawer() {
  const open = useUiStore((s) => s.addRuleOpen)
  const context = useUiStore((s) => s.addRuleContext)
  const close = useUiStore((s) => s.closeAddRule)
  const editing = Boolean(context.ruleId)

  return (
    <Drawer
      open={open}
      onClose={close}
      wide
      className="drawer-rule-editor"
      bodyClassName="drawer-rule-editor-body"
      title={editing ? 'Edit Classification Rule' : 'Add New Classification Rule'}
      subtitle={editing ? 'Adjust trigger logic and save updated behavior.' : 'Design a deterministic rule, preview service impact, then apply.'}
    >
      {open ? <RuleForm key={JSON.stringify(context)} context={context} onClose={close} /> : null}
    </Drawer>
  )
}
