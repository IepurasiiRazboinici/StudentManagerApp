import { beforeEach, describe, expect, it, vi } from 'vitest'
import { screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import type { PolicyDocument } from '@/types'
import { renderWithProviders } from '@/test/utils'
import { PolicySideSheet } from './PolicySideSheet'

const { closePolicyMock, navigateMock } = vi.hoisted(() => ({
  closePolicyMock: vi.fn(),
  navigateMock: vi.fn(),
}))

const policy: PolicyDocument = {
  id: 'pol-fin-07',
  name: 'FIN-07',
  version: '2026.2',
  status: 'DRAFT',
  classificationsUsing: 3,
  ingestedAt: '2026-07-20T00:00:00Z',
  coverage: 88,
  sections: [
    {
      id: 's-1',
      reference: 'FIN-07 2.4',
      title: 'Embargoed content',
      body: {
        en: 'Draft earnings remain restricted.',
        es: 'Las ganancias preliminares siguen restringidas.',
      },
      datasetsUsing: ['draft_earnings_forecast'],
    },
  ],
}

vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual<typeof import('react-router-dom')>('react-router-dom')
  return {
    ...actual,
    useNavigate: () => navigateMock,
  }
})

vi.mock('@/stores/uiStore', () => ({
  useUiStore: (
    selector: (state: { policySheetId: string | null; closePolicy: () => void }) => unknown,
  ) => selector({ policySheetId: policy.id, closePolicy: closePolicyMock }),
}))

vi.mock('@/hooks', () => ({
  usePolicy: () => ({ data: policy, isLoading: false }),
}))

describe('PolicySideSheet', () => {
  beforeEach(() => {
    closePolicyMock.mockReset()
    navigateMock.mockReset()
  })

  it('renders multilingual section content', () => {
    renderWithProviders(<PolicySideSheet />)

    expect(screen.getByText('[en]', { exact: false })).toBeInTheDocument()
    expect(screen.getByText('Draft earnings remain restricted.')).toBeInTheDocument()
    expect(screen.getByText('[es]', { exact: false })).toBeInTheDocument()
    expect(screen.getByText('Las ganancias preliminares siguen restringidas.')).toBeInTheDocument()
  })

  it('closes the sheet and navigates to dataset details from a dataset badge link', async () => {
    const user = userEvent.setup()
    renderWithProviders(<PolicySideSheet />)

    await user.click(screen.getByRole('button', { name: 'draft_earnings_forecast' }))

    expect(closePolicyMock).toHaveBeenCalledTimes(1)
    expect(navigateMock).toHaveBeenCalledWith('/datasets/draft_earnings_forecast')
  })
})

