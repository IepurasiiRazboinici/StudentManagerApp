import { useNavigate } from 'react-router-dom'
import { useUiStore } from '@/stores/uiStore'
import { usePolicy } from '@/hooks'
import { Drawer, KeyValue, StatusBadge, Skeleton } from '@/components/common'
import { formatDate } from '@/utils/format'
import { POLICY_STATUS_LABEL, POLICY_STATUS_TONE } from '@/utils/labels'

function localizedBodies(body: string | Record<string, string>): Array<{ locale: string; text: string }> {
  if (typeof body === 'string') return [{ locale: 'default', text: body }]
  return Object.entries(body)
    .filter(([, text]) => text.trim().length > 0)
    .map(([locale, text]) => ({ locale, text }))
}

export function PolicySideSheet() {
  const navigate = useNavigate()
  const policyId = useUiStore((s) => s.policySheetId)
  const close = useUiStore((s) => s.closePolicy)
  const { data: policy, isLoading } = usePolicy(policyId ?? undefined)

  const goToDataset = (datasetId: string) => {
    close()
    navigate(`/datasets/${encodeURIComponent(datasetId)}`)
  }

  return (
    <Drawer open={Boolean(policyId)} onClose={close} title={policy ? policy.name : 'Policy'} subtitle={policy ? `Version ${policy.version}` : undefined}>
      {isLoading ? (
        <div className="stack">
          <Skeleton className="skeleton-line" />
          <Skeleton className="skeleton-panel" />
        </div>
      ) : policy ? (
        <div className="policy-sheet">
          <div className="rule-details-badges">
            <StatusBadge tone={POLICY_STATUS_TONE[policy.status]}>{POLICY_STATUS_LABEL[policy.status]}</StatusBadge>
            <StatusBadge tone="blue">{policy.classificationsUsing} classifications</StatusBadge>
          </div>
          <div className="key-value-grid">
            <KeyValue label="Version" value={policy.version} />
            <KeyValue label="Ingested" value={formatDate(policy.ingestedAt)} />
            <KeyValue label="Coverage" value={`${policy.coverage}%`} />
          </div>
          {policy.sections.map((section) => (
            <section key={section.id} className="policy-section-block">
              <span className="mono policy-ref">{section.reference}</span>
              <h3>{section.title}</h3>
              {localizedBodies(section.body).map((entry) => (
                <blockquote key={`${section.id}-${entry.locale}`}>
                  {entry.locale !== 'default' ? <span className="policy-locale-tag mono">[{entry.locale}] </span> : null}
                  {entry.text}
                </blockquote>
              ))}
              {section.datasetsUsing.length > 0 ? (
                <div className="policy-datasets">
                  <span className="eyebrow">Datasets using this section</span>
                  <div className="rule-pills">
                    {section.datasetsUsing.map((d) => (
                      <button key={d} type="button" className="badge badge-neutral mono policy-dataset-link" onClick={() => goToDataset(d)}>
                        {d}
                      </button>
                    ))}
                  </div>
                </div>
              ) : null}
            </section>
          ))}
        </div>
      ) : (
        <p className="muted">Policy not found.</p>
      )}
    </Drawer>
  )
}
