import type { ReviewItem } from '@/types'
import { cn } from '@/utils/cn'
import { TierBadge } from '@/components/common'
import { REVIEW_CATEGORY_LABEL } from '@/utils/labels'

export function ReviewQueueRail({
  items,
  selectedId,
  resolvedIds,
  highlightedId,
  onSelect,
}: {
  items: ReviewItem[]
  selectedId: string | undefined
  resolvedIds: Set<string>
  highlightedId?: string
  onSelect: (id: string) => void
}) {
  return (
    <nav className="queue-rail" aria-label="Review queue">
      <div className="queue-rail-head">
        <span className="eyebrow">Queue</span>
        <span className="badge badge-amber">{items.length}</span>
      </div>
      <ul>
        {items.map((item) => (
          <li key={item.id}>
            <button
              type="button"
              className={cn(
                'queue-item',
                selectedId === item.id && 'queue-item-active',
                resolvedIds.has(item.id) && 'queue-item-resolved',
                highlightedId === item.id && 'queue-item-highlighted',
              )}
              onClick={() => onSelect(item.id)}
              aria-current={selectedId === item.id}
              data-review-id={item.id}
            >
              <span className="queue-item-cat">{REVIEW_CATEGORY_LABEL[item.category]}</span>
              <span className="queue-item-name mono">{item.datasetName}</span>
              <span className="queue-item-meta">
                <TierBadge tier={item.currentClassification} />
                <span className="muted">{item.confidence}%</span>
              </span>
              {resolvedIds.has(item.id) ? <span className="queue-item-status">Resolved</span> : null}
            </button>
          </li>
        ))}
      </ul>
    </nav>
  )
}
