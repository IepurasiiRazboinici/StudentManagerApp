import { useNavigate } from 'react-router-dom'
import { ArrowDown, ArrowUp, ArrowUpDown, ShieldCheck, ShieldX, SlidersHorizontal } from 'lucide-react'
import type { DatasetSummary } from '@/types'
import { ConfidenceIndicator, ReviewStatusBadge, StatusBadge, TierBadge, UsageStatusBadge } from '@/components/common'
import { formatDate, formatNumber } from '@/utils/format'

export type DatasetSortKey =
  | 'name'
  | 'rowCount'
  | 'classification'
  | 'confidence'
  | 'reviewStatus'
  | 'usageStatus'
  | 'matchedRuleCount'
  | 'lastAnalysed'
  | 'canBeMadeSafe'

export type DatasetSortDirection = 'asc' | 'desc' | null

const collator = new Intl.Collator('en-GB', { numeric: true, sensitivity: 'base' })

function isLogSource(dataset: DatasetSummary): boolean {
  const raw = `${dataset.name} ${dataset.sourceLocation}`.toLowerCase()
  return /\.(log|txt|md|fids)(\b|$)/.test(raw)
}

export function structureLabel(dataset: DatasetSummary): 'Structured' | 'Unstructured' {
  if (dataset.sourceKind === 'POSTGRESQL') return 'Structured'
  return isLogSource(dataset) ? 'Unstructured' : 'Structured'
}

function sortStatusValue(value: string, order: Record<string, number>): number {
  return order[value] ?? Number.MAX_SAFE_INTEGER
}

export function sortDatasets(items: DatasetSummary[], sortKey: DatasetSortKey | null, sortDirection: DatasetSortDirection): DatasetSummary[] {
  if (!sortKey || !sortDirection) return items

  const order =
    sortDirection === 'asc'
      ? 1
      : -1

  const rankMap = {
    PUBLIC: 0,
    CORPORATE: 1,
    RESTRICTED: 2,
    HIGHLY_RESTRICTED: 3,
    UNKNOWN: 4,
  } as const
  const reviewOrder = {
    AUTO: 0,
    CONFIRMED: 1,
    OVERRIDDEN: 2,
    REVIEW_REQUIRED: 3,
  } as const
  const usageOrder = {
    ALLOWED: 0,
    CONDITIONALLY_ALLOWED: 1,
    REVIEW_REQUIRED: 2,
    BLOCKED: 3,
  } as const

  return [...items]
    .map((item, index) => ({ item, index }))
    .sort((left, right) => {
      const a = left.item
      const b = right.item
      let result = 0

      switch (sortKey) {
        case 'name':
          result = collator.compare(a.name, b.name)
          break
        case 'rowCount':
          result = a.rowCount - b.rowCount
          break
        case 'classification':
          result = sortStatusValue(a.classification, rankMap) - sortStatusValue(b.classification, rankMap)
          break
        case 'confidence':
          result = a.confidence - b.confidence
          break
        case 'reviewStatus':
          result = sortStatusValue(a.reviewStatus, reviewOrder) - sortStatusValue(b.reviewStatus, reviewOrder)
          break
        case 'usageStatus':
          result = sortStatusValue(a.usageStatus, usageOrder) - sortStatusValue(b.usageStatus, usageOrder)
          break
        case 'matchedRuleCount':
          result = a.matchedRuleCount - b.matchedRuleCount
          break
        case 'lastAnalysed':
          result = new Date(a.lastAnalysed).getTime() - new Date(b.lastAnalysed).getTime()
          break
        case 'canBeMadeSafe':
          result = Number(a.canBeMadeSafe) - Number(b.canBeMadeSafe)
          break
      }

      if (result !== 0) return result * order
      return left.index - right.index
    })
    .map(({ item }) => item)
}

function SortIcon({ active, direction }: { active: boolean; direction: DatasetSortDirection }) {
  if (!active || !direction) return <ArrowUpDown size={13} aria-hidden />
  return direction === 'asc' ? <ArrowUp size={13} aria-hidden /> : <ArrowDown size={13} aria-hidden />
}

function SortHeader({
  label,
  sortKey,
  currentKey,
  direction,
  onSort,
  alignRight = false,
}: {
  label: string
  sortKey: DatasetSortKey
  currentKey: DatasetSortKey | null
  direction: DatasetSortDirection
  onSort: (key: DatasetSortKey) => void
  alignRight?: boolean
}) {
  const active = currentKey === sortKey
  const ariaSort = active ? (direction === 'asc' ? 'ascending' : direction === 'desc' ? 'descending' : 'none') : 'none'
  return (
    <th className={alignRight ? 'num' : undefined} aria-sort={ariaSort}>
      <button
        type="button"
        onClick={() => onSort(sortKey)}
        title={`Sort by ${label}`}
        aria-label={`Sort by ${label}`}
        style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: 8,
          border: 0,
          background: 'transparent',
          color: 'inherit',
          cursor: 'pointer',
          font: 'inherit',
          padding: '2px 0',
          minHeight: 24,
        }}
      >
        <span>{label}</span>
        <SortIcon active={active} direction={direction} />
      </button>
    </th>
  )
}

export function DatasetTable({
  datasets,
  sortKey,
  sortDirection,
  onSort,
}: {
  datasets: DatasetSummary[]
  sortKey: DatasetSortKey | null
  sortDirection: DatasetSortDirection
  onSort: (key: DatasetSortKey) => void
}) {
  const navigate = useNavigate()

  return (
    <div className="table-wrap">
      <table className="data-table dataset-table">
        <thead>
          <tr>
            <SortHeader label="Dataset" sortKey="name" currentKey={sortKey} direction={sortDirection} onSort={onSort} />
            <SortHeader label="Rows" sortKey="rowCount" currentKey={sortKey} direction={sortDirection} onSort={onSort} alignRight />
            <SortHeader label="Classification" sortKey="classification" currentKey={sortKey} direction={sortDirection} onSort={onSort} />
            <SortHeader label="Confidence" sortKey="confidence" currentKey={sortKey} direction={sortDirection} onSort={onSort} />
            <SortHeader label="Review" sortKey="reviewStatus" currentKey={sortKey} direction={sortDirection} onSort={onSort} />
            <SortHeader label="Usage" sortKey="usageStatus" currentKey={sortKey} direction={sortDirection} onSort={onSort} />
            <SortHeader label="Rules" sortKey="matchedRuleCount" currentKey={sortKey} direction={sortDirection} onSort={onSort} alignRight />
            <SortHeader label="Last analysed" sortKey="lastAnalysed" currentKey={sortKey} direction={sortDirection} onSort={onSort} />
          </tr>
        </thead>
        <tbody>
          {datasets.map((d) => (
            <tr
              key={d.id}
              className="clickable-row"
              tabIndex={0}
              role="link"
              aria-label={`Open ${d.name}`}
              onClick={() => navigate(`/datasets/${d.id}`)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault()
                  navigate(`/datasets/${d.id}`)
                }
              }}
            >
              <td>
                <span className="dataset-cell" style={{ display: 'grid', gap: 8, alignItems: 'start' }}>
                  <span className="mono" title={d.sourceLocation}>{d.name}</span>
                  {d.hasCustomRule ? <span className="badge badge-teal">Custom rule</span> : null}
                </span>
              </td>
              <td className="num">{formatNumber(d.rowCount)}</td>
              <td>
                <TierBadge tier={d.classification} />
              </td>
              <td>
                <span style={{ display: 'grid', gap: 8 }}>
                  <ConfidenceIndicator value={d.confidence} size="sm" />
                  <span title={`Rule impact on confidence: ${d.matchedRuleCount} matched rule${d.matchedRuleCount === 1 ? '' : 's'}`}>
                    <StatusBadge
                      tone={d.matchedRuleCount > 0 ? 'violet' : 'neutral'}
                      dashed={d.matchedRuleCount === 0}
                      icon={<SlidersHorizontal size={13} aria-hidden />}
                    >
                      {d.matchedRuleCount > 0 ? `${d.matchedRuleCount} rule${d.matchedRuleCount === 1 ? '' : 's'}` : 'No rule impact'}
                    </StatusBadge>
                  </span>
                </span>
              </td>
              <td>
                <ReviewStatusBadge status={d.reviewStatus} />
              </td>
              <td>
                <span style={{ display: 'grid', gap: 8 }}>
                  <UsageStatusBadge status={d.usageStatus} />
                  <span title={d.canBeMadeSafe ? 'Can be made safe with remediation' : 'No safe remediation path detected'}>
                    <StatusBadge
                      tone={d.canBeMadeSafe ? 'green' : 'neutral'}
                      icon={d.canBeMadeSafe ? <ShieldCheck size={13} aria-hidden /> : <ShieldX size={13} aria-hidden />}
                    >
                      {d.canBeMadeSafe ? 'Safe-able' : 'Not safe-able'}
                    </StatusBadge>
                  </span>
                </span>
              </td>
              <td className="num">{d.matchedRuleCount}</td>
              <td className="muted">{formatDate(d.lastAnalysed)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
