import { forwardRef } from 'react'
import { Check } from 'lucide-react'
import type { RemediationTransformation } from '@/types'
import { cn } from '@/utils/cn'
import { TRANSFORMATION_LABEL } from '@/utils/labels'

export const TransformationCard = forwardRef<
  HTMLButtonElement,
  {
    transformation: RemediationTransformation
    selected: boolean
    highlighted?: boolean
    onToggle: () => void
  }
>(({ transformation, selected, highlighted = false, onToggle }, ref) => {
  return (
    <button
      ref={ref}
      type="button"
      className={cn('transformation-card', selected && 'transformation-card-selected')}
      onClick={onToggle}
      aria-pressed={selected}
      style={
        highlighted
          ? {
              padding: 16,
              borderColor: 'var(--accent)',
              background: 'var(--accent-soft)',
              boxShadow: '0 0 0 1px rgba(47, 111, 237, 0.26)',
            }
          : { padding: 16 }
      }
    >
      <span className="transformation-check" aria-hidden>
        {selected ? <Check size={14} /> : null}
      </span>
      <span className="transformation-body" style={{ gap: 8, lineHeight: 1.35 }}>
        <span className="transformation-title">
          {transformation.title}
          {transformation.recommended ? <span className="badge badge-green">Recommended</span> : null}
        </span>
        <span className="transformation-kind mono">{TRANSFORMATION_LABEL[transformation.kind]}</span>
        <span className="transformation-desc">{transformation.description}</span>
      </span>
    </button>
  )
})

TransformationCard.displayName = 'TransformationCard'
