import type { ReactNode } from 'react'
import { ArrowRight } from 'lucide-react'
import type { RemediationMetrics } from '@/types'
import { StatusBadge, TierBadge, UsageStatusBadge } from '@/components/common'

const TIER_RANK: Record<RemediationMetrics['classification'], number> = {
  PUBLIC: 0,
  CORPORATE: 1,
  RESTRICTED: 2,
  HIGHLY_RESTRICTED: 3,
  UNKNOWN: 4,
}

const USAGE_RANK: Record<RemediationMetrics['usageStatus'], number> = {
  ALLOWED: 0,
  CONDITIONALLY_ALLOWED: 1,
  REVIEW_REQUIRED: 2,
  BLOCKED: 3,
}

function numericDelta(before: number, after: number, betterWhen: 'lower' | 'higher', unit = ''): { label: string; tone: 'green' | 'red' | 'neutral' } {
  if (before === after) return { label: 'No change', tone: 'neutral' }
  const diff = after - before
  const improved = betterWhen === 'lower' ? diff < 0 : diff > 0
  const sign = diff > 0 ? '+' : '−'
  return { label: `${sign}${Math.abs(diff)}${unit}`, tone: improved ? 'green' : 'red' }
}

function tierDelta(before: RemediationMetrics['classification'], after: RemediationMetrics['classification']) {
  if (before === after) return { label: 'No tier change', tone: 'neutral' as const }
  const diff = TIER_RANK[after] - TIER_RANK[before]
  return diff < 0
    ? { label: `Safer by ${Math.abs(diff)} tier${Math.abs(diff) === 1 ? '' : 's'}`, tone: 'green' as const }
    : { label: `More restrictive by ${Math.abs(diff)} tier${Math.abs(diff) === 1 ? '' : 's'}`, tone: 'red' as const }
}

function usageDelta(before: RemediationMetrics['usageStatus'], after: RemediationMetrics['usageStatus']) {
  if (before === after) return { label: 'No change', tone: 'neutral' as const }
  const diff = USAGE_RANK[after] - USAGE_RANK[before]
  return diff < 0
    ? { label: `More usable by ${Math.abs(diff)} step${Math.abs(diff) === 1 ? '' : 's'}`, tone: 'green' as const }
    : { label: `Less usable by ${Math.abs(diff)} step${Math.abs(diff) === 1 ? '' : 's'}`, tone: 'red' as const }
}

function fieldDelta(before: number, after: number) {
  if (before === after) return { label: 'No change', tone: 'neutral' as const }
  return after < before
    ? { label: `−${before - after} field${before - after === 1 ? '' : 's'}`, tone: 'green' as const }
    : { label: `+${after - before} field${after - before === 1 ? '' : 's'}`, tone: 'red' as const }
}

function MetricRow({ label, value, delta }: { label: string; value: ReactNode; delta?: { label: string; tone: 'green' | 'red' | 'neutral' } }) {
  return (
    <div className="ba-row" style={{ paddingBlock: 4 }}>
      <span style={{ minWidth: 132 }}>{label}</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', justifyContent: 'flex-end', rowGap: 8 }}>
        {value}
        {delta ? <StatusBadge tone={delta.tone} dashed={delta.tone === 'neutral'}>{delta.label}</StatusBadge> : null}
      </div>
    </div>
  )
}

function MetricColumn({
  label,
  metrics,
  compareTo,
}: {
  label: string
  metrics: RemediationMetrics
  compareTo?: RemediationMetrics
}) {
  const sensitiveFieldDelta = compareTo
    ? fieldDelta(compareTo.remainingSensitiveFields.length, metrics.remainingSensitiveFields.length)
    : null

  return (
    <div className="ba-column" style={{ gap: 12, padding: 16 }}>
      <span className="eyebrow">{label}</span>
      <MetricRow
        label="Classification"
        value={<TierBadge tier={metrics.classification} />}
        delta={compareTo ? tierDelta(compareTo.classification, metrics.classification) : undefined}
      />
      <MetricRow
        label="Risk score"
        value={<strong>{metrics.riskScore}</strong>}
        delta={compareTo ? numericDelta(compareTo.riskScore, metrics.riskScore, 'lower') : undefined}
      />
      <MetricRow
        label="Usage"
        value={<UsageStatusBadge status={metrics.usageStatus} />}
        delta={compareTo ? usageDelta(compareTo.usageStatus, metrics.usageStatus) : undefined}
      />
      <MetricRow
        label="Utility retained"
        value={<strong>{metrics.utilityRetained}%</strong>}
        delta={compareTo ? numericDelta(compareTo.utilityRetained, metrics.utilityRetained, 'higher', '%') : undefined}
      />
      <div className="ba-row ba-row-fields" style={{ paddingTop: 8, gap: 8 }}>
        <span>Remaining sensitive fields</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', justifyContent: 'flex-end', rowGap: 8 }}>
          {metrics.remainingSensitiveFields.length > 0 ? (
            <div className="rule-pills">
              {metrics.remainingSensitiveFields.map((f) => (
                <span key={f} className="badge badge-red mono">
                  {f}
                </span>
              ))}
            </div>
          ) : (
            <span className="badge badge-green">None</span>
          )}
          {sensitiveFieldDelta ? (
            <StatusBadge tone={sensitiveFieldDelta.tone} dashed={sensitiveFieldDelta.tone === 'neutral'}>
              {sensitiveFieldDelta.label}
            </StatusBadge>
          ) : null}
        </div>
      </div>
    </div>
  )
}

export function BeforeAfterPanel({ before, after }: { before: RemediationMetrics; after: RemediationMetrics }) {
  return (
    <div className="before-after-panel" style={{ gap: 16 }}>
      <MetricColumn label="Original" metrics={before} />
      <ArrowRight className="ba-arrow" size={20} aria-hidden />
      <MetricColumn label="Proposed safe version" metrics={after} compareTo={before} />
    </div>
  )
}
