import { useEffect } from 'react'
import { Outlet } from 'react-router-dom'
import { Keyboard } from 'lucide-react'
import { Sidebar } from './Sidebar'
import { Topbar } from './Topbar'
import { Modal, Toaster } from '@/components/common'
import { AddRuleDrawer } from '@/components/rules/AddRuleDrawer'
import { RuleDetailsDrawer } from '@/components/rules/RuleDetailsDrawer'
import { EvidenceDrawer } from '@/components/classification/EvidenceDrawer'
import { PolicySideSheet } from '@/components/policies/PolicySideSheet'
import { useUiStore } from '@/stores/uiStore'
import { cn } from '@/utils/cn'

const SHORTCUTS = [
  { keys: ['?'], description: 'Open this keyboard shortcuts guide' },
  { keys: ['Esc'], description: 'Close the active dialog, drawer or menu' },
  { keys: ['Tab'], description: 'Move focus to the next control' },
  { keys: ['Shift', 'Tab'], description: 'Move focus to the previous control' },
]

/** Modal listing the app's keyboard shortcuts, opened via the global "?" listener. */
function ShortcutsModal() {
  const open = useUiStore((s) => s.shortcutsOpen)
  const close = useUiStore((s) => s.closeShortcuts)

  return (
    <Modal
      open={open}
      title={
        <span className="shortcuts-modal-title">
          <Keyboard size={18} aria-hidden />
          Keyboard shortcuts
        </span>
      }
      onClose={close}
      labelId="shortcuts-modal-title"
    >
      <ul className="shortcuts-list">
        {SHORTCUTS.map((shortcut) => (
          <li key={shortcut.description} className="shortcuts-row">
            <span className="shortcuts-keys">
              {shortcut.keys.map((key) => (
                <kbd key={key} className="shortcut-key">
                  {key}
                </kbd>
              ))}
            </span>
            <span className="shortcuts-description">{shortcut.description}</span>
          </li>
        ))}
      </ul>
    </Modal>
  )
}

export function AppShell() {
  const collapsed = useUiStore((s) => s.sidebarCollapsed)
  const darkMode = useUiStore((s) => s.darkMode)
  const openShortcuts = useUiStore((s) => s.openShortcuts)

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key !== '?' || event.metaKey || event.ctrlKey || event.altKey) return

      const target = event.target as HTMLElement | null
      const tag = target?.tagName
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || target?.isContentEditable) return

      event.preventDefault()
      openShortcuts()
    }

    document.addEventListener('keydown', onKeyDown)
    return () => document.removeEventListener('keydown', onKeyDown)
  }, [openShortcuts])

  return (
    <div className={cn('app-shell', collapsed && 'app-shell-collapsed', darkMode && 'theme-dark')}>
      <a href="#main-content" className="skip-link">
        Skip to content
      </a>
      <Sidebar />
      <div className="workspace">
        <Topbar />
        <main className="page" id="main-content">
          <Outlet />
        </main>
      </div>

      {/* Global overlays driven by the UI store */}
      <AddRuleDrawer />
      <RuleDetailsDrawer />
      <EvidenceDrawer />
      <PolicySideSheet />
      <ShortcutsModal />
      <Toaster />
    </div>
  )
}
