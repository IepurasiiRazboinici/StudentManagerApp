import { beforeEach, describe, expect, it, vi } from 'vitest'
import { screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { renderWithProviders } from '@/test/utils'
import { Topbar } from './Topbar'

const { navigateMock } = vi.hoisted(() => ({
  navigateMock: vi.fn(),
}))

vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual<typeof import('react-router-dom')>('react-router-dom')
  return {
    ...actual,
    useNavigate: () => navigateMock,
  }
})

vi.mock('@/hooks', () => ({
  useCurrentUser: () => ({ displayName: 'Mia Mihai' }),
}))

vi.mock('@/stores/uiStore', () => ({
  useUiStore: (selector: (state: { darkMode: boolean; toggleDarkMode: () => void }) => unknown) =>
    selector({ darkMode: false, toggleDarkMode: vi.fn() }),
}))

describe('Topbar scan new data source', () => {
  beforeEach(() => {
    navigateMock.mockReset()
  })

  it('navigates to the new source flow when clicked', async () => {
    const user = userEvent.setup()
    renderWithProviders(<Topbar />, ['/dashboard'])

    await user.click(screen.getByRole('button', { name: /scan new data source/i }))

    expect(navigateMock).toHaveBeenCalledWith('/sources/new')
  })
})

