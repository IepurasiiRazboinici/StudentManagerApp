import { useEffect, useMemo, useState } from 'react'
import { NavLink } from 'react-router-dom'
import {
  ClipboardList,
  FileText,
  History,
  LayoutDashboard,
  Library,
  PanelLeftClose,
  PanelLeftOpen,
  ShieldCheck,
} from 'lucide-react'
import { useCurrentUser, useDashboardStats, useReviewQueue } from '@/hooks'
import { useUiStore } from '@/stores/uiStore'
import { cn } from '@/utils/cn'
import { initialsOf } from '@/utils/initials'
import {
  onResolvedReviewIdsSessionChange,
  readResolvedReviewIdsFromSession,
} from '@/utils/reviewQueueSession'

const NAV = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/datasets', label: 'Data Catalogue', icon: Library },
  { to: '/reviews', label: 'Review Queue', icon: ClipboardList },
  { to: '/rules', label: 'Classification Rules', icon: ShieldCheck },
  { to: '/audit', label: 'Audit Trail', icon: History },
] as const

const REFERENCE_NAV = { to: '/policies', label: 'Policies', icon: FileText } as const

export function Sidebar() {
  const collapsed = useUiStore((s) => s.sidebarCollapsed)
  const toggle = useUiStore((s) => s.toggleSidebar)
  const { data } = useDashboardStats()
  const { data: queue } = useReviewQueue()
  const currentUser = useCurrentUser()
  const [resolvedIds, setResolvedIds] = useState<Set<string>>(() => readResolvedReviewIdsFromSession())

  useEffect(() => onResolvedReviewIdsSessionChange(() => setResolvedIds(readResolvedReviewIdsFromSession())), [])

  const pendingReviewCount = useMemo(() => {
    if (!queue) return data?.awaitingReview ?? 0
    return queue.filter((item) => !resolvedIds.has(item.id)).length
  }, [queue, resolvedIds, data?.awaitingReview])

  return (
    <aside className={cn('sidebar', collapsed && 'sidebar-collapsed')} aria-label="Primary navigation">
      <div className="sidebar-top">
        <div className="wordmark">
          <span className="wordmark-mark" aria-hidden>
            <img src="/gemini-svg.svg" alt="" className="wordmark-logo" />
          </span>
          <strong className="sidebar-label">Data Governance Engine</strong>
        </div>
        <button
          type="button"
          className="icon-button sidebar-toggle"
          onClick={toggle}
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <PanelLeftOpen size={16} /> : <PanelLeftClose size={16} />}
        </button>
      </div>

      <nav className="sidebar-nav">
        {NAV.map((item) => {
          const Icon = item.icon
          const showBadge = item.to === '/reviews' && pendingReviewCount > 0
          return (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) => cn('nav-link', isActive && 'active')}
              title={item.label}
            >
              <Icon size={17} aria-hidden />
              <span className="sidebar-label">{item.label}</span>
              {showBadge ? <em>{pendingReviewCount}</em> : null}
            </NavLink>
          )
        })}

        <div className="sidebar-nav-divider" role="separator" />

        <NavLink
          to={REFERENCE_NAV.to}
          className={({ isActive }) => cn('nav-link', 'nav-link-reference', isActive && 'active')}
          title={`${REFERENCE_NAV.label} — read-only reference`}
        >
          <REFERENCE_NAV.icon size={17} aria-hidden />
          <span className="sidebar-label">{REFERENCE_NAV.label}</span>
          <span className="sidebar-label nav-link-reference-tag">Read only</span>
        </NavLink>
      </nav>

      <div className="sidebar-footer">
        <div className="user-chip">
          <span className="avatar" aria-hidden>
            {initialsOf(currentUser.displayName)}
          </span>
          <span className="user-meta">
            <strong>{currentUser.displayName}</strong>
            <small>Signed in</small>
          </span>
        </div>
      </div>
    </aside>
  )
}
