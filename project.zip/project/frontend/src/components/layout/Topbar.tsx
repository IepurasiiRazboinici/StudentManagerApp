import { useEffect, useRef, useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { useIsFetching } from '@tanstack/react-query'
import { ChevronDown, ChevronRight, Moon, ScanLine, Sun } from 'lucide-react'
import { Button } from '@/components/common'
import { useCurrentUser } from '@/hooks'
import { useUiStore } from '@/stores/uiStore'
import { cn } from '@/utils/cn'
import { initialsOf } from '@/utils/initials'

/** Human-friendly labels for known route segments, used to build breadcrumbs. */
const SEGMENT_LABEL: Record<string, string> = {
  dashboard: 'Dashboard',
  sources: 'Data Sources',
  new: 'New Source',
  file: 'File',
  configure: 'Configure',
  scan: 'Scan Progress',
  datasets: 'Data Catalogue',
  'intended-use': 'Intended Use',
  'make-safe': 'Make Safe',
  reviews: 'Review Queue',
  rules: 'Classification Rules',
  policies: 'Policies',
  audit: 'Audit Trail',
  'data-passport': 'Data Passport',
}

interface Breadcrumb {
  path: string
  label: string
}

function buildBreadcrumbs(pathname: string): Breadcrumb[] {
  const segments = pathname.split('/').filter(Boolean)
  let path = ''

  const crumbs = segments.map((segment) => {
    path += `/${segment}`
    return { path, label: SEGMENT_LABEL[segment] ?? 'Details' }
  })

  return crumbs.length > 0 ? crumbs : [{ path: '/dashboard', label: 'Dashboard' }]
}

export function Topbar() {
  const navigate = useNavigate()
  const location = useLocation()
  const isFetching = useIsFetching() > 0
  const currentUser = useCurrentUser()

  const darkMode = useUiStore((s) => s.darkMode)
  const toggleDarkMode = useUiStore((s) => s.toggleDarkMode)

  const [avatarOpen, setAvatarOpen] = useState(false)
  const avatarRef = useRef<HTMLDivElement>(null)

  const crumbs = buildBreadcrumbs(location.pathname)

  useEffect(() => {
    if (!avatarOpen) return

    const onOutsideClick = (event: MouseEvent) => {
      if (avatarRef.current && !avatarRef.current.contains(event.target as Node)) {
        setAvatarOpen(false)
      }
    }
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setAvatarOpen(false)
    }

    document.addEventListener('mousedown', onOutsideClick)
    document.addEventListener('keydown', onKeyDown)
    return () => {
      document.removeEventListener('mousedown', onOutsideClick)
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [avatarOpen])

  return (
    <header className="topbar">
      <div className={cn('topbar-progress', isFetching && 'topbar-progress-active')} role="progressbar" aria-hidden={!isFetching} aria-label="Loading" />

      <div className="topbar-titles">
        <span className="eyebrow">Workspace</span>
        <nav className="breadcrumbs" aria-label="Breadcrumb">
          {crumbs.map((crumb, index) => {
            const isLast = index === crumbs.length - 1
            return (
              <span key={crumb.path} className="breadcrumb-item">
                {index > 0 ? <ChevronRight size={12} className="breadcrumb-separator" aria-hidden /> : null}
                {isLast ? <strong>{crumb.label}</strong> : <Link to={crumb.path}>{crumb.label}</Link>}
              </span>
            )
          })}
        </nav>
      </div>

      <div className="topbar-actions">
        <Button onClick={() => navigate('/sources/new')}>
          <ScanLine size={16} /> Scan New Data Source
        </Button>

        <button
          type="button"
          className="icon-button dark-mode-toggle"
          onClick={toggleDarkMode}
          aria-pressed={darkMode}
          aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
          title={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
        >
          {darkMode ? <Sun size={16} /> : <Moon size={16} />}
        </button>

        <div className="avatar-menu" ref={avatarRef}>
          <button
            type="button"
            className="avatar-menu-trigger"
            onClick={() => setAvatarOpen((open) => !open)}
            aria-haspopup="true"
            aria-expanded={avatarOpen}
            aria-label="Open account menu"
          >
            <span className="avatar" aria-hidden>
              {initialsOf(currentUser.displayName)}
            </span>
            <ChevronDown size={14} className={cn('avatar-menu-chevron', avatarOpen && 'avatar-menu-chevron-open')} aria-hidden />
          </button>
          {avatarOpen ? (
            <div className="avatar-menu-panel" role="menu" aria-label="Account">
              <div className="avatar-menu-header">
                <span className="avatar" aria-hidden>
                  {initialsOf(currentUser.displayName)}
                </span>
                <span className="user-meta">
                  <strong>{currentUser.displayName}</strong>
                  <small>Signed in</small>
                </span>
              </div>
              <div className="avatar-menu-empty muted">No account actions yet.</div>
            </div>
          ) : null}
        </div>
      </div>
    </header>
  )
}
