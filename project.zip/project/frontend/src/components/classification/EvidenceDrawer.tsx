import { useEffect, useMemo, useState } from 'react'
import { ShieldPlus } from 'lucide-react'
import type { ClassificationTier, EvidenceKind, EvidenceSignal, ReviewDecisionKind } from '@/types'
import { useUiStore } from '@/stores/uiStore'
import { toast } from '@/stores/toastStore'
import { useCurrentUser, useDatasetDetails, useSubmitReview } from '@/hooks'
import {
  Button,
  ConfidenceIndicator,
  Drawer,
  EvidenceBadge,
  ReviewStatusBadge,
  Skeleton,
  TierBadge,
} from '@/components/common'
import { EVIDENCE_KIND_LABEL, formatReviewActionLabel } from '@/utils/labels'
import { formatDateTime } from '@/utils/format'

const EVIDENCE_ORDER: EvidenceKind[] = [
  'EXPLICIT_MARKER',
  'DETECTOR',
  'POLICY',
  'CONTEXT',
  'AGGREGATION',
  'CUSTOM_RULE',
  'HUMAN',
]

function EvidenceGroup({ kind, items }: { kind: EvidenceKind; items: EvidenceSignal[] }) {
  if (items.length === 0) return null
  return (
    <section className="evidence-group" aria-label={`${EVIDENCE_KIND_LABEL[kind]} evidence`} style={{ gap: 8 }}>
      <div className="evidence-group-head">
        <EvidenceBadge kind={kind} />
        <span className="muted">{items.length} signal{items.length > 1 ? 's' : ''}</span>
      </div>
      {items.map((item) => (
        <div key={item.id} className="evidence-item" style={{ gap: 8 }}>
          <div className="evidence-item-head">
            <strong>{item.label}</strong>
            <span className="evidence-weight" title="Signal weight">
              weight {item.weight.toFixed(2)}
            </span>
          </div>
          <p>{item.explanation}</p>
          <div className="evidence-item-meta" style={{ rowGap: 8 }}>
            {item.reference ? <span className="mono">{item.reference}</span> : null}
            {item.matchedMaskedValue ? <span className="mono masked">{item.matchedMaskedValue}</span> : null}
            {item.confidence !== undefined ? <ConfidenceIndicator value={item.confidence} size="sm" /> : null}
            {item.actor ? <span className="muted">{item.actor}</span> : null}
            {item.timestamp ? <span className="muted">{formatDateTime(item.timestamp)}</span> : null}
          </div>
        </div>
      ))}
    </section>
  )
}

export function EvidenceDrawer() {
  const evidence = useUiStore((s) => s.evidence)
  const close = useUiStore((s) => s.closeEvidence)
  const openAddRule = useUiStore((s) => s.openAddRule)
  const { data: detail, isLoading } = useDatasetDetails(evidence.open ? evidence.datasetId : undefined)
  const currentUser = useCurrentUser()
  const submitReview = useSubmitReview()
  const [note, setNote] = useState('')
  const [overrideTier, setOverrideTier] = useState<ClassificationTier | ''>('')

  const fieldItem = detail?.fields.find((f) => f.id === evidence.fieldId)
  const scopedIdentity = `${evidence.datasetId ?? ''}:${evidence.fieldId ?? ''}`
  const overrideOptions: ClassificationTier[] = useMemo(
    () => ['PUBLIC', 'CORPORATE', 'RESTRICTED', 'HIGHLY_RESTRICTED'].filter((tier) => tier !== fieldItem?.classification) as ClassificationTier[],
    [fieldItem?.classification],
  )

  useEffect(() => {
    // Reset reviewer inputs when switching to a different file/field to avoid state leakage.
    setNote('')
    setOverrideTier('')
  }, [scopedIdentity])

  const act = (decision: ReviewDecisionKind) => {
    if (!detail) return
    if (decision === 'OVERRIDE') {
      if (!overrideTier || overrideTier === fieldItem?.classification) {
        toast.error('Select a different tier before submitting override.')
        return
      }
    }

    submitReview.mutate(
      {
        classificationId: `cls-${detail.id}`,
        req: {
          decision,
          note: note.trim() || undefined,
          overrideTier: decision === 'OVERRIDE' && overrideTier ? overrideTier : undefined,
          datasetId: detail.id,
          fileId: detail.sourceLocation,
          evidenceId: evidence.fieldId,
          reviewerId: currentUser.id,
          reviewerName: currentUser.displayName,
        },
      },
      {
        onSuccess: () => {
          toast.success('Evidence decision recorded.')
          setNote('')
          setOverrideTier('')
        },
        onError: () => toast.error('Could not submit the decision.'),
      },
    )
  }

  const startAddRule = () => {
    if (!detail) return
    close()
    openAddRule({ datasetId: detail.id })
  }

  const footer = fieldItem ? (
    <div className="evidence-footer">
      <div className="drawer-section">
        <span className="eyebrow">Reviewer decision</span>
        <p className="muted">Reviewer: {currentUser.displayName}</p>
        <label className="cf-field">
          <span className="cf-label">Override tier</span>
          <select
            className="cf-input"
            value={overrideTier}
            onChange={(e) => setOverrideTier(e.target.value as ClassificationTier | '')}
            aria-label="Override tier"
          >
            <option value="">Select a different tier…</option>
            {overrideOptions.map((tier) => (
              <option key={tier} value={tier}>
                {tier}
              </option>
            ))}
          </select>
        </label>

        <label className="cf-field">
          <span className="cf-label">Reviewer note</span>
          <textarea
            className="cf-input"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Included with Approve, Confirm, Override, Reject, and Escalate decisions..."
            aria-label="Reviewer note"
          />
        </label>
      </div>

      <div className="evidence-footer-actions">
        <Button variant="primary" onClick={() => act('APPROVE')} disabled={submitReview.isPending}>
          Approve
        </Button>
        <Button variant="secondary" onClick={() => act('REQUEST_CHANGES')} disabled={submitReview.isPending}>
          Confirm
        </Button>
        <Button variant="secondary" onClick={() => act('OVERRIDE')} disabled={submitReview.isPending}>
          Override
        </Button>
        <Button variant="ghost" onClick={() => act('REJECT_USAGE')} disabled={submitReview.isPending}>
          Reject
        </Button>
        <Button variant="ghost" onClick={() => act('ESCALATE')} disabled={submitReview.isPending}>
          Escalate
        </Button>
        <Button variant="ghost" onClick={startAddRule}>
          <ShieldPlus size={15} /> Add New Rule
        </Button>
      </div>
    </div>
  ) : null

  return (
    <Drawer
      open={evidence.open}
      onClose={close}
      title={fieldItem ? fieldItem.name : 'Field evidence'}
      subtitle="Evidence returned by the service"
      footer={footer}
    >
      {isLoading ? (
        <div className="stack">
          <Skeleton className="skeleton-line" />
          <Skeleton className="skeleton-panel" />
        </div>
      ) : fieldItem ? (
        <div className="evidence-body" style={{ gap: 16 }}>
          <div className="evidence-summary">
            <TierBadge tier={fieldItem.classification} />
            <ConfidenceIndicator value={fieldItem.confidence} />
            <ReviewStatusBadge status={fieldItem.reviewStatus} />
          </div>

          <div className="drawer-section">
            <span className="eyebrow">System recommendation</span>
            <p>
              <strong>Recommendation:</strong>{' '}
              {fieldItem.reviewStatus === 'REVIEW_REQUIRED'
                ? 'Reviewer confirmation required before final approval.'
                : 'Classification appears ready for confirmation.'}
            </p>
            <p className="muted">Confidence: {fieldItem.confidence}%</p>
            <p className="muted">Rationale: {fieldItem.whyThisTier}</p>
            <p className="muted">
              Evidence ID: {fieldItem.id} · Dataset ID: {detail?.id ?? 'n/a'} · File ID: {detail?.sourceLocation ?? 'n/a'}
            </p>
          </div>

          <div className="why-block">
            <h3>Why this tier?</h3>
            <p>{fieldItem.whyThisTier}</p>
          </div>

          {EVIDENCE_ORDER.map((kind) => (
            <EvidenceGroup key={kind} kind={kind} items={fieldItem.evidence.filter((e) => e.kind === kind)} />
          ))}

          {fieldItem.evidence.length === 0 ? (
            <p className="muted">No additional evidence signals were returned for this field.</p>
          ) : null}

          <div className="reduce-block">
            <h3>What could reduce the tier?</h3>
            <p>{fieldItem.whatReducesTier}</p>
          </div>

          {detail && detail.reviewHistory.length > 0 ? (
            <section className="evidence-group" style={{ gap: 8 }}>
              <div className="evidence-group-head">
                <EvidenceBadge kind="HUMAN" />
                <span className="muted">Human review history</span>
              </div>
              {detail.reviewHistory.map((h) => (
                <div key={h.id} className="evidence-item" style={{ gap: 8 }}>
                  <div className="evidence-item-head">
                    <strong>{formatReviewActionLabel(h.action)}</strong>
                    <span className="muted">{formatDateTime(h.timestamp)}</span>
                  </div>
                  {h.note ? <p>{h.note}</p> : null}
                  <span className="muted">{h.actor}</span>
                </div>
              ))}
            </section>
          ) : null}
        </div>
      ) : (
        <div className="empty-state" style={{ minHeight: 220 }}>
          <p className="muted">Select a field to inspect its evidence.</p>
        </div>
      )}
    </Drawer>
  )
}
