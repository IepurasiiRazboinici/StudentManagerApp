import { useEffect, useMemo, useRef, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { RefreshCw, Send } from 'lucide-react'
import type { RemediationMetrics } from '@/types'
import { usePreviewRemediation, useRemediationPlan, useReviewQueue, useSubmitPlanReview } from '@/hooks'
import { useRemediationStore } from '@/stores/remediationStore'
import { toast } from '@/stores/toastStore'
import {
  Button,
  ErrorState,
  PageHeader,
  Panel,
  SeverityBadge,
  Skeleton,
} from '@/components/common'
import { TransformationCard } from '@/components/remediation/TransformationCard'
import { BeforeAfterPanel } from '@/components/remediation/BeforeAfterPanel'
import { MaskedPreviewTable } from '@/components/remediation/MaskedPreviewTable'

const EMPTY_SELECTION: string[] = []

export function MakeSafePage() {
  const { datasetId } = useParams()
  const navigate = useNavigate()
  const { data: plan, isLoading, isError, refetch } = useRemediationPlan(datasetId)
  const preview = usePreviewRemediation()
  const submit = useSubmitPlanReview()
  const { data: reviewQueue } = useReviewQueue()
  const transformationRefs = useRef<Record<string, HTMLButtonElement | null>>({})
  const [activeTransformationId, setActiveTransformationId] = useState<string | null>(null)

  const planId = plan?.id ?? ''
  const selected = useRemediationStore((s) => s.selectedByPlan[planId] ?? EMPTY_SELECTION)
  const init = useRemediationStore((s) => s.init)
  const toggle = useRemediationStore((s) => s.toggle)

  const recommendedIds = useMemo(() => plan?.transformations.filter((t) => t.recommended).map((t) => t.id) ?? [], [plan])

  useEffect(() => {
    if (plan) init(plan.id, recommendedIds)
  }, [plan, recommendedIds, init])

  useEffect(() => {
    if (selected.length === 0) {
      setActiveTransformationId(null)
    }
  }, [selected.length])

  const selectedKey = selected.join(',')
  useEffect(() => {
    if (!planId || selected.length === 0) return
    const handle = setTimeout(() => {
      preview.mutate({ planId, req: { transformationIds: selected } })
    }, 400)
    return () => clearTimeout(handle)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [planId, selectedKey])

  if (isLoading) {
    return (
      <div className="page-stack">
        <PageHeader eyebrow="Make it Safe" title="Make it Safe" />
        <Panel style={{ padding: 16 }}>
          <Skeleton className="skeleton-title" />
          <Skeleton className="skeleton-panel" />
        </Panel>
      </div>
    )
  }

  if (isError || !plan) {
    return (
      <div className="page-stack">
        <PageHeader eyebrow="Make it Safe" title="Make it Safe" />
        <ErrorState description="The remediation plan could not be generated." onRetry={() => void refetch()} retryLabel="Try again" />
      </div>
    )
  }

  const proposed: RemediationMetrics = preview.data?.proposed ?? plan.proposed
  const hasSelection = selected.length > 0
  const effectiveProposed: RemediationMetrics = hasSelection ? proposed : plan.original
  const maskedRows = hasSelection ? preview.data?.maskedPreview ?? [] : []

  const findTransformationIdForRisk = (field: string): string | undefined =>
    plan.transformations.find((transformation) => transformation.field === field)?.id

  const focusTransformation = (transformationId: string) => {
    setActiveTransformationId(transformationId)
    transformationRefs.current[transformationId]?.scrollIntoView({ behavior: 'smooth', block: 'center' })
    transformationRefs.current[transformationId]?.focus({ preventScroll: true })
  }

  const downloadDisabledReason = !hasSelection
    ? 'Select at least one transformation to download a safe version.'
    : preview.isPending
      ? 'Wait for the remediation preview to finish before downloading.'
      : preview.isError
        ? 'The preview failed — re-evaluate before downloading.'
        : null

  const downloadSafeVersion = () => {
    if (downloadDisabledReason || !plan) return
    const payload = {
      planId: plan.id,
      datasetId: plan.datasetId,
      datasetName: plan.datasetName,
      selectedTransformationIds: selected,
      selectedTransformations: plan.transformations.filter((transformation) => selected.includes(transformation.id)),
      original: plan.original,
      proposed: effectiveProposed,
      maskedPreview: maskedRows,
      generatedAt: new Date().toISOString(),
    }
    const blob = new Blob([`${JSON.stringify(payload, null, 2)}\n`], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${plan.datasetName.replace(/\.[^.]+$/, '') || plan.datasetId}.safe-version.json`
    document.body.appendChild(a)
    a.click()
    a.remove()
    URL.revokeObjectURL(url)
    toast.success('Safe version download started.')
  }

  const submitSafeVersion = () => {
    if (!plan) return

    const alreadyQueued = reviewQueue?.some(
      (r) => r.datasetId === plan.datasetId && r.category === 'PROPOSED_SAFE_VERSION',
    )
    if (alreadyQueued) {
      toast.info(`"${plan.datasetName} (safe)" is already in the review queue.`)
      return
    }

    submit.mutate(
      { planId: plan.id, req: { decision: 'APPROVE' } },
      {
        onSuccess: () => {
          toast.success(`"${plan.datasetName} (safe)" added to the review queue.`)
          navigate(`/reviews?highlight=${plan.id}`)
        },
        onError: () => toast.error('Could not add to the review queue.'),
      },
    )
  }

  return (
    <div className="page-stack">
      <nav className="breadcrumb" aria-label="Breadcrumb">
        <Link to="/datasets">Data Catalogue</Link>
        <span aria-hidden>/</span>
        <Link to={`/datasets/${plan.datasetId}`} className="mono">
          {plan.datasetName}
        </Link>
        <span aria-hidden>/</span>
        <span>Make it Safe</span>
      </nav>

      <PageHeader
        title="Make it Safe"
        description="Select transformations. The service recalculates the safe version — nothing is computed in the browser."
        actions={
          <div className="section-actions" style={{ gap: 8 }}>
            <Button variant="secondary" onClick={() => preview.mutate({ planId: plan.id, req: { transformationIds: selected } })} disabled={preview.isPending}>
              <RefreshCw size={15} className={preview.isPending ? 'spin' : undefined} /> Re-evaluate
            </Button>
            <span title={downloadDisabledReason ?? 'Download the file-specific safe version snapshot.'}>
              <Button variant="secondary" onClick={downloadSafeVersion} disabled={Boolean(downloadDisabledReason)}>
                <Send size={15} /> Download safe version
              </Button>
            </span>
            <Button onClick={submitSafeVersion} disabled={submit.isPending}>
              <Send size={15} /> {submit.isPending ? 'Sending…' : 'Send to Review Queue'}
            </Button>
          </div>
        }
      />

      <div className="make-safe-grid">
        <div className="make-safe-left">
          <Panel style={{ padding: 16 }}>
            <div className="panel-head" style={{ marginBottom: 8 }}>
              <h2>Risk contributors</h2>
            </div>
            <ul className="risk-list">
              {plan.riskContributors.map((rc) => (
                <li key={rc.id} style={{ marginBottom: 8 }}>
                  <button
                    type="button"
                    onClick={() => {
                      const match = findTransformationIdForRisk(rc.field)
                      if (!match) return
                      focusTransformation(match)
                    }}
                    className="risk-head"
                    style={{
                      display: 'grid',
                      gap: 8,
                      width: '100%',
                      border: '1px solid var(--border)',
                      borderRadius: 10,
                      background: 'var(--surface)',
                      padding: 16,
                      textAlign: 'left',
                    }}
                    title="Scroll to the matching transformation"
                  >
                    <div className="risk-head" style={{ gap: 8 }}>
                      <span className="mono">{rc.field}</span>
                      <SeverityBadge severity={rc.severity} />
                    </div>
                    <p>{rc.reason}</p>
                    <span className="muted mono">{rc.relatedRuleOrPolicy}</span>
                  </button>
                </li>
              ))}
            </ul>
          </Panel>

          <Panel style={{ padding: 16 }}>
            <div className="panel-head" style={{ marginBottom: 8 }}>
              <h2>Recommended transformations</h2>
              <span className="muted">Changes re-evaluate automatically</span>
            </div>
            <div className="transformation-grid" style={{ gap: 12 }}>
              {plan.transformations.map((t) => (
                <TransformationCard
                  key={t.id}
                  ref={(node) => {
                    transformationRefs.current[t.id] = node
                  }}
                  transformation={t}
                  selected={selected.includes(t.id)}
                  highlighted={activeTransformationId === t.id}
                  onToggle={() => {
                    setActiveTransformationId(t.id)
                    toggle(plan.id, t.id)
                  }}
                />
              ))}
            </div>
          </Panel>
        </div>

        <div className="make-safe-right">
          <Panel style={{ padding: 16 }}>
            <div className="panel-head" style={{ marginBottom: 8 }}>
              <h2>Before and after</h2>
            </div>
            {!hasSelection ? (
              <p className="muted" style={{ marginTop: 8 }}>Select one or more transformations to preview the safe version.</p>
            ) : preview.isPending ? (
              <div className="stack">
                <Skeleton className="skeleton-line" />
                <Skeleton className="skeleton-panel" />
              </div>
            ) : (
              <BeforeAfterPanel before={plan.original} after={effectiveProposed} />
            )}
          </Panel>

          <Panel style={{ padding: 16 }}>
            <div className="panel-head" style={{ marginBottom: 8 }}>
              <h2>Safe preview</h2>
            </div>
            {!hasSelection ? (
              <p className="muted" style={{ marginTop: 8 }}>Select one or more transformations to generate a safe preview.</p>
            ) : preview.isPending ? (
              <Skeleton className="skeleton-panel" />
            ) : preview.isError ? (
              <div className="inline-error" role="alert">
                <p>The remediation preview could not be generated. Try again.</p>
                <button type="button" className="text-link" onClick={() => preview.mutate({ planId: plan.id, req: { transformationIds: selected } })}>
                  Retry
                </button>
              </div>
            ) : (
              <MaskedPreviewTable rows={maskedRows} />
            )}
          </Panel>
        </div>
      </div>
    </div>
  )
}
