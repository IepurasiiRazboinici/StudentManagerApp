import { describe, expect, it, vi, beforeEach } from 'vitest'
import { screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import type { DataSource, DatasetSummary, UploadedFile } from '@/types'
import { renderWithProviders } from '@/test/utils'
import { CataloguePage } from './CataloguePage'

const rows: DatasetSummary[] = [
  {
    id: 'market_ticks',
    name: 'market_ticks.csv',
    sourceKind: 'FILE',
    sourceName: 'Upload',
    sourceLocation: 'x',
    rowCount: 100,
    fieldCount: 5,
    classification: 'PUBLIC',
    confidence: 93,
    reviewStatus: 'AUTO',
    usageStatus: 'ALLOWED',
    matchedRuleCount: 1,
    hasCustomRule: false,
    canBeMadeSafe: false,
    lastAnalysed: '2026-07-21T10:00:00Z',
  },
  {
    id: 'client_positions_sample',
    name: 'client_positions_sample.csv',
    sourceKind: 'FILE',
    sourceName: 'Upload',
    sourceLocation: 'x',
    rowCount: 5000,
    fieldCount: 6,
    classification: 'HIGHLY_RESTRICTED',
    confidence: 98,
    reviewStatus: 'AUTO',
    usageStatus: 'BLOCKED',
    matchedRuleCount: 1,
    hasCustomRule: false,
    canBeMadeSafe: true,
    lastAnalysed: '2026-07-21T10:00:00Z',
  },
]

const sources: DataSource[] = [
  {
    id: 'src-uploads',
    name: 'Governance file uploads',
    kind: 'FILE',
    locator: 'uploads/',
    status: 'CONNECTED',
    datasetsDiscovered: 6,
    lastScan: '2026-07-21T17:00:00Z',
    createdAt: '2026-06-15T09:00:00Z',
  },
]

const files: UploadedFile[] = [
  {
    id: 'file-ownergroup',
    filename: 'ownergroup_mapping.csv',
    fileType: 'CSV',
    sizeBytes: 48210,
    estimatedRows: 640,
    detectedFields: ['ownergroup'],
    explicitMarkers: [],
    activeRuleIds: ['sys-8'],
    uploadStatus: 'PROFILED',
    sourceId: 'src-uploads',
  },
]

const { hook, navigateMock, startScanMutateMock, deleteSourceMutateMock } = vi.hoisted(() => ({
  hook: { value: {} as ReturnType<typeof mkResult> },
  navigateMock: vi.fn(),
  startScanMutateMock: vi.fn(),
  deleteSourceMutateMock: vi.fn(),
}))

function mkResult(over: Record<string, unknown> = {}) {
  return { data: rows, isLoading: false, isError: false, refetch: () => {}, ...over }
}

vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual<typeof import('react-router-dom')>('react-router-dom')
  return {
    ...actual,
    useNavigate: () => navigateMock,
  }
})

vi.mock('@/hooks', () => ({
  useDatasets: () => hook.value,
  useDataSources: () => ({ data: sources, isLoading: false, isError: false, refetch: () => {} }),
  useUploadedFiles: () => ({ data: files, isLoading: false }),
  useStartScan: () => ({ mutate: startScanMutateMock, isPending: false }),
  useDeleteSource: () => ({ mutate: deleteSourceMutateMock, isPending: false }),
}))

describe('CataloguePage filters', () => {
  beforeEach(() => {
    hook.value = mkResult({})
    navigateMock.mockReset()
    startScanMutateMock.mockReset()
    deleteSourceMutateMock.mockReset()
  })

  it('shows moved connected sources table', () => {
    renderWithProviders(<CataloguePage />)

    expect(screen.getByText(/connected sources/i)).toBeInTheDocument()
    expect(screen.getByRole('button', { name: /scan now/i })).toBeInTheDocument()
    expect(screen.getByRole('button', { name: /reconfigure/i })).toBeInTheDocument()
    expect(screen.getByRole('button', { name: /^delete$/i })).toBeInTheDocument()
  })

  it('renders connected sources panel below datasets panel', () => {
    renderWithProviders(<CataloguePage />)

    const datasetsHeading = screen.getByRole('heading', { name: /^datasets$/i })
    const connectedSourcesHeading = screen.getByRole('heading', { name: /connected sources/i })

    const orderFlag = datasetsHeading.compareDocumentPosition(connectedSourcesHeading)
    expect(orderFlag & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy()
  })

  it('starts scan from moved source table with mapped file context', async () => {
    const user = userEvent.setup()
    renderWithProviders(<CataloguePage />)

    await user.click(screen.getByRole('button', { name: /scan now/i }))

    expect(startScanMutateMock).toHaveBeenCalledWith(
      { sourceId: 'src-uploads', fileId: 'file-ownergroup' },
      expect.anything(),
    )
  })

  it('lists all datasets initially', () => {
    renderWithProviders(<CataloguePage />)
    expect(screen.getByText('market_ticks.csv')).toBeInTheDocument()
    expect(screen.getByText('client_positions_sample.csv')).toBeInTheDocument()
  })

  it('filters by search text', async () => {
    renderWithProviders(<CataloguePage />)
    await userEvent.type(screen.getByLabelText('Search datasets'), 'market')
    expect(screen.getByText('market_ticks.csv')).toBeInTheDocument()
    expect(screen.queryByText('client_positions_sample.csv')).toBeNull()
  })

  it('filters by classification', async () => {
    renderWithProviders(<CataloguePage />)
    await userEvent.selectOptions(screen.getByLabelText('Classification'), 'HIGHLY_RESTRICTED')
    expect(screen.getByText('client_positions_sample.csv')).toBeInTheDocument()
    expect(screen.queryByText('market_ticks.csv')).toBeNull()
  })

  it('shows an error state with retry when the request fails', () => {
    hook.value = mkResult({ data: undefined, isError: true })
    renderWithProviders(<CataloguePage />)
    expect(screen.getByRole('button', { name: /retry/i })).toBeInTheDocument()
  })
})
