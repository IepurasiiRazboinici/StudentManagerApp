import { Link, useNavigate, useParams } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { AlertTriangle, CheckCircle, ChevronRight, Loader, SlidersHorizontal, XCircle } from 'lucide-react'
import type { IntendedUsePurpose, UsageCheckRequest } from '@/types'
import { useCheckIntendedUse, useDatasetDetails } from '@/hooks'
import { useUiStore } from '@/stores/uiStore'
import { Button, PageHeader, Panel } from '@/components/common'
import { INTENDED_USE_LABEL } from '@/utils/labels'

const PURPOSES: IntendedUsePurpose[] = [
  'INTERNAL_ANALYTICS',
  'SHARE_INTERNAL_TEAM',
  'SHARE_EXTERNAL_PARTNER',
  'AI_MODEL_TRAINING',
  'PUBLIC_EXPORT',
  'TESTING',
]

function VerdictCallout({ status, summary }: { status: string; summary: string }) {
  const map: Record<string, { icon: React.ReactNode; cls: string; label: string }> = {
    ALLOWED:      { icon: <CheckCircle size={20} aria-hidden />, cls: 'verdict-allowed',      label: 'Allowed' },
    CONDITIONAL:  { icon: <AlertTriangle size={20} aria-hidden />, cls: 'verdict-conditional', label: 'Conditionally allowed' },
    BLOCKED:      { icon: <XCircle size={20} aria-hidden />, cls: 'verdict-blocked',          label: 'Blocked' },
    NEEDS_REVIEW: { icon: <AlertTriangle size={20} aria-hidden />, cls: 'verdict-review',      label: 'Needs review' },
  }
  const v = map[status] ?? map['NEEDS_REVIEW']
  return (
    <div className={`verdict-callout ${v.cls}`}>
      <div className="verdict-icon">{v.icon}</div>
      <div className="verdict-body">
        <strong className="verdict-label">{v.label}</strong>
        <p className="verdict-summary">{summary}</p>
      </div>
    </div>
  )
}

export function IntendedUsePage() {
  const { datasetId } = useParams()
  const navigate = useNavigate()
  const { data: dataset } = useDatasetDetails(datasetId)
  const check = useCheckIntendedUse(datasetId ?? '')
  const openPolicy = useUiStore((s) => s.openPolicy)

  const { register, handleSubmit } = useForm<UsageCheckRequest>({
    defaultValues: {
      purpose: 'SHARE_EXTERNAL_PARTNER',
      consumerType: 'External partner',
      destinationRegion: 'EU',
      businessPurpose: '',
      retentionPeriod: '90 days',
    },
  })

  const onSubmit = handleSubmit((values) => check.mutate(values))
  const result = check.data

  return (
    <div className="page-stack">
      {/* Breadcrumb */}
      <nav className="breadcrumb" aria-label="Breadcrumb">
        <Link to="/datasets">Data Catalogue</Link>
        <ChevronRight size={13} aria-hidden className="breadcrumb-sep" />
        {dataset ? (
          <Link to={`/datasets/${dataset.id}`} className="mono">{dataset.name}</Link>
        ) : null}
        <ChevronRight size={13} aria-hidden className="breadcrumb-sep" />
        <span>Intended use</span>
      </nav>

      <PageHeader
        title="What do you want to do with this dataset?"
        description="Declare your intent and the service will decide whether the use is allowed, conditional, or blocked."
      />

      <div className="intended-use-grid">
        {/* ── Left column: form ── */}
        <Panel className="iu-form-panel">
          <div className="iu-form-header">
            <h2 className="iu-form-title">Usage details</h2>
            <p className="iu-form-subtitle muted">Fill in the fields below to check whether this usage is permitted.</p>
          </div>

          <form className="iu-form" onSubmit={onSubmit}>
            <label className="cf-field">
              <span className="cf-label">Intended use</span>
              <select className="cf-input" {...register('purpose')}>
                {PURPOSES.map((p) => (
                  <option key={p} value={p}>{INTENDED_USE_LABEL[p]}</option>
                ))}
              </select>
            </label>

            <div className="form-grid">
              <label className="cf-field">
                <span className="cf-label">Consumer type</span>
                <input className="cf-input" {...register('consumerType')} />
              </label>
              <label className="cf-field">
                <span className="cf-label">Destination region</span>
                <input className="cf-input" {...register('destinationRegion')} />
              </label>
            </div>

            <label className="cf-field">
              <span className="cf-label">Business purpose</span>
              <textarea className="cf-input" {...register('businessPurpose')} placeholder="Describe why this data is needed." />
            </label>

            <label className="cf-field">
              <span className="cf-label">Retention period</span>
              <input className="cf-input" {...register('retentionPeriod')} />
            </label>

            <div className="iu-form-actions">
              <Button type="submit" disabled={check.isPending}>
                {check.isPending ? (
                  <><Loader size={14} className="spin" aria-hidden /> Checking…</>
                ) : (
                  'Check intended use'
                )}
              </Button>
            </div>
          </form>
        </Panel>

        {/* ── Right column: result ── */}
        <Panel className="iu-result-panel">
          {check.isPending ? (
            <div className="iu-result-placeholder">
              <div className="iu-skeleton iu-skeleton-verdict" aria-hidden />
              <div className="iu-skeleton iu-skeleton-line" aria-hidden />
              <div className="iu-skeleton iu-skeleton-line iu-skeleton-short" aria-hidden />
            </div>
          ) : check.isError ? (
            <div className="iu-error-state" role="alert">
              <XCircle size={22} aria-hidden />
              <div>
                <strong>Check failed</strong>
                <p className="muted">The usage check could not be completed. Check your inputs and try again.</p>
              </div>
            </div>
          ) : result ? (
            <div className="usage-result">
              {/* Verdict callout — prominent, leads the eye */}
              <VerdictCallout status={result.status} summary={result.summary} />

              {/* Reasons */}
              {result.reasons.length > 0 ? (
                <div className="iu-section">
                  <span className="eyebrow iu-section-label">Reasons</span>
                  <ul className="iu-item-list">
                    {result.reasons.map((r, i) => (
                      <li key={i} className="iu-item">{r}</li>
                    ))}
                  </ul>
                </div>
              ) : null}

              {/* Conditions */}
              {result.conditions.length > 0 ? (
                <div className="iu-section">
                  <span className="eyebrow iu-section-label">Conditions</span>
                  <ul className="iu-item-list">
                    {result.conditions.map((c, i) => (
                      <li key={i} className="iu-item">{c}</li>
                    ))}
                  </ul>
                </div>
              ) : null}

              {/* Policy references */}
              {result.policyReferences.length > 0 ? (
                <div className="iu-section">
                  <span className="eyebrow iu-section-label">Policy references</span>
                  <div className="iu-policy-chips">
                    {result.policyReferences.map((p) => (
                      <button
                        key={p.policyId}
                        type="button"
                        className="badge badge-violet policy-chip"
                        title={`${p.code} · ${p.section}`}
                        onClick={() => openPolicy(p.policyId)}
                      >
                        {p.code} {p.section}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="iu-section">
                  <span className="eyebrow iu-section-label">Policy references</span>
                  <p className="iu-empty-note muted">No applicable policies for this use case.</p>
                </div>
              )}

              {/* Make safe CTA */}
              {result.canBeMadeSafe ? (
                <div className="iu-cta-row">
                  <Button variant="secondary" onClick={() => navigate(`/datasets/${datasetId}/make-safe`)}>
                    <SlidersHorizontal size={15} /> Make it Safe
                  </Button>
                </div>
              ) : null}
            </div>
          ) : (
            <div className="iu-result-placeholder">
              <div className="iu-idle-state">
                <CheckCircle size={32} className="iu-idle-icon" aria-hidden />
                <strong className="iu-idle-heading">No result yet</strong>
                <p className="muted">Submit the form to see whether this use is allowed, conditionally allowed, blocked, or needs review.</p>
              </div>
            </div>
          )}
        </Panel>
      </div>
    </div>
  )
}
