import { useEffect, useMemo, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { ChevronLeft, ChevronRight, Database, Download, ScanLine, Search, Settings2, Trash2 } from 'lucide-react'
import type { ClassificationTier, DatasetSummary, DataSource, ReviewStatus, SourceKind, UsageStatus } from '@/types'
import { useDataSources, useDatasets, useDeleteSource, useStartScan, useUploadedFiles } from '@/hooks'
import { toast } from '@/stores/toastStore'
import { Button, ConfirmDialog, EmptyState, ErrorState, PageHeader, Panel, StatusBadge, TableSkeleton } from '@/components/common'
import { DatasetTable, sortDatasets, structureLabel, type DatasetSortDirection, type DatasetSortKey } from '@/components/datasets/DatasetTable'
import { formatDate, formatNumber } from '@/utils/format'
import {
  REVIEW_STATUS_LABEL,
  TIER_LABEL,
  USAGE_STATUS_LABEL,
} from '@/utils/labels'

const TIERS: ClassificationTier[] = ['PUBLIC', 'CORPORATE', 'RESTRICTED', 'HIGHLY_RESTRICTED', 'UNKNOWN']
const REVIEWS: ReviewStatus[] = ['AUTO', 'CONFIRMED', 'OVERRIDDEN', 'REVIEW_REQUIRED']
const USAGES: UsageStatus[] = ['ALLOWED', 'CONDITIONALLY_ALLOWED', 'BLOCKED', 'REVIEW_REQUIRED']
const PAGE_SIZES = [10, 25, 50] as const
const SOURCE_STATUS_TONE = { CONNECTED: 'green', SCANNING: 'blue', ERROR: 'red', IDLE: 'neutral' } as const

interface ExportDatasetRow {
  id: string
  name: string
  source_kind: SourceKind
  source_name: string
  source_location: string
  structure: 'Structured' | 'Unstructured'
  row_count: number
  field_count: number
  classification: ClassificationTier
  confidence: number
  review_status: ReviewStatus
  usage_status: UsageStatus
  safe_able: string
  matched_rule_count: number
  rule_impact: string
  has_custom_rule: string
  last_analysed: string
  attention_reason: string
}

function buildExportRows(datasets: DatasetSummary[]): ExportDatasetRow[] {
  return datasets.map((d) => ({
    id: d.id,
    name: d.name,
    source_kind: d.sourceKind,
    source_name: d.sourceName,
    source_location: d.sourceLocation,
    structure: structureLabel(d),
    row_count: d.rowCount,
    field_count: d.fieldCount,
    classification: d.classification,
    confidence: d.confidence,
    review_status: d.reviewStatus,
    usage_status: d.usageStatus,
    safe_able: d.canBeMadeSafe ? 'Yes' : 'No',
    matched_rule_count: d.matchedRuleCount,
    rule_impact: `${d.matchedRuleCount} matched rule${d.matchedRuleCount === 1 ? '' : 's'}`,
    has_custom_rule: d.hasCustomRule ? 'Yes' : 'No',
    last_analysed: d.lastAnalysed,
    attention_reason: d.attentionReason ?? '',
  }))
}

function escapeCsv(value: unknown): string {
  const text = value == null ? '' : String(value)
  return /[",\n\r]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text
}

function rowsToCsv(rows: ExportDatasetRow[]): string {
  const headers: Array<keyof ExportDatasetRow> = [
    'id',
    'name',
    'source_kind',
    'source_name',
    'source_location',
    'structure',
    'row_count',
    'field_count',
    'classification',
    'confidence',
    'review_status',
    'usage_status',
    'safe_able',
    'matched_rule_count',
    'rule_impact',
    'has_custom_rule',
    'last_analysed',
    'attention_reason',
  ]

  const lines = [headers.join(',')]
  for (const row of rows) {
    lines.push(headers.map((key) => escapeCsv(row[key])).join(','))
  }
  return `${lines.join('\n')}\n`
}

function downloadTextFile(filename: string, content: string, type: string): void {
  const blob = new Blob([content], { type })
  const url = URL.createObjectURL(blob)
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = filename
  document.body.appendChild(anchor)
  anchor.click()
  anchor.remove()
  URL.revokeObjectURL(url)
}

export function CataloguePage() {
  const navigate = useNavigate()
  const [params, setParams] = useSearchParams()
  const filterSignature = params.toString()
  const { data: sourceRows, isLoading: isSourcesLoading, isError: isSourcesError, refetch: refetchSources } = useDataSources()
  const { data: files } = useUploadedFiles()
  const startScan = useStartScan()
  const deleteSource = useDeleteSource()
  const { data, isLoading, isError, refetch } = useDatasets()
  const [sort, setSort] = useState<{ key: DatasetSortKey | null; direction: DatasetSortDirection }>({
    key: null,
    direction: null,
  })
  const [pageSize, setPageSize] = useState<(typeof PAGE_SIZES)[number]>(25)
  const [pageIndex, setPageIndex] = useState(0)
  const [pendingDelete, setPendingDelete] = useState<DataSource | null>(null)

  const latestFileBySource = useMemo(() => {
    const map = new Map<string, string>()
    for (const file of files ?? []) {
      map.set(file.sourceId, file.id)
    }
    return map
  }, [files])

  useEffect(() => {
    setPageIndex(0)
  }, [filterSignature, sort.key, sort.direction, pageSize])

  const get = (key: string) => params.get(key) ?? ''
  const set = (key: string, value: string) => {
    const next = new URLSearchParams(params)
    if (value) next.set(key, value)
    else next.delete(key)
    setParams(next, { replace: true })
  }

  const filtered = useMemo(() => {
    const search = get('q').toLowerCase()
    return (data ?? []).filter((d) => {
      if (search && !d.name.toLowerCase().includes(search)) return false
      if (get('classification') && d.classification !== get('classification')) return false
      if (get('review') && d.reviewStatus !== get('review')) return false
      if (get('usage') && d.usageStatus !== get('usage')) return false
      if (get('hasCustomRule') === 'true' && !d.hasCustomRule) return false
      if (get('canBeMadeSafe') === 'true' && !d.canBeMadeSafe) return false
      return true
    })
  }, [data, filterSignature])

  const sorted = useMemo(() => sortDatasets(filtered, sort.key, sort.direction), [filtered, sort.key, sort.direction])
  const pageCount = Math.max(1, Math.ceil(sorted.length / pageSize))
  const safePageIndex = Math.min(pageIndex, pageCount - 1)
  const pageStart = sorted.length === 0 ? 0 : safePageIndex * pageSize + 1
  const pageEnd = sorted.length === 0 ? 0 : Math.min(sorted.length, (safePageIndex + 1) * pageSize)
  const paged = useMemo(
    () => sorted.slice(safePageIndex * pageSize, safePageIndex * pageSize + pageSize),
    [sorted, safePageIndex, pageSize],
  )
  const exportRows = useMemo(() => buildExportRows(sorted), [sorted])

  const hasFilters = Array.from(params.keys()).length > 0
  const toggleSort = (key: DatasetSortKey) => {
    setSort((current) => {
      if (current.key !== key) return { key, direction: 'asc' }
      if (current.direction === 'asc') return { key, direction: 'desc' }
      if (current.direction === 'desc') return { key: null, direction: null }
      return { key, direction: 'asc' }
    })
  }

  const downloadCsv = () => {
    if (!exportRows.length) return
    downloadTextFile('datasets-export.csv', rowsToCsv(exportRows), 'text/csv;charset=utf-8')
  }

  const downloadJson = () => {
    if (!exportRows.length) return
    downloadTextFile('datasets-export.json', `${JSON.stringify(exportRows, null, 2)}\n`, 'application/json;charset=utf-8')
  }

  const goToPage = (next: number) => {
    setPageIndex(Math.max(0, Math.min(next, pageCount - 1)))
  }

  const onScanNow = (source: DataSource) => {
    const maybeFileId = source.kind === 'FILE' ? latestFileBySource.get(source.id) : undefined
    startScan.mutate(
      { sourceId: source.id, fileId: maybeFileId },
      {
        onSuccess: (res) => navigate(`/scan/${res.scanId}`),
        onError: () => toast.error('Could not start scan.'),
      },
    )
  }

  const onReconfigure = (source: DataSource) => {
    if (source.kind === 'FILE') {
      const fileId = latestFileBySource.get(source.id)
      if (!fileId) {
        toast.info('No uploaded file found for this source.')
        return
      }
      navigate(`/sources/file/${fileId}/configure`)
      return
    }

    navigate('/sources/new')
  }

  const onConfirmDelete = () => {
    if (!pendingDelete) return

    deleteSource.mutate(pendingDelete.id, {
      onSuccess: () => {
        toast.success('Source removed.')
        setPendingDelete(null)
      },
      onError: () => {
        toast.error('Could not remove source.')
      },
    })
  }

  return (
    <div className="page-stack">
      <PageHeader title="Data Catalogue" description="Datasets classified by the service. Filter, then open a dataset to inspect its evidence." />

      <Panel className="catalogue-filters" style={{ padding: 16 }}>
        <div className="filter-search">
          <Search size={15} aria-hidden />
          <input
            className="cf-input"
            type="search"
            placeholder="Search datasets…"
            value={get('q')}
            onChange={(e) => set('q', e.target.value)}
            aria-label="Search datasets"
          />
        </div>
        <div className="filter-row" style={{ rowGap: 8 }}>
          <select className="cf-input" value={get('classification')} onChange={(e) => set('classification', e.target.value)} aria-label="Classification">
            <option value="">All classifications</option>
            {TIERS.map((t) => (
              <option key={t} value={t}>
                {TIER_LABEL[t]}
              </option>
            ))}
          </select>
          <select className="cf-input" value={get('review')} onChange={(e) => set('review', e.target.value)} aria-label="Review status">
            <option value="">All review states</option>
            {REVIEWS.map((r) => (
              <option key={r} value={r}>
                {REVIEW_STATUS_LABEL[r]}
              </option>
            ))}
          </select>
          <select className="cf-input" value={get('usage')} onChange={(e) => set('usage', e.target.value)} aria-label="Usage status">
            <option value="">All usage states</option>
            {USAGES.map((u) => (
              <option key={u} value={u}>
                {USAGE_STATUS_LABEL[u]}
              </option>
            ))}
          </select>
          <label className="toggle-filter">
            <input type="checkbox" checked={get('hasCustomRule') === 'true'} onChange={(e) => set('hasCustomRule', e.target.checked ? 'true' : '')} />
            Has custom rule
          </label>
          <label className="toggle-filter">
            <input type="checkbox" checked={get('canBeMadeSafe') === 'true'} onChange={(e) => set('canBeMadeSafe', e.target.checked ? 'true' : '')} />
            Can be made safe
          </label>
          {hasFilters ? (
            <Button variant="ghost" size="sm" onClick={() => setParams(new URLSearchParams(), { replace: true })}>
              Clear
            </Button>
          ) : null}
        </div>
      </Panel>

      <Panel style={{ padding: 16 }}>
        <div className="panel-head" style={{ gap: 16, paddingBottom: 8 }}>
          <div>
            <h2>Datasets</h2>
            <p className="muted">
              {sorted.length === 0
                ? 'No datasets to display.'
                : `Showing ${pageStart}–${pageEnd} of ${sorted.length} filtered datasets.`}
            </p>
          </div>
          <div className="section-actions" style={{ gap: 16 }}>
            <div style={{ display: 'grid', gap: 8 }}>
              <span className="eyebrow">Rows per page</span>
              <select
                className="cf-input"
                style={{ width: 110 }}
                value={pageSize}
                onChange={(e) => setPageSize(Number(e.target.value) as (typeof PAGE_SIZES)[number])}
                aria-label="Rows per page"
              >
                {PAGE_SIZES.map((size) => (
                  <option key={size} value={size}>
                    {size}
                  </option>
                ))}
              </select>
            </div>
            <div className="section-actions" style={{ gap: 8, alignItems: 'flex-end' }}>
              <Button variant="secondary" size="sm" onClick={downloadCsv} disabled={!exportRows.length}>
                <Download size={14} /> CSV
              </Button>
              <Button variant="secondary" size="sm" onClick={downloadJson} disabled={!exportRows.length}>
                <Download size={14} /> JSON
              </Button>
            </div>
          </div>
        </div>

        {isLoading ? (
          <TableSkeleton rows={6} cols={9} />
        ) : isError ? (
          <ErrorState description="The catalogue could not be loaded." onRetry={() => void refetch()} />
        ) : sorted.length === 0 ? (
          <EmptyState
            title={hasFilters ? 'No datasets match these filters' : 'No datasets have been scanned yet'}
            description={hasFilters ? 'Adjust or clear the filters to see more results.' : 'Add a data source to begin.'}
          />
        ) : (
          <DatasetTable datasets={paged} sortKey={sort.key} sortDirection={sort.direction} onSort={toggleSort} />
        )}

        {sorted.length > 0 ? (
          <div
            className="section-actions"
            style={{
              justifyContent: 'space-between',
              marginTop: 24,
              paddingTop: 16,
              borderTop: '1px solid var(--border)',
              gap: 16,
            }}
          >
            <span className="muted">
              Page {safePageIndex + 1} of {pageCount} · {sorted.length} filtered dataset{sorted.length === 1 ? '' : 's'}
            </span>
            <div className="section-actions" style={{ gap: 8 }}>
              <Button variant="secondary" size="sm" onClick={() => goToPage(safePageIndex - 1)} disabled={safePageIndex === 0}>
                <ChevronLeft size={14} /> Prev
              </Button>
              <span className="badge badge-neutral" title="Current page">
                {safePageIndex + 1}/{pageCount}
              </span>
              <Button variant="secondary" size="sm" onClick={() => goToPage(safePageIndex + 1)} disabled={safePageIndex >= pageCount - 1}>
                Next <ChevronRight size={14} />
              </Button>
            </div>
          </div>
        ) : null}
      </Panel>

      <Panel className="catalogue-sources-panel">
        <div className="panel-head">
          <h2>Connected sources</h2>
        </div>
        {isSourcesLoading ? (
          <TableSkeleton rows={3} cols={6} />
        ) : isSourcesError ? (
          <ErrorState description="Sources could not be loaded." onRetry={() => void refetchSources()} />
        ) : !sourceRows || sourceRows.length === 0 ? (
          <EmptyState title="No sources yet" description="Add a data source to begin discovering and classifying data." />
        ) : (
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Source</th>
                  <th>Locator</th>
                  <th>Status</th>
                  <th className="num">Datasets</th>
                  <th>Last scan</th>
                  <th aria-label="Actions" />
                </tr>
              </thead>
              <tbody>
                {sourceRows.map((source) => (
                  <tr key={source.id}>
                    <td>
                      <span className="source-cell">
                        <Database size={14} aria-hidden />
                        {source.name}
                      </span>
                    </td>
                    <td className="mono muted">{source.locator}</td>
                    <td>
                      <StatusBadge tone={SOURCE_STATUS_TONE[source.status]}>{source.status}</StatusBadge>
                    </td>
                    <td className="num">{formatNumber(source.datasetsDiscovered)}</td>
                    <td className="muted">{formatDate(source.lastScan)}</td>
                    <td className="row-actions">
                      <Button size="sm" variant="secondary" onClick={() => onScanNow(source)} disabled={startScan.isPending}>
                        <ScanLine size={14} /> Scan now
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => onReconfigure(source)}>
                        <Settings2 size={14} /> Reconfigure
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => setPendingDelete(source)} disabled={deleteSource.isPending}>
                        <Trash2 size={14} /> Delete
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>

      <ConfirmDialog
        open={Boolean(pendingDelete)}
        title="Delete source?"
        message={
          <>
            This permanently removes <strong>{pendingDelete?.name}</strong> and its linked uploaded files.
          </>
        }
        confirmLabel="Delete source"
        destructive
        onConfirm={onConfirmDelete}
        onCancel={() => setPendingDelete(null)}
      />
    </div>
  )
}
