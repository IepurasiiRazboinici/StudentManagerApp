import { Link, useNavigate, useParams } from 'react-router-dom'
import { ShieldCheck, SlidersHorizontal } from 'lucide-react'
import { useDatasetDetails, useSendDatasetForReview } from '@/hooks'
import { useUiStore } from '@/stores/uiStore'
import { toast } from '@/stores/toastStore'
import {
  Button,
  ConfidenceIndicator,
  ErrorState,
  Panel,
  ReviewStatusBadge,
  Skeleton,
  StatusBadge,
  TierBadge,
  UsageStatusBadge,
} from '@/components/common'
import { FieldTable } from '@/components/datasets/FieldTable'
import { PriorityBadge } from '@/components/common'
import { formatDateTime, formatNumber } from '@/utils/format'
import { formatReviewActionLabel } from '@/utils/labels'

function datasetStructureStatus(sourceLocation: string, datasetName: string): 'Structured' | 'Unstructured' | 'Mixed' {
  const target = `${sourceLocation} ${datasetName}`.toLowerCase()
  if (target.endsWith('.csv') || target.endsWith('.json') || target.endsWith('.xlsx') || target.includes('postgres://')) {
    return 'Structured'
  }
  if (target.endsWith('.md') || target.endsWith('.txt') || target.endsWith('.log') || target.endsWith('.fids')) {
    return 'Unstructured'
  }
  return 'Mixed'
}

export function DatasetDetailsPage() {
  const { datasetId } = useParams()
  const navigate = useNavigate()
  const { data, isLoading, isError, refetch } = useDatasetDetails(datasetId)
  const sendForReview = useSendDatasetForReview(datasetId ?? '')
  const openPolicy = useUiStore((s) => s.openPolicy)

  const onSendForHumanReview = () =>
    sendForReview.mutate(undefined, {
      onSuccess: (result) => {
        if (result.queued) {
          toast.success(`${data?.name ?? 'File'} sent for human review.`)
          return
        }
        toast.info('File already in review')
      },
      onError: () => toast.error('Could not send file for human review.'),
    })

  if (isLoading) {
    return (
      <div className="page-stack">
        <Panel>
          <Skeleton className="skeleton-eyebrow" />
          <Skeleton className="skeleton-title" />
          <Skeleton className="skeleton-line" />
        </Panel>
        <Panel>
          <Skeleton className="skeleton-panel" />
        </Panel>
      </div>
    )
  }

  if (isError || !data) {
    return (
      <div className="page-stack">
        <ErrorState description="This dataset could not be loaded." onRetry={() => void refetch()} />
      </div>
    )
  }

  const structureStatus = datasetStructureStatus(data.sourceLocation, data.name)

  return (
    <div className="page-stack">
      <nav className="breadcrumb" aria-label="Breadcrumb">
        <Link to="/datasets">Data Catalogue</Link>
        <span aria-hidden>/</span>
        <span className="mono">{data.name}</span>
      </nav>

      <Panel className="dataset-header" style={{ padding: 16 }}>
        <div className="dataset-header-main" style={{ display: 'grid', gap: 16 }}>
          <h1 className="mono dataset-title">{data.name}</h1>
          <div className="dataset-meta" style={{ gap: 8 }}>
            <span>{data.sourceName}</span>
            <span>·</span>
            <span>{formatNumber(data.rowCount)} rows</span>
            <span>·</span>
            <span>{data.fieldCount} fields</span>
            <span>·</span>
            <span>{structureStatus}</span>
            <span>·</span>
            <span>Last analysed {formatDateTime(data.lastAnalysed)}</span>
          </div>
          <div className="dataset-badges">
            <TierBadge tier={data.classification} />
            <ConfidenceIndicator value={data.confidence} />
            <ReviewStatusBadge status={data.reviewStatus} />
            <UsageStatusBadge status={data.usageStatus} />
          </div>
        </div>
        <div className="dataset-actions" style={{ gap: 8 }}>
          <Button variant="secondary" onClick={() => navigate(`/datasets/${data.id}/intended-use`)}>
            <ShieldCheck size={15} /> Check Intended Use
          </Button>
          <Button variant="secondary" onClick={() => navigate(`/datasets/${data.id}/make-safe`)} disabled={!data.canBeMadeSafe}>
            <SlidersHorizontal size={15} /> Make it Safe
          </Button>
          <Button onClick={onSendForHumanReview} disabled={sendForReview.isPending}>
            {sendForReview.isPending ? 'Sending...' : 'Send for Human Review'}
          </Button>
        </div>
      </Panel>


      <Panel style={{ padding: 16 }}>
        <div className="panel-head">
          <h2>Protection summary</h2>
        </div>
        <p className="summary-text" style={{ marginTop: 8 }}>{data.protectionSummary}</p>
        <div className="why-block" style={{ marginTop: 16 }}>
          <h3>Why this tier?</h3>
          <p>{data.whyThisTier}</p>
        </div>
      </Panel>

      {data.aiClassification ? (
        <Panel style={{ padding: 16 }}>
          <div className="panel-head">
            <h2>AI Classification</h2>
            {data.aiClassification.source === 'conflict' ? (
              <StatusBadge tone="amber">AI disagreed with rules</StatusBadge>
            ) : data.aiClassification.source === 'agreement' ? (
              <StatusBadge tone="green">AI confirmed rules</StatusBadge>
            ) : (
              <StatusBadge tone="neutral">AI not used</StatusBadge>
            )}
          </div>

          {!data.aiClassification.attempted ? (
            <p className="muted" style={{ marginTop: 8 }}>
              No AI/LLM endpoint was configured for this request — showing the deterministic rule-based result only.
            </p>
          ) : (
            <div className="ai-classification-grid" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginTop: 8 }}>
              <div>
                <span className="eyebrow">Rule-based (deterministic)</span>
                <div className="dataset-badges" style={{ marginTop: 8, gap: 8 }}>
                  <TierBadge tier={data.aiClassification.rule.classification} />
                  <ConfidenceIndicator value={data.aiClassification.rule.confidence} size="sm" />
                </div>
                <p style={{ marginTop: 8 }}>{data.aiClassification.rule.explanation}</p>
              </div>
              <div>
                <span className="eyebrow">AI / LLM result</span>
                {data.aiClassification.used && data.aiClassification.ai ? (
                  <>
                    <div className="dataset-badges" style={{ marginTop: 8, gap: 8 }}>
                      <TierBadge tier={data.aiClassification.ai.classification} />
                      <ConfidenceIndicator value={data.aiClassification.ai.confidence} size="sm" />
                    </div>
                    <p style={{ marginTop: 8 }}>{data.aiClassification.ai.explanation}</p>
                    {data.aiClassification.ai.confidenceReasoning ? (
                      <p className="muted" style={{ marginTop: 4 }}>{data.aiClassification.ai.confidenceReasoning}</p>
                    ) : null}
                  </>
                ) : data.aiClassification.error ? (
                  <>
                    <p className="muted" style={{ marginTop: 8 }}>
                      The AI/LLM call failed before returning a response:
                    </p>
                    <p className="mono" style={{ marginTop: 4, whiteSpace: 'pre-wrap' }}>{data.aiClassification.error}</p>
                  </>
                ) : data.aiClassification.rawOutput ? (
                  <>
                    <p className="muted" style={{ marginTop: 8 }}>
                      The model responded, but its output couldn't be parsed into a structured classification. Raw
                      model output is shown below so its analysis is still visible:
                    </p>
                    <p className="mono" style={{ marginTop: 4, whiteSpace: 'pre-wrap' }}>{data.aiClassification.rawOutput}</p>
                  </>
                ) : (
                  <p className="muted" style={{ marginTop: 8 }}>
                    The AI/LLM call was attempted but did not return any usable output.
                  </p>
                )}
              </div>
            </div>
          )}

          {data.aiClassification.source === 'conflict' ? (
            <div className="inline-error" role="alert" style={{ marginTop: 12 }}>
              <p>
                The AI classification disagreed with the deterministic rules. The stricter (more sensitive) result was
                applied as the final classification above, and this asset is marked for human review.
              </p>
            </div>
          ) : null}
        </Panel>
      ) : null}

      {data.remediationSuggestions && data.remediationSuggestions.length > 0 ? (
        <Panel style={{ padding: 16 }}>
          <div className="panel-head">
            <h2>AI Remediation Suggestions</h2>
            <span className="muted">Model-suggested actions to reduce sensitivity before sharing</span>
          </div>
          <div className="table-wrap" style={{ marginTop: 8 }}>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Field</th>
                  <th>Suggested transformation</th>
                  <th>Reason</th>
                  <th>Impact</th>
                </tr>
              </thead>
              <tbody>
                {data.remediationSuggestions.map((suggestion, index) => (
                  <tr key={`${suggestion.fieldName}-${index}`}>
                    <td className="mono">{suggestion.fieldName}</td>
                    <td className="mono">{suggestion.transformation}</td>
                    <td>{suggestion.reason}</td>
                    <td>{suggestion.impact ?? '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      ) : null}

      {data.explicitMarkers.length > 0 ? (
        <Panel style={{ padding: 16 }}>
          <div className="panel-head">
            <h2>Explicit markers</h2>
          </div>
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Marker</th>
                  <th>Resulting tier</th>
                  <th>Confidence</th>
                  <th>Conflict</th>
                </tr>
              </thead>
              <tbody>
                {data.explicitMarkers.map((m) => (
                  <tr key={m.id}>
                    <td>{m.marker}</td>
                    <td>
                      <TierBadge tier={m.resultingTier} />
                    </td>
                    <td>
                      <ConfidenceIndicator value={m.confidence} size="sm" />
                    </td>
                    <td>
                      <StatusBadge tone={m.conflict ? 'amber' : 'green'}>{m.conflict ? 'Conflict' : 'No conflict'}</StatusBadge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      ) : null}

      <Panel style={{ padding: 16 }}>
        <div className="panel-head">
          <h2>Matched rules</h2>
        </div>
        {data.matchedRules.length === 0 ? (
          <p className="muted">No rules matched this dataset.</p>
        ) : (
          <ul className="matched-rules">
            {data.matchedRules.map((rule) => (
              <li key={rule.ruleId}>
                <div className="matched-rule-head" style={{ rowGap: 8 }}>
                  <strong>{rule.name}</strong>
                  <StatusBadge tone={rule.source === 'SYSTEM' ? 'neutral' : 'teal'}>{rule.source === 'SYSTEM' ? 'System' : 'Custom'}</StatusBadge>
                  <TierBadge tier={rule.targetTier} />
                  <PriorityBadge priority={rule.priority} />
                </div>
                <p>{rule.explanation}</p>
                {rule.matchedFields.length > 0 ? (
                  <div className="rule-pills">
                    {rule.matchedFields.map((f) => (
                      <span key={f} className="badge badge-neutral mono">
                        {f}
                      </span>
                    ))}
                  </div>
                ) : null}
              </li>
            ))}
          </ul>
        )}
      </Panel>

      <Panel style={{ padding: 16 }}>
        <div className="panel-head">
          <h2>Fields</h2>
          <span className="muted">Select a field to inspect its evidence</span>
        </div>
        <FieldTable datasetId={data.id} fields={data.fields} />
      </Panel>

      {data.policyReferences.length > 0 ? (
        <Panel style={{ padding: 16 }}>
          <div className="panel-head">
            <h2>Policies</h2>
          </div>
          <div className="rule-pills" style={{ gap: 8, rowGap: 8, marginTop: 8 }}>
            {data.policyReferences.map((p) => (
              <button
                key={p.policyId}
                type="button"
                className="badge badge-violet policy-chip"
                title={`${p.code} · ${p.title}`}
                onClick={() => openPolicy(p.policyId)}
              >
                {p.code} {p.section}
              </button>
            ))}
          </div>
        </Panel>
      ) : null}

      <Panel style={{ padding: 16 }}>
        <div className="panel-head">
          <h2>Review history</h2>
        </div>
        {data.reviewHistory.length === 0 ? (
          <p className="muted">No review decisions have been recorded for this dataset.</p>
        ) : (
          <ul className="timeline" style={{ marginTop: 8 }}>
            {data.reviewHistory.map((h) => (
              <li key={h.id}>
                <span className="timeline-dot" aria-hidden />
                <div style={{ display: 'grid', gap: 8 }}>
                  <strong>{formatReviewActionLabel(h.action)}</strong>
                  {h.note ? <p>{h.note}</p> : null}
                  <span className="muted">
                    {h.actor} · {formatDateTime(h.timestamp)}
                  </span>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </div>
  )
}
