import { beforeEach, describe, expect, it, vi } from 'vitest'
import { screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import type { DatasetDetails } from '@/types'
import { renderRoute } from '@/test/utils'
import { DatasetDetailsPage } from './DatasetDetailsPage'

const { navigateMock, sendForReviewMutateMock, toastSuccessMock, toastInfoMock, toastErrorMock } = vi.hoisted(() => ({
  navigateMock: vi.fn(),
  sendForReviewMutateMock: vi.fn(),
  toastSuccessMock: vi.fn(),
  toastInfoMock: vi.fn(),
  toastErrorMock: vi.fn(),
}))

const dataset: DatasetDetails = {
  id: 'dataset-ownergroup',
  name: 'ownergroup_mapping.csv',
  sourceKind: 'FILE',
  sourceName: 'Upload',
  sourceLocation: 'uploads/ownergroup_mapping.csv',
  rowCount: 640,
  fieldCount: 1,
  classification: 'RESTRICTED',
  confidence: 92,
  reviewStatus: 'AUTO',
  usageStatus: 'REVIEW_REQUIRED',
  matchedRuleCount: 1,
  hasCustomRule: false,
  canBeMadeSafe: true,
  lastAnalysed: '2026-07-22T10:00:00Z',
  protectionSummary: 'Contains identifiers.',
  whyThisTier: 'Sensitive identifiers detected.',
  owner: 'Data Steward Team',
  retention: '12 months',
  explicitMarkers: [],
  matchedRules: [],
  fields: [],
  reviewHistory: [],
  policyReferences: [],
}

vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual<typeof import('react-router-dom')>('react-router-dom')
  return {
    ...actual,
    useNavigate: () => navigateMock,
  }
})

vi.mock('@/hooks', () => ({
  useDatasetDetails: () => ({ data: dataset, isLoading: false, isError: false, refetch: () => {} }),
  useSendDatasetForReview: () => ({ mutate: sendForReviewMutateMock, isPending: false }),
}))

vi.mock('@/stores/uiStore', () => ({
  useUiStore: (selector: (state: { openPolicy: (policyId: string) => void }) => unknown) =>
    selector({ openPolicy: vi.fn() }),
}))

vi.mock('@/stores/toastStore', () => ({
  toast: {
    success: toastSuccessMock,
    info: toastInfoMock,
    error: toastErrorMock,
  },
}))

describe('DatasetDetailsPage review action', () => {
  beforeEach(() => {
    navigateMock.mockReset()
    sendForReviewMutateMock.mockReset()
    toastSuccessMock.mockReset()
    toastInfoMock.mockReset()
    toastErrorMock.mockReset()
  })

  it('shows send-for-review action and removes old actions', () => {
    renderRoute(<DatasetDetailsPage />, {
      path: '/datasets/:datasetId',
      initialEntries: ['/datasets/dataset-ownergroup'],
    })

    expect(screen.getByRole('button', { name: /send for human review/i })).toBeInTheDocument()
    expect(screen.queryByRole('button', { name: /reclassify/i })).toBeNull()
    expect(screen.queryByRole('button', { name: /add new rule/i })).toBeNull()
  })

  it('shows duplicate notification when the file is already in review', async () => {
    sendForReviewMutateMock.mockImplementation((_value, options) => {
      options?.onSuccess?.({ queued: false, reviewItemId: 'rev-1' })
    })

    const user = userEvent.setup()
    renderRoute(<DatasetDetailsPage />, {
      path: '/datasets/:datasetId',
      initialEntries: ['/datasets/dataset-ownergroup'],
    })

    await user.click(screen.getByRole('button', { name: /send for human review/i }))

    expect(sendForReviewMutateMock).toHaveBeenCalledWith(undefined, expect.anything())
    expect(toastInfoMock).toHaveBeenCalledWith('File already in review')
  })
})

