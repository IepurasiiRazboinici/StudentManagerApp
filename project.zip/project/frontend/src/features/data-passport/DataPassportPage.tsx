import { Link, useNavigate, useParams } from 'react-router-dom'
import { Download, FileJson, ShieldCheck } from 'lucide-react'
import { useApproveSafeVersion, useDataPassport } from '@/hooks'
import { dataPassportApi } from '@/api'
import { jsPDF } from 'jspdf'
import { toast } from '@/stores/toastStore'
import {
  Button,
  EmptyState,
  ErrorState,
  KeyValue,
  PageHeader,
  Panel,
  Skeleton,
  TierBadge,
} from '@/components/common'
import { formatDateTime } from '@/utils/format'

export function DataPassportPage() {
  const { datasetId } = useParams()
  const navigate = useNavigate()
  const { data: passport, isLoading, isError, refetch } = useDataPassport(datasetId)
  const approve = useApproveSafeVersion()

  const startDownload = (blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob)
    const anchor = document.createElement('a')
    anchor.href = url
    anchor.download = filename
    anchor.click()
    URL.revokeObjectURL(url)
  }

  const readBlobBytes = async (blob: Blob): Promise<ArrayBuffer> => {
    if (typeof blob.arrayBuffer === 'function') {
      return blob.arrayBuffer()
    }

    return await new Promise<ArrayBuffer>((resolve, reject) => {
      const reader = new FileReader()
      reader.onerror = () => reject(new Error('Could not read PDF payload'))
      reader.onload = () => {
        if (reader.result instanceof ArrayBuffer) {
          resolve(reader.result)
          return
        }
        reject(new Error('Could not read PDF payload'))
      }
      reader.readAsArrayBuffer(blob)
    })
  }

  const buildFallbackPdf = () => {
    if (!passport) return null

    const doc = new jsPDF()
    doc.setFontSize(14)
    doc.text(`Data Passport ${passport.reference}`, 14, 16)
    doc.setFontSize(10)
    doc.text(`Dataset: ${passport.originalDatasetName}`, 14, 28)
    doc.text(`Safe version: ${passport.safeDatasetName}`, 14, 34)
    doc.text(`Approved classification: ${passport.approvedClassification}`, 14, 40)
    doc.text(`Reviewer: ${passport.reviewer}`, 14, 46)
    doc.text(`Approved at: ${formatDateTime(passport.approvedAt)}`, 14, 52)
    doc.text(`Audit reference: ${passport.auditReference}`, 14, 58)
    return doc.output('blob')
  }

  const generate = () =>
    approve.mutate(datasetId ?? '', {
      onSuccess: () => toast.success('Safe version approved — Data Passport generated.'),
      onError: () => toast.error('Could not approve the safe version.'),
    })

  const download = async (kind: 'pdf' | 'json') => {
    if (!passport) return

    if (kind === 'json') {
      const blob = new Blob([JSON.stringify(passport, null, 2)], { type: 'application/json;charset=utf-8' })
      startDownload(blob, `${passport.reference}.json`)
      toast.success('Data Passport JSON exported.')
      return
    }

    try {
      const backendPdf = await dataPassportApi.downloadPassportPdf(datasetId ?? '')
      if (backendPdf) {
        const bytes = await readBlobBytes(backendPdf)
        const signature = new TextDecoder().decode(bytes.slice(0, 4))
        if (signature !== '%PDF') {
          throw new Error('Downloaded payload is not a valid PDF')
        }

        startDownload(new Blob([bytes], { type: 'application/pdf' }), `${passport.reference}.pdf`)
        toast.success('Data Passport PDF download started.')
        return
      }

      const fallback = buildFallbackPdf()
      if (!fallback) {
        toast.error('A valid PDF could not be generated.')
        return
      }

      startDownload(fallback, `${passport.reference}.pdf`)
      toast.success('Data Passport PDF generated locally.')
    } catch {
      toast.error('A valid PDF could not be generated.')
    }
  }

  if (isLoading) {
    return (
      <div className="page-stack">
        <PageHeader eyebrow="Data Passport" title="Data Passport" />
        <Panel>
          <Skeleton className="skeleton-title" />
          <Skeleton className="skeleton-panel" />
        </Panel>
      </div>
    )
  }

  if (isError) {
    return (
      <div className="page-stack">
        <PageHeader eyebrow="Data Passport" title="Data Passport" />
        <ErrorState description="The Data Passport could not be loaded." onRetry={() => void refetch()} />
      </div>
    )
  }

  if (!passport) {
    return (
      <div className="page-stack">
        <PageHeader eyebrow="Data Passport" title="Data Passport" />
        <EmptyState
          title="No Data Passport yet"
          description="A Data Passport is generated when a safe version is approved for this dataset."
          action={
            <Button onClick={generate} disabled={approve.isPending}>
              <ShieldCheck size={15} /> {approve.isPending ? 'Approving…' : 'Approve safe version'}
            </Button>
          }
        />
      </div>
    )
  }

  return (
    <div className="page-stack">
      <PageHeader
        eyebrow="Data Passport"
        title={passport.reference}
        description="A signed record of how a dataset was made safe and approved."
        actions={
          <div className="passport-header-actions">
            <div className="passport-action-group" role="group" aria-label="Export actions">
              <span className="eyebrow">Export actions</span>
              <div className="passport-action-row">
                <Button variant="secondary" onClick={() => void download('pdf')}>
                  <Download size={15} /> Download PDF
                </Button>
                <Button variant="secondary" onClick={() => void download('json')}>
                  <FileJson size={15} /> Export JSON
                </Button>
              </div>
            </div>

            <div className="passport-action-group passport-action-group-secondary" role="group" aria-label="Navigation">
              <span className="eyebrow">Navigation</span>
              <Button variant="ghost" onClick={() => navigate('/datasets')}>
                Return to Catalogue
              </Button>
            </div>
          </div>
        }
      />

      <Panel className="passport-panel passport-panel-polished">
        <section className="passport-section passport-section-card">
          <div className="passport-section-head passport-section-head-stacked">
            <div className="passport-section-copy">
              <span className="eyebrow">Classification</span>
              <h2>Classification</h2>
              <p>Compare the original dataset with the approved safe version and its final release classification.</p>
            </div>
          </div>

          <div className="passport-tiers">
            <div className="passport-tier-card">
              <span className="eyebrow">Original dataset</span>
              <span className="mono">{passport.originalDatasetName}</span>
              <TierBadge tier={passport.originalClassification} />
            </div>
            <div className="passport-tier-card">
              <span className="eyebrow">Approved safe version</span>
              <span className="mono">{passport.safeDatasetName}</span>
              <TierBadge tier={passport.approvedClassification} />
            </div>
          </div>

          <div className="passport-classification-note">
            <strong>Approved outcome</strong>
            <p>
              Protection controls reduced the approved release level from {passport.originalClassification} to{' '}
              {passport.approvedClassification} for the safe dataset.
            </p>
          </div>
        </section>

        <section className="passport-section passport-section-card">
          <div className="passport-section-head passport-section-head-stacked">
            <div className="passport-section-copy">
              <span className="eyebrow">Transformations</span>
              <h2>Transformations</h2>
              <p>Review the masking, removal, and rule logic applied before the safe version was approved.</p>
            </div>
          </div>

          <div className="passport-detail-grid">
            <PassportList
              title="Applied transformations"
              description="Operational steps that were executed to produce the approved safe version."
              items={passport.appliedTransformations}
              empty="No transformations recorded."
            />
            <PassportList
              title="System rules applied"
              description="Baseline rules enforced automatically by the platform during protection review."
              items={passport.systemRulesApplied}
              empty="No system rules recorded."
            />
            <PassportList
              title="Custom rules applied"
              description="Additional organisation-specific rules used to support the final decision."
              items={passport.customRulesApplied}
              empty="No custom rules applied."
            />
          </div>
        </section>

        <section className="passport-section passport-section-card">
          <div className="passport-section-head passport-section-head-stacked">
            <div className="passport-section-copy">
              <span className="eyebrow">Approvals</span>
              <h2>Approvals</h2>
              <p>See who approved the safe version, when it was approved, and any conditions that still apply.</p>
            </div>
          </div>

          <div className="passport-approval-summary">
            <ShieldCheck size={18} />
            <div>
              <strong>Safe version approved</strong>
              <p>{passport.safeDatasetName} has been approved for the intended use described below.</p>
            </div>
          </div>

          <div className="key-value-grid passport-facts-grid">
            <KeyValue label="Intended use" value={passport.intendedUse} />
            <KeyValue label="Reviewer" value={passport.reviewer} />
            <KeyValue label="Approved classification" value={<TierBadge tier={passport.approvedClassification} />} />
            <KeyValue label="Approved at" value={formatDateTime(passport.approvedAt)} />
          </div>

          <PassportList
            title="Remaining conditions"
            description="Follow-up controls or contractual obligations that remain attached to this release."
            items={passport.remainingConditions}
            empty="No remaining conditions."
          />
        </section>

        <section className="passport-section passport-section-card">
          <div className="passport-section-head passport-section-head-stacked">
            <div className="passport-section-copy">
              <span className="eyebrow">References</span>
              <h2>References</h2>
              <p>Use these identifiers and links to trace the source dataset, the approved safe version, and its audit trail.</p>
            </div>
          </div>

          <div className="key-value-grid passport-facts-grid passport-reference-grid">
            <KeyValue label="Passport reference" value={<span className="mono">{passport.reference}</span>} />
            <KeyValue label="Audit reference" value={<span className="mono">{passport.auditReference}</span>} />
            <KeyValue label="Original dataset" value={<span className="mono">{passport.originalDatasetName}</span>} />
            <KeyValue label="Safe dataset" value={<span className="mono">{passport.safeDatasetName}</span>} />
          </div>

          <div className="passport-reference-links">
            {datasetId ? (
              <Link className="passport-reference-link text-link" to={`/datasets/${datasetId}`}>
                Open original dataset
              </Link>
            ) : null}
            {datasetId ? (
              <Link className="passport-reference-link text-link" to={`/datasets/${datasetId}/make-safe`}>
                Review transformation plan
              </Link>
            ) : null}
            <Link className="passport-reference-link text-link" to="/audit">
              Open audit trail
            </Link>
          </div>
        </section>
      </Panel>
    </div>
  )
}

function PassportList({
  title,
  items,
  empty,
  description,
}: {
  title: string
  items: string[]
  empty: string
  description?: string
}) {
  return (
    <section className="passport-subsection">
      <div className="passport-subsection-head">
        <h3>{title}</h3>
        {description ? <p>{description}</p> : null}
      </div>

      {items.length === 0 ? (
        <p className="muted passport-list-empty">{empty}</p>
      ) : (
        <ul className="plain-list passport-list">
          {items.map((item, index) => (
            <li key={`${title}-${index}`}>{item}</li>
          ))}
        </ul>
      )}
    </section>
  )
}

