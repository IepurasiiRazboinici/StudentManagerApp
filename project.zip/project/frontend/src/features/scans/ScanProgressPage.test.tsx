import { beforeEach, describe, expect, it, vi } from 'vitest'
import { screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import type { ScanStatus } from '@/types'
import { renderRoute } from '@/test/utils'
import { ScanProgressPage } from './ScanProgressPage'

const { cancelMutateMock, useScanStatusMock, toastSuccessMock } = vi.hoisted(() => ({
  cancelMutateMock: vi.fn(),
  useScanStatusMock: vi.fn(),
  toastSuccessMock: vi.fn(),
}))

const runningScan: ScanStatus = {
  id: 'scan-1',
  state: 'RUNNING',
  progress: 42,
  currentStageKey: 'fields',
  fileName: 'mixed_market_client_log.csv',
  fieldsAnalysed: 8,
  matchedRuleCount: 2,
  stages: [
    { key: 'received', label: 'File received', status: 'COMPLETE' },
    { key: 'fields', label: 'Fields analysed', status: 'ACTIVE' },
    { key: 'completed', label: 'Scan completed', status: 'PENDING' },
  ],
  events: [{ id: 'e1', timestamp: '2026-07-23T10:00:00Z', stageKey: 'fields', message: 'Fields analysed in progress.' }],
  provisionalResult: null,
}

const completedScan: ScanStatus = {
  ...runningScan,
  state: 'COMPLETE',
  progress: 100,
  currentStageKey: 'completed',
  stages: runningScan.stages.map((stage) => ({ ...stage, status: 'COMPLETE' })),
  provisionalResult: {
    datasetId: 'dataset-1',
    datasetName: 'mixed_market_client_log.csv',
    classification: 'HIGHLY_RESTRICTED',
    confidence: 96,
    reviewStatus: 'AUTO',
  },
}

vi.mock('@/hooks', () => ({
  useScanStatus: (...args: unknown[]) => useScanStatusMock(...args),
  useCancelScan: () => ({ mutate: cancelMutateMock, isPending: false }),
}))

vi.mock('@/stores/toastStore', () => ({
  toast: {
    success: toastSuccessMock,
    error: vi.fn(),
    info: vi.fn(),
  },
}))

describe('ScanProgressPage polling + cancel', () => {
  beforeEach(() => {
    cancelMutateMock.mockReset()
    useScanStatusMock.mockReset()
    toastSuccessMock.mockReset()
  })

  it('requests scan status with polling enabled and allows cancellation', async () => {
    useScanStatusMock.mockReturnValue({ data: runningScan, isLoading: false, isError: false, refetch: () => {} })
    const user = userEvent.setup()

    renderRoute(<ScanProgressPage />, {
      path: '/scan/:scanId',
      initialEntries: ['/scan/scan-1'],
    })

    expect(useScanStatusMock).toHaveBeenCalledWith('scan-1', { polling: true, intervalMs: 1200 })

    await user.click(screen.getByRole('button', { name: /cancel scan/i }))
    expect(cancelMutateMock).toHaveBeenCalledWith('scan-1', expect.anything())
  })

  it('shows completion toast when backend reports scan complete', () => {
    useScanStatusMock.mockReturnValue({ data: completedScan, isLoading: false, isError: false, refetch: () => {} })

    renderRoute(<ScanProgressPage />, {
      path: '/scan/:scanId',
      initialEntries: ['/scan/scan-1'],
    })

    expect(toastSuccessMock).toHaveBeenCalledWith('Scan completed.')
  })
})

