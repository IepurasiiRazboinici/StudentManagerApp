import { useEffect, useRef } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { Check, Loader2, XCircle } from 'lucide-react'
import { useCancelScan, useScanStatus } from '@/hooks'
import { toast } from '@/stores/toastStore'
import {
  Button,
  ConfidenceIndicator,
  ErrorState,
  PageHeader,
  Panel,
  ProgressBar,
  Skeleton,
  TierBadge,
} from '@/components/common'
import { cn } from '@/utils/cn'

export function ScanProgressPage() {
  const { scanId } = useParams()
  const navigate = useNavigate()
  const { data, isLoading, isError, refetch } = useScanStatus(scanId, { polling: true, intervalMs: 1200 })
  const cancelScan = useCancelScan()
  const notifiedCompleteRef = useRef(false)

  useEffect(() => {
    if (!data || notifiedCompleteRef.current) return
    if (data.state === 'COMPLETE') {
      notifiedCompleteRef.current = true
      toast.success('Scan completed.')
    }
  }, [data])

  if (isLoading) {
    return (
      <div className="page-stack scan-page">
        <PageHeader eyebrow="Scan" title="Scan in progress" />
        <Panel>
          <Skeleton className="skeleton-line" />
          <Skeleton className="skeleton-panel" />
        </Panel>
      </div>
    )
  }

  if (isError || !data) {
    return (
      <div className="page-stack scan-page">
        <PageHeader eyebrow="Scan" title="Scan" />
        <ErrorState description="The scan status could not be loaded." onRetry={() => void refetch()} />
      </div>
    )
  }

  const done = data.state === 'COMPLETE'
  const failed = data.state === 'FAILED'
  const progress = Math.max(0, Math.min(100, data.progress))
  const currentIndex = data.stages.findIndex((stage) => stage.key === data.currentStageKey)
  const fallbackIndex = Math.max(0, Math.floor((progress / 100) * Math.max(data.stages.length - 1, 0)))
  const activeIndex = currentIndex >= 0 ? currentIndex : fallbackIndex
  const currentStage = data.stages[activeIndex] ?? data.stages[data.stages.length - 1]

  return (
    <div className="page-stack scan-page">
      <PageHeader
        eyebrow="Scan"
        title={done ? 'Scan completed' : failed ? 'Scan cancelled' : 'Scan in progress'}
        description={
          <>
            File <span className="mono">{data.fileName}</span>
          </>
        }
        actions={
          done ? (
            <>
              <Button variant="secondary" onClick={() => navigate('/datasets')}>
                Open Data Catalogue
              </Button>
              {data.provisionalResult ? (
                <Button onClick={() => navigate(`/datasets/${data.provisionalResult?.datasetId}`)}>Open dataset</Button>
              ) : null}
            </>
          ) : failed ? (
            <Button variant="secondary" onClick={() => navigate('/sources/new')}>
              Back to sources
            </Button>
          ) : (
            <Button
              variant="ghost"
              onClick={() => {
                if (!scanId) return
                cancelScan.mutate(scanId, {
                  onSuccess: () => {
                    toast.info('Scan cancelled.')
                    navigate('/sources/new')
                  },
                  onError: () => toast.error('Could not cancel the scan.'),
                })
              }}
              disabled={cancelScan.isPending || !scanId}
            >
              <XCircle size={15} /> {cancelScan.isPending ? 'Cancelling...' : 'Cancel scan'}
            </Button>
          )
        }
      />

      <Panel>
        <div className="scan-progress-head">
          <div className="scan-progress-copy">
            <span className="eyebrow">{done ? 'Complete' : failed ? 'Cancelled at stage' : 'Current stage'}</span>
            <strong>{currentStage?.label ?? 'Processing'}</strong>
          </div>
          <span className="scan-progress-pct">{progress}%</span>
        </div>
        <ProgressBar value={progress} label={`Scan ${progress}%`} />

        <div className="scan-progress-grid">
          <ol className="scan-stage-list">
            {data.stages.map((stage, index) => {
              const complete = stage.status === 'COMPLETE' || index < activeIndex
              const active = stage.status === 'ACTIVE' || (index === activeIndex && !done && !failed)
              return (
                <li key={stage.key} className={cn(complete && 'complete', active && 'active')}>
                  <span className="scan-stage-icon" aria-hidden>
                    {complete ? <Check size={13} /> : active ? <Loader2 size={13} className="spin" /> : null}
                  </span>
                  {stage.label}
                </li>
              )
            })}
          </ol>

          <div className="scan-side">
            <div className="scan-metrics">
              <div>
                <strong>{data.fieldsAnalysed}</strong>
                <span>Fields analysed</span>
              </div>
              <div>
                <strong>{data.matchedRuleCount}</strong>
                <span>Matched rules</span>
              </div>
            </div>

            {done && data.provisionalResult ? (
              <div className="provisional-result">
                <span className="eyebrow">Provisional result</span>
                <span className="mono">{data.provisionalResult.datasetName}</span>
                <div className="provisional-badges">
                  <TierBadge tier={data.provisionalResult.classification} />
                  <ConfidenceIndicator value={data.provisionalResult.confidence} size="sm" />
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </Panel>
    </div>
  )
}

