import { beforeEach, describe, expect, it, vi } from 'vitest'
import { screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import type { AuditEvent } from '@/types'
import { renderWithProviders } from '@/test/utils'
import { getMaxAllowedDate, getMinAllowedDate } from '@/utils/dateBounds'
import { AuditTrailPage } from './AuditTrailPage'

const LONG_DETAIL =
  'This is a long audit detail that should be truncated for readability in the event list until the user asks to expand it for full reporting context. '

const events: AuditEvent[] = [
  {
    id: 'with-link',
    type: 'FILE_UPLOADED',
    summary: 'File uploaded',
    detail: LONG_DETAIL.repeat(2),
    actor: 'You',
    datasetId: 'dataset-123',
    reference: 'file-1',
    timestamp: '2026-07-22T12:00:00Z',
  },
  {
    id: 'filtered-in',
    type: 'SOURCE_CREATED',
    summary: 'Source created',
    detail: 'Filtered row',
    actor: 'System',
    datasetId: 'dataset-keep',
    reference: 'ref-keep',
    timestamp: '2026-07-23T13:00:00Z',
  },
  {
    id: 'filtered-out',
    type: 'SOURCE_CREATED',
    summary: 'Source created old',
    detail: 'Older row',
    actor: 'System',
    datasetId: 'dataset-old',
    reference: 'ref-old',
    timestamp: '2026-07-10T13:00:00Z',
  },
  ...Array.from({ length: 27 }, (_, index): AuditEvent => ({
    id: `row-${index}`,
    type: 'SOURCE_CREATED',
    summary: `Event ${index}`,
    detail: `Detail ${index}`,
    actor: index % 2 === 0 ? 'You' : 'System',
    timestamp: `2026-07-23T${String((index % 7) + 12).padStart(2, '0')}:00:00Z`,
  })),
]

vi.mock('@/hooks', () => ({
  useAuditEvents: () => ({ data: events, isLoading: false, isError: false, refetch: () => {} }),
}))

describe('AuditTrailPage', () => {
  beforeEach(() => {
    vi.restoreAllMocks()
  })

  it('supports date range filtering and client-side pagination at 25 rows per page', async () => {
    const user = userEvent.setup()
    renderWithProviders(<AuditTrailPage />)

    const sinceInput = screen.getByLabelText('Since date') as HTMLInputElement
    const untilInput = screen.getByLabelText('Until date') as HTMLInputElement
    expect(sinceInput).toHaveAttribute('min', getMinAllowedDate())
    expect(untilInput).toHaveAttribute('min', getMinAllowedDate())
    expect(sinceInput).toHaveAttribute('max', getMaxAllowedDate())
    expect(untilInput).toHaveAttribute('max', getMaxAllowedDate())

    expect(screen.getByText(/1 \/ 2/)).toBeInTheDocument()
    expect(screen.getByText(/Showing 1–25 of 30 events/)).toBeInTheDocument()

    await user.click(screen.getByRole('button', { name: /next/i }))
    expect(screen.getByText(/2 \/ 2/)).toBeInTheDocument()
    expect(screen.getByText(/Showing 26–30 of 30 events/)).toBeInTheDocument()

    await user.type(sinceInput, '2026-07-22')
    await user.type(untilInput, '2026-07-23')

    expect(screen.getByText(/Showing 1–25 of 29 events/)).toBeInTheDocument()
    expect(screen.queryByText('Source created old')).not.toBeInTheDocument()
  })

  it('renders dataset link and expands long detail per event', async () => {
    const user = userEvent.setup()
    renderWithProviders(<AuditTrailPage />)

    const datasetLink = screen.getByRole('link', { name: /open dataset dataset-123/i })
    expect(datasetLink).toHaveAttribute('href', '/datasets/dataset-123')

    expect(screen.getByText(/Show more/)).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: 'Show more' }))
    expect(screen.getByText(/Show less/)).toBeInTheDocument()
  })

  it('exports active filtered data with date-stamped CSV filename', async () => {
    const user = userEvent.setup()

    const OriginalBlob = globalThis.Blob
    class FakeBlob {
      parts: unknown[]
      type: string
      size: number
      constructor(parts: unknown[], options?: { type?: string }) {
        this.parts = parts
        this.type = options?.type ?? ''
        this.size = String(parts[0] ?? '').length
      }
    }
    Object.defineProperty(globalThis, 'Blob', {
      writable: true,
      configurable: true,
      value: FakeBlob,
    })

    const createObjectURLMock = vi.fn<(blob: FakeBlob) => string>(() => 'blob:url')
    const revokeObjectURLMock = vi.fn<(url: string) => void>()
    Object.defineProperty(URL, 'createObjectURL', {
      writable: true,
      configurable: true,
      value: createObjectURLMock as unknown as typeof URL.createObjectURL,
    })
    Object.defineProperty(URL, 'revokeObjectURL', {
      writable: true,
      configurable: true,
      value: revokeObjectURLMock,
    })

    const clickMock = vi.fn()
    const appendSpy = vi.spyOn(document.body, 'append').mockImplementation(() => undefined)
    const removeSpy = vi.spyOn(HTMLElement.prototype, 'remove').mockImplementation(() => undefined)
    const nativeCreateElement = document.createElement.bind(document)
    let createdAnchor: HTMLAnchorElement | undefined
    vi.spyOn(document, 'createElement').mockImplementation(((tagName: string) => {
      const node = nativeCreateElement(tagName as keyof HTMLElementTagNameMap)
      if (tagName === 'a') {
        const anchor = node as HTMLAnchorElement
        anchor.click = clickMock
        createdAnchor = anchor
      }
      return node
    }) as typeof document.createElement)

    renderWithProviders(<AuditTrailPage />)

    await user.type(screen.getByLabelText('Since date'), '2026-07-22')
    await user.selectOptions(screen.getByLabelText('Export format'), 'CSV')
    await user.click(screen.getByRole('button', { name: /export/i }))

    expect(createdAnchor).toBeDefined()
    expect(createdAnchor!.download).toMatch(/^cache-flow-audit-\d{4}-\d{2}-\d{2}\.csv$/)
    expect(clickMock).toHaveBeenCalled()

    const blob = createObjectURLMock.mock.calls[0]?.[0]
    expect(blob).toBeInstanceOf(FakeBlob)
    const csv = String(blob?.parts[0] ?? '')
    expect(blob.type).toContain('text/csv')
    expect(csv).toContain('filtered-in')
    expect(csv).toContain('dataset-keep')
    expect(csv).not.toContain('filtered-out')

    expect(revokeObjectURLMock).toHaveBeenCalledWith('blob:url')
    Object.defineProperty(globalThis, 'Blob', {
      writable: true,
      configurable: true,
      value: OriginalBlob,
    })
    appendSpy.mockRestore()
    removeSpy.mockRestore()
  })
})


