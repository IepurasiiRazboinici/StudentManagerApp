import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { Clock, Download, Search, User } from 'lucide-react'
import type { AuditEvent, AuditEventType } from '@/types'
import { useAuditEvents } from '@/hooks'
import { toast } from '@/stores/toastStore'
import { Button, EmptyState, ErrorState, PageHeader, Panel, TableSkeleton } from '@/components/common'
import { clampDateInput, getMaxAllowedDate, getMinAllowedDate, isWithinDateWindow } from '@/utils/dateBounds'
import { AUDIT_EVENT_LABEL } from '@/utils/labels'
import { formatDateTime } from '@/utils/format'

const PAGE_SIZE = 25
const DETAIL_PREVIEW_LIMIT = 150

function toCsv(events: AuditEvent[]): string {
  const header = ['id', 'type', 'typeLabel', 'summary', 'detail', 'actor', 'datasetId', 'reference', 'timestamp']
  const escape = (value: string) => `"${value.replace(/"/g, '""')}"`
  const rows = events.map((event) =>
    [
      event.id,
      event.type,
      AUDIT_EVENT_LABEL[event.type],
      event.summary,
      event.detail,
      event.actor,
      event.datasetId ?? '',
      event.reference ?? '',
      event.timestamp,
    ].map((v) => escape(String(v))),
  )
  return [header.join(','), ...rows.map((row) => row.join(','))].join('\n')
}

function downloadFile(content: string, type: string, fileName: string): void {
  const blob = new Blob([content], { type })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = fileName
  document.body.append(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}

export function AuditTrailPage() {
  const { data, isLoading, isError, refetch } = useAuditEvents()
  const [search, setSearch] = useState('')
  const [type, setType] = useState<AuditEventType | 'ALL'>('ALL')
  const [actor, setActor] = useState('ALL')
  const [since, setSince] = useState('')
  const [until, setUntil] = useState('')
  const [exportFormat, setExportFormat] = useState<'JSON' | 'CSV'>('JSON')
  const [page, setPage] = useState(1)
  const [expandedById, setExpandedById] = useState<Record<string, boolean>>({})
  const minDate = getMinAllowedDate()
  const maxDate = getMaxAllowedDate()

  const actors = useMemo(() => Array.from(new Set((data ?? []).map((event) => event.actor))), [data])

  const filtered = useMemo(
    () =>
      (data ?? []).filter((event) => {
        if (search && !`${event.summary} ${event.detail}`.toLowerCase().includes(search.toLowerCase())) return false
        if (type !== 'ALL' && event.type !== type) return false
        if (actor !== 'ALL' && event.actor !== actor) return false
        if (!isWithinDateWindow(event.timestamp, since, until)) return false
        return true
      }),
    [data, search, type, actor, since, until],
  )

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE))
  const currentPage = Math.min(page, totalPages)
  const startIndex = (currentPage - 1) * PAGE_SIZE
  const paged = filtered.slice(startIndex, startIndex + PAGE_SIZE)

  const updatePage = (nextPage: number) => {
    setPage(Math.min(Math.max(nextPage, 1), totalPages))
  }

  const resetToFirstPage = () => setPage(1)

  const toggleExpanded = (id: string) => {
    setExpandedById((prev) => ({ ...prev, [id]: !prev[id] }))
  }

  const onExport = () => {
    const stamp = getMaxAllowedDate()
    if (exportFormat === 'JSON') {
      downloadFile(JSON.stringify(filtered, null, 2), 'application/json', `cache-flow-audit-${stamp}.json`)
    } else {
      downloadFile(toCsv(filtered), 'text/csv;charset=utf-8;', `cache-flow-audit-${stamp}.csv`)
    }
    toast.success('Audit events exported.')
  }

  return (
    <div className="page-stack audit-page">
      <PageHeader
        title="Audit Trail"
        description="Every governance action, in order, with export-ready reporting context."
      />

      {/* Filter + Export toolbar */}
      <Panel className="audit-toolbar-panel">
        <div className="audit-toolbar">
          {/* Filters — left side */}
          <div className="audit-filter-group">
            <div className="filter-search">
              <Search size={15} aria-hidden />
              <input
                className="cf-input"
                type="search"
                placeholder="Search events…"
                value={search}
                onChange={(event) => {
                  setSearch(event.target.value)
                  resetToFirstPage()
                }}
                aria-label="Search events"
              />
            </div>
            <div className="filter-row">
              <select
                className="cf-input"
                value={type}
                onChange={(event) => {
                  setType(event.target.value as AuditEventType | 'ALL')
                  resetToFirstPage()
                }}
                aria-label="Event type"
              >
                <option value="ALL">All event types</option>
                {(Object.keys(AUDIT_EVENT_LABEL) as AuditEventType[]).map((eventType) => (
                  <option key={eventType} value={eventType}>
                    {AUDIT_EVENT_LABEL[eventType]}
                  </option>
                ))}
              </select>
              <select
                className="cf-input"
                value={actor}
                onChange={(event) => {
                  setActor(event.target.value)
                  resetToFirstPage()
                }}
                aria-label="Actor"
              >
                <option value="ALL">All actors</option>
                {actors.map((value) => (
                  <option key={value} value={value}>
                    {value}
                  </option>
                ))}
              </select>
              <input
                className="cf-input"
                type="date"
                value={since}
                min={minDate}
                max={maxDate}
                onChange={(event) => {
                  const next = clampDateInput(event.target.value)
                  setSince(next)
                  if (until && next && until < next) setUntil(next)
                  resetToFirstPage()
                }}
                aria-label="Since date"
              />
              <input
                className="cf-input"
                type="date"
                value={until}
                min={minDate}
                max={maxDate}
                onChange={(event) => {
                  const next = clampDateInput(event.target.value)
                  setUntil(next)
                  if (since && next && since > next) setSince(next)
                  resetToFirstPage()
                }}
                aria-label="Until date"
              />
            </div>
          </div>

          {/* Export — right side */}
          <div className="audit-export-group" aria-label="Export actions">
            <span className="audit-export-label eyebrow">Export</span>
            <div className="audit-export-actions">
              <select
                className="cf-input audit-export-select"
                value={exportFormat}
                onChange={(event) => setExportFormat(event.target.value as 'JSON' | 'CSV')}
                aria-label="Export format"
              >
                <option value="JSON">JSON</option>
                <option value="CSV">CSV</option>
              </select>
              <Button variant="secondary" onClick={onExport} disabled={filtered.length === 0}>
                <Download size={15} /> Export
              </Button>
            </div>
          </div>
        </div>
      </Panel>

      <Panel className="audit-list-panel">
        {isLoading ? (
          <div className="audit-skeleton-wrap">
            <TableSkeleton rows={7} cols={4} />
          </div>
        ) : isError ? (
          <ErrorState description="Audit events could not be loaded." onRetry={() => void refetch()} />
        ) : filtered.length === 0 ? (
          <div className="audit-empty-wrap">
            <EmptyState title="No matching events" description="Adjust the filters to see more governance activity." />
          </div>
        ) : (
          <>
            <div className="audit-list-head">
              Showing {startIndex + 1}–{Math.min(startIndex + PAGE_SIZE, filtered.length)} of {filtered.length} events
            </div>
            <ul className="audit-list">
              {paged.map((event) => {
                const isExpanded = Boolean(expandedById[event.id])
                const shouldTruncate = event.detail.length > DETAIL_PREVIEW_LIMIT
                const detail = shouldTruncate && !isExpanded ? `${event.detail.slice(0, DETAIL_PREVIEW_LIMIT)}...` : event.detail
                return (
                  <li key={event.id}>
                    {/* Event type badge — left column */}
                    <div className="audit-type-col">
                      <span className={`audit-type-badge audit-type-badge-${event.type.toLowerCase()}`}>
                        {AUDIT_EVENT_LABEL[event.type]}
                      </span>
                    </div>

                    {/* Body — centre column */}
                    <div className="audit-body">
                      <strong>{event.summary}</strong>
                      <p className="muted">{detail}</p>
                      <div className="audit-context-row">
                        {event.datasetId ? (
                          <Link to={`/datasets/${encodeURIComponent(event.datasetId)}`} className="text-link" aria-label={`Open dataset ${event.datasetId}`}>
                            Open dataset
                          </Link>
                        ) : null}
                        {event.reference ? <span className="badge badge-blue mono">Ref: {event.reference}</span> : null}
                        {shouldTruncate ? (
                          <button type="button" className="text-link" onClick={() => toggleExpanded(event.id)}>
                            {isExpanded ? 'Show less' : 'Show more'}
                          </button>
                        ) : null}
                      </div>
                    </div>

                    {/* Meta — right column */}
                    <div className="audit-meta">
                      <span className="audit-actor">
                        <User size={11} aria-hidden />
                        {event.actor}
                      </span>
                      <span className="audit-timestamp">
                        <Clock size={11} aria-hidden />
                        {formatDateTime(event.timestamp)}
                      </span>
                    </div>
                  </li>
                )
              })}
            </ul>

            <div className="audit-pagination">
              <Button variant="secondary" size="sm" onClick={() => updatePage(currentPage - 1)} disabled={currentPage <= 1}>
                Previous
              </Button>
              <span className="audit-page-indicator" aria-current="page" aria-label={`Page ${currentPage} of ${totalPages}`}>
                {currentPage} / {totalPages}
              </span>
              <Button variant="secondary" size="sm" onClick={() => updatePage(currentPage + 1)} disabled={currentPage >= totalPages}>
                Next
              </Button>
            </div>
          </>
        )}
      </Panel>
    </div>
  )
}
