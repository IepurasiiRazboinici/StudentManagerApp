import type { PieSectorShapeProps } from 'recharts'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Cell, Pie, PieChart, ResponsiveContainer, Sector, Tooltip } from 'recharts'
import type { ClassificationTier } from '@/types'
import { useDashboardStats } from '@/hooks'
import { Button, CardsSkeleton, ErrorState, PageHeader, Panel, ReviewStatusBadge, TierBadge } from '@/components/common'
import { AUDIT_EVENT_LABEL, TIER_LABEL } from '@/utils/labels'
import { formatRelative } from '@/utils/format'
import { cn } from '@/utils/cn'

const TIER_HEX: Record<ClassificationTier, string> = {
  PUBLIC: '#475467',
  CORPORATE: '#175CD3',
  RESTRICTED: '#B54708',
  HIGHLY_RESTRICTED: '#B42318',
  UNKNOWN: '#667085',
}

const DONUT_ORDER: ClassificationTier[] = ['PUBLIC', 'CORPORATE', 'RESTRICTED', 'HIGHLY_RESTRICTED', 'UNKNOWN']

/** Renders each donut sector, giving the active (selected) tier a thicker ring and a subtle scale-up. */
function renderDonutSegment(activeIndex: number) {
  return function DonutSegment(props: PieSectorShapeProps) {
    const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill, index } = props
    const isActive = index === activeIndex
    return (
      <g aria-current={isActive ? 'true' : undefined} className={cn('donut-segment', isActive && 'donut-segment-active')}>
        <Sector
          cx={cx}
          cy={cy}
          innerRadius={innerRadius}
          outerRadius={isActive ? (outerRadius ?? 0) + 8 : outerRadius}
          startAngle={startAngle}
          endAngle={endAngle}
          fill={fill}
          stroke={isActive ? fill : 'none'}
          strokeWidth={isActive ? 3 : 0}
          cursor="pointer"
        />
      </g>
    )
  }
}

export function DashboardPage() {
  const navigate = useNavigate()
  const { data, isLoading, isError, refetch, isRefetching } = useDashboardStats()

  const [activeIndex, setActiveIndex] = useState(0)

  if (isLoading) {
    return (
      <div className="page-stack">
        <PageHeader title="Data Protection Overview" description="Discover sensitive data, review decisions, and create safer versions." />
        <CardsSkeleton count={6} />
      </div>
    )
  }

  if (isError || !data) {
    return (
      <div className="page-stack">
        <PageHeader title="Data Protection Overview" />
        <ErrorState description="The dashboard could not be loaded." onRetry={() => void refetch()} />
      </div>
    )
  }

  const donut = DONUT_ORDER.map((tier) => ({ tier, name: TIER_LABEL[tier], value: data.distribution[tier] })).filter((d) => d.value > 0)

  const metrics = [
    { label: 'Datasets analysed', value: data.datasetsAnalysed, onClick: () => navigate('/datasets') },
    { label: 'Highly Restricted', value: data.highlyRestricted, onClick: () => navigate('/datasets?classification=HIGHLY_RESTRICTED') },
    { label: 'Awaiting review', value: data.awaitingReview, onClick: () => navigate('/reviews') },
    { label: 'Active custom rules', value: data.activeCustomRules, onClick: () => navigate('/rules') },
    { label: 'Safe versions created', value: data.safeVersionsCreated },
    { label: 'Policy gaps', value: data.policyGaps, onClick: () => navigate('/reviews') },
  ]

  return (
    <div className="page-stack">
      <PageHeader
        eyebrow={isRefetching ? 'Refreshing…' : undefined}
        title="Data Protection Overview"
        description="Discover sensitive data, review decisions, and create safer versions."
      />

      <div className="metrics-grid">
        {metrics.map((m) =>
          m.onClick ? (
            <button key={m.label} type="button" className="metric-tile" onClick={m.onClick}>
              <strong>{m.value}</strong>
              <span>{m.label}</span>
            </button>
          ) : (
            <div key={m.label} className="metric-tile">
              <strong>{m.value}</strong>
              <span>{m.label}</span>
            </div>
          ),
        )}
      </div>

      <div className="dashboard-grid">
        <Panel className="distribution-panel">
          <div className="panel-head">
            <h2>Classification distribution</h2>
            <span className="muted">Click a segment to filter the catalogue</span>
          </div>
          <div className="donut-wrap">
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie
                  data={donut}
                  dataKey="value"
                  nameKey="name"
                  innerRadius={64}
                  outerRadius={96}
                  paddingAngle={2}
                  shape={renderDonutSegment(activeIndex)}
                  onMouseEnter={(_data, index) => setActiveIndex(index)}
                  onClick={(_data, index) => {
                    setActiveIndex(index)
                    const seg = donut[index]
                    if (seg) navigate(`/datasets?classification=${seg.tier}`)
                  }}
                >
                  {donut.map((d) => (
                    <Cell key={d.tier} fill={TIER_HEX[d.tier]} className="donut-cell" />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <ul className="donut-legend">
              {donut.map((d, index) => (
                <li key={d.tier}>
                  <button
                    type="button"
                    className={cn('donut-legend-item', index === activeIndex && 'donut-legend-item-active')}
                    aria-current={index === activeIndex ? 'true' : undefined}
                    onMouseEnter={() => setActiveIndex(index)}
                    onFocus={() => setActiveIndex(index)}
                    onClick={() => {
                      setActiveIndex(index)
                      navigate(`/datasets?classification=${d.tier}`)
                    }}
                  >
                    <span className="legend-swatch" style={{ background: TIER_HEX[d.tier] }} aria-hidden />
                    {d.name}
                    <strong>{d.value}</strong>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </Panel>

        <Panel className="priority-panel">
          <div className="panel-head">
            <h2 className="panel-title-chip panel-title-chip-amber">Priority review items</h2>
          </div>
          <ul className="priority-list">
            {data.priorityReviewItems.map((item) => (
              <li key={item.datasetId}>
                <button type="button" onClick={() => navigate(`/datasets/${item.datasetId}`)}>
                  <span className="priority-name mono">{item.datasetName}</span>
                  <span className="priority-badges">
                    <TierBadge tier={item.classification} />
                    {item.reviewStatus === 'REVIEW_REQUIRED' ? <ReviewStatusBadge status={item.reviewStatus} /> : null}
                  </span>
                  <span className="priority-note muted">{item.note}</span>
                </button>
              </li>
            ))}
          </ul>
        </Panel>
      </div>

      <Panel className="opportunities-panel">
        <div className="panel-head">
          <h2>Data protection opportunities</h2>
        </div>
        <p className="opportunity-message">{data.protectionOpportunities.message}</p>
        <Button variant="secondary" onClick={() => navigate('/datasets?canBeMadeSafe=true')}>
          Review opportunities
        </Button>
      </Panel>

      <Panel className="activity-panel">
        <div className="panel-head">
          <h2 className="panel-title-chip panel-title-chip-blue">Recent governance activity</h2>
          <button type="button" className="text-link" onClick={() => navigate('/audit')}>
            View audit trail
          </button>
        </div>
        <ul className="activity-list">
          {data.recentActivity.map((event) => (
            <li key={event.id}>
              <span className="activity-type">{AUDIT_EVENT_LABEL[event.type]}</span>
              <span className="activity-summary">{event.summary}</span>
              <span className="muted">{formatRelative(event.timestamp)}</span>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  )
}
