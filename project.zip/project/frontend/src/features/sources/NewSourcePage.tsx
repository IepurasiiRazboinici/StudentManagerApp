import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useForm, useWatch } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { useMutation } from '@tanstack/react-query'
import { z } from 'zod'
import { AlertCircle, CheckCircle2, Database, FileUp, LoaderCircle, ShieldCheck } from 'lucide-react'
import { sourcesApi } from '@/api'
import type { PostgresTestResult } from '@/api/sourcesApi'
import { useCreateSource, useUploadFile } from '@/hooks'
import { toast } from '@/stores/toastStore'
import { Button, PageHeader, Panel, TabButton } from '@/components/common'
import { UploadDropzone } from '@/components/datasets/UploadDropzone'
import type { AcceptedFile } from '@/components/datasets/UploadDropzone'

const postgresSchema = z.object({
  name: z.string().min(2, 'Use a recognisable connection name.'),
  host: z.string().min(2, 'Host is required.'),
  port: z.number().int().min(1).max(65535),
  database: z.string().min(1, 'Database is required.'),
  username: z.string().min(1, 'Username is required.'),
  password: z.string().min(1, 'Password is required.'),
})
type PostgresValues = z.infer<typeof postgresSchema>

type ConnectionState =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'success'; result: PostgresTestResult }
  | { status: 'error'; message: string }

function fingerprintConnection(values: Pick<PostgresValues, 'host' | 'port' | 'database' | 'username' | 'password'>): string {
  return `${values.host}|${values.port}|${values.database}|${values.username}|${values.password}`
}

export function NewSourcePage() {
  const navigate = useNavigate()
  const [mode, setMode] = useState<'upload' | 'postgres'>('upload')
  const upload = useUploadFile()
  const [uploadProgress, setUploadProgress] = useState(0)
  const createSource = useCreateSource()
  const [connectionState, setConnectionState] = useState<ConnectionState>({ status: 'idle' })
  const [verifiedFingerprint, setVerifiedFingerprint] = useState<string | null>(null)

  const form = useForm<PostgresValues>({
    resolver: zodResolver(postgresSchema),
    defaultValues: { name: 'Risk warehouse', host: 'warehouse.internal', port: 5432, database: 'risk', username: 'governance_reader', password: '' },
  })

  const watchedConnection = useWatch({
    control: form.control,
    name: ['host', 'port', 'database', 'username', 'password'],
  })

  const activeFingerprint = useMemo(
    () => fingerprintConnection({
      host: watchedConnection[0] ?? '',
      port: watchedConnection[1] ?? 5432,
      database: watchedConnection[2] ?? '',
      username: watchedConnection[3] ?? '',
      password: watchedConnection[4] ?? '',
    }),
    [watchedConnection],
  )

  const testConnection = useMutation({
    mutationFn: (values: PostgresValues) => sourcesApi.testPostgres(values),
  })

  const isConnectionVerified = connectionState.status === 'success' && verifiedFingerprint === activeFingerprint

  const onAccepted = (file: AcceptedFile) => {
    setUploadProgress(0)
    upload.mutate({ ...file, onProgress: setUploadProgress }, {
      onSuccess: (created) => {
        setUploadProgress(100)
        toast.success('File uploaded.')
        navigate(`/sources/file/${created.id}/configure`)
      },
      onError: () => {
        setUploadProgress(0)
        toast.error('Upload failed. Try again.')
      },
    })
  }

  const onCreatePostgres = form.handleSubmit((values) => {
    if (!isConnectionVerified) {
      toast.error('Test the connection successfully before adding this source.')
      return
    }

    createSource.mutate(
      { name: values.name, kind: 'POSTGRESQL', locator: `${values.host}:${values.port}/${values.database}` },
      {
        onSuccess: () => {
          toast.success('PostgreSQL source connected.')
          navigate('/sources/new')
        },
        onError: () => toast.error('Could not create the source.'),
      },
    )
  })

  const onTestConnection = form.handleSubmit((values) => {
    setConnectionState({ status: 'loading' })
    setVerifiedFingerprint(null)
    testConnection.mutate(values, {
      onSuccess: (result) => {
        setConnectionState({ status: 'success', result })
        setVerifiedFingerprint(fingerprintConnection(values))
      },
      onError: (error) => {
        const message = error instanceof Error ? error.message : 'Connection refused'
        setConnectionState({ status: 'error', message })
      },
    })
  })

  return (
    <div className="page-stack new-source-page">
      <PageHeader eyebrow="Data Sources" title="Add a data source" description="Upload a file or connect a PostgreSQL database." />

      <div className="tabs" role="tablist" aria-label="Source type">
        <TabButton active={mode === 'upload'} onClick={() => setMode('upload')}>
          <FileUp size={15} /> Upload file
        </TabButton>
        <TabButton active={mode === 'postgres'} onClick={() => setMode('postgres')}>
          <Database size={15} /> PostgreSQL
        </TabButton>
      </div>

      {mode === 'upload' ? (
        <Panel className="source-card source-card-upload">
          <div className="source-upload-head">
            <h2>Upload a file</h2>
            <p>Drop a file or browse locally. It is sent to the backend for profiling and scan setup.</p>
          </div>
          <section className="source-form-section" aria-label="Upload dataset file">
            <header>
              <h3>Dataset file</h3>
              <p>Accepted formats: CSV, JSON, TXT, Markdown and XLSX.</p>
            </header>
            <UploadDropzone onAccepted={onAccepted} isUploading={upload.isPending} progress={uploadProgress} />
          </section>
        </Panel>
      ) : (
        <Panel className="source-card source-card-postgres">
          <div className="source-postgres-head">
            <h2>Connect PostgreSQL</h2>
            <p>Enter credentials, test the connection, then add the source once verified.</p>
          </div>
          <form className="source-form source-form-postgres" onSubmit={onCreatePostgres}>
            <section className="source-form-section" aria-label="Connection details">
              <header>
                <h3>Connection details</h3>
                <p>This label appears in your source list and audit history.</p>
              </header>
              <label className="cf-field">
                <span className="cf-label">Connection name</span>
                <input className="cf-input" {...form.register('name')} />
                {form.formState.errors.name ? <small className="field-error">{form.formState.errors.name.message}</small> : null}
              </label>
            </section>

            <section className="source-form-section" aria-label="Database credentials">
              <header>
                <h3>Database credentials</h3>
                <p>Use a read-only user to validate and discover schemas safely.</p>
              </header>
              <div className="source-form-grid">
                <label className="cf-field">
                  <span className="cf-label">Host</span>
                  <input className="cf-input mono" {...form.register('host')} />
                  {form.formState.errors.host ? <small className="field-error">{form.formState.errors.host.message}</small> : null}
                </label>
                <label className="cf-field">
                  <span className="cf-label">Port</span>
                  <input className="cf-input mono" type="number" {...form.register('port', { valueAsNumber: true })} />
                  {form.formState.errors.port ? <small className="field-error">{form.formState.errors.port.message}</small> : null}
                </label>
                <label className="cf-field">
                  <span className="cf-label">Database</span>
                  <input className="cf-input mono" {...form.register('database')} />
                  {form.formState.errors.database ? <small className="field-error">{form.formState.errors.database.message}</small> : null}
                </label>
                <label className="cf-field">
                  <span className="cf-label">Username</span>
                  <input className="cf-input mono" {...form.register('username')} />
                  {form.formState.errors.username ? <small className="field-error">{form.formState.errors.username.message}</small> : null}
                </label>
                <label className="cf-field source-form-grid-span-2">
                  <span className="cf-label">Password</span>
                  <input className="cf-input" type="password" {...form.register('password')} />
                  {form.formState.errors.password ? <small className="field-error">{form.formState.errors.password.message}</small> : null}
                </label>
              </div>
            </section>

            <div className="source-postgres-state-wrap">
              {connectionState.status === 'idle' ? (
                <div className="connection-state connection-state-idle" role="status">
                  <ShieldCheck size={18} />
                  <div>
                    <strong>Ready to test</strong>
                    <p>Run a connection test to unlock source creation.</p>
                  </div>
                </div>
              ) : null}
              {connectionState.status === 'loading' ? (
                <div className="connection-state connection-state-loading" role="status" aria-live="polite">
                  <LoaderCircle className="spin" size={18} />
                  <div>
                    <strong>Testing connection</strong>
                    <p>Validating credentials and discovering metadata...</p>
                  </div>
                </div>
              ) : null}
              {connectionState.status === 'success' ? (
                <div className="connection-state connection-state-success" role="status">
                  <CheckCircle2 size={18} />
                  <div>
                    <strong>Connected</strong>
                    <p>
                      Found {connectionState.result.schemas} schemas / {connectionState.result.tables} tables / {connectionState.result.fields} fields.
                    </p>
                  </div>
                </div>
              ) : null}
              {connectionState.status === 'error' ? (
                <div className="connection-state connection-state-error" role="alert">
                  <AlertCircle size={18} />
                  <div>
                    <strong>Connection refused</strong>
                    <p>{connectionState.message}</p>
                  </div>
                </div>
              ) : null}
            </div>

            <div className="form-actions source-form-actions">
              <Button type="button" variant="secondary" onClick={onTestConnection} disabled={testConnection.isPending}>
                {testConnection.isPending ? 'Testing...' : 'Test connection'}
              </Button>
              <Button type="submit" disabled={createSource.isPending || !isConnectionVerified}>
                {createSource.isPending ? 'Connecting...' : 'Add source'}
              </Button>
            </div>
          </form>
        </Panel>
      )}
    </div>
  )
}
