import { beforeEach, describe, expect, it, vi } from 'vitest'
import { screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { renderWithProviders } from '@/test/utils'
import { NewSourcePage } from './NewSourcePage'

const { navigateMock, createSourceMutateMock, toastErrorMock } = vi.hoisted(() => ({
  navigateMock: vi.fn(),
  createSourceMutateMock: vi.fn(),
  toastErrorMock: vi.fn(),
}))

vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual<typeof import('react-router-dom')>('react-router-dom')
  return {
    ...actual,
    useNavigate: () => navigateMock,
  }
})

vi.mock('@/stores/toastStore', () => ({
  toast: {
    success: vi.fn(),
    error: toastErrorMock,
  },
}))

vi.mock('@/hooks', () => ({
  useUploadFile: () => ({ mutate: vi.fn(), isPending: false }),
  useCreateSource: () => ({ mutate: createSourceMutateMock, isPending: false }),
}))

vi.mock('@/api', () => ({
  sourcesApi: {
    testPostgres: vi.fn(async (input: { password: string }) => {
      if (input.password !== '1234') {
        throw new Error('Connection refused')
      }

      return { ok: true, schemas: 3, tables: 11, fields: 86 }
    }),
  },
}))

describe('NewSourcePage PostgreSQL flow', () => {
  beforeEach(() => {
    navigateMock.mockReset()
    createSourceMutateMock.mockReset()
    toastErrorMock.mockReset()
  })

  it('keeps Add source disabled until test connection succeeds', async () => {
    const user = userEvent.setup()
    renderWithProviders(<NewSourcePage />)

    await user.click(screen.getByRole('tab', { name: /postgresql/i }))

    const addSourceButton = screen.getByRole('button', { name: /add source/i })
    expect(addSourceButton).toBeDisabled()

    await user.type(screen.getByLabelText(/password/i), 'badpass')
    await user.click(screen.getByRole('button', { name: /test connection/i }))

    const errorAlert = await screen.findByRole('alert')
    expect(errorAlert).toHaveTextContent(/connection refused/i)
    expect(addSourceButton).toBeDisabled()

    await user.clear(screen.getByLabelText(/password/i))
    await user.type(screen.getByLabelText(/password/i), '1234')
    await user.click(screen.getByRole('button', { name: /test connection/i }))

    expect(await screen.findByText(/^connected$/i)).toBeInTheDocument()
    expect(screen.getByText(/found 3 schemas \/ 11 tables \/ 86 fields/i)).toBeInTheDocument()

    await waitFor(() => {
      expect(addSourceButton).toBeEnabled()
    })
  })

  it('submits source creation only after a successful test', async () => {
    const user = userEvent.setup()
    renderWithProviders(<NewSourcePage />)

    await user.click(screen.getByRole('tab', { name: /postgresql/i }))

    await user.type(screen.getByLabelText(/password/i), '1234')
    await user.click(screen.getByRole('button', { name: /test connection/i }))
    await screen.findByText(/^connected$/i)

    await user.click(screen.getByRole('button', { name: /add source/i }))

    expect(createSourceMutateMock).toHaveBeenCalledWith(
      {
        name: 'Risk warehouse',
        kind: 'POSTGRESQL',
        locator: 'warehouse.internal:5432/risk',
      },
      expect.anything(),
    )
  })
})

