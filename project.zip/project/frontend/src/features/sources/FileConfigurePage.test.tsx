import { beforeEach, describe, expect, it, vi } from 'vitest'
import { screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import type { ClassificationRule, UploadedFile } from '@/types'
import { renderRoute } from '@/test/utils'
import { FileConfigurePage } from './FileConfigurePage'

const { navigateMock, startScanMutateMock, deleteFileMutateMock } = vi.hoisted(() => ({
  navigateMock: vi.fn(),
  startScanMutateMock: vi.fn(),
  deleteFileMutateMock: vi.fn(),
}))

const file: UploadedFile = {
  id: 'file-ownergroup',
  filename: 'ownergroup_mapping.csv',
  fileType: 'CSV',
  sizeBytes: 48210,
  estimatedRows: 640,
  detectedFields: ['ownergroup'],
  explicitMarkers: [],
  activeRuleIds: ['sys-8'],
  uploadStatus: 'PROFILED',
  sourceId: 'src-uploads',
}

const fileScopedCustomRule: ClassificationRule = {
  id: 'custom-file-1',
  name: 'Owner group mapping rule',
  description: 'x',
  source: 'CUSTOM',
  scope: 'THIS_FILE',
  scopeLabel: 'This file',
  scopeFileId: 'file-ownergroup',
  triggerType: 'FIELD_COMBINATION',
  triggerSummary: 'ownergroup + identity',
  targetTier: 'RESTRICTED',
  confidence: 88,
  priority: 'HIGH',
  requireHumanReview: false,
  explanationTemplate: '',
  enabled: true,
  protected: false,
  matchedFiles: 1,
  matchStatus: 'MATCHED',
  updatedAt: '2026-06-01T00:00:00Z',
}

vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual<typeof import('react-router-dom')>('react-router-dom')
  return {
    ...actual,
    useNavigate: () => navigateMock,
  }
})

vi.mock('@/hooks', () => ({
  useUploadedFile: () => ({ data: file, isLoading: false, isError: false, refetch: () => {} }),
  useClassificationRules: () => ({ data: [fileScopedCustomRule] }),
  useStartScan: () => ({ mutate: startScanMutateMock, isPending: false }),
  useDeleteFile: () => ({ mutate: deleteFileMutateMock, isPending: false }),
  useToggleRule: () => ({ mutate: vi.fn() }),
  useDeleteRule: () => ({ mutate: vi.fn() }),
}))

describe('FileConfigurePage remove file', () => {
  beforeEach(() => {
    navigateMock.mockReset()
    startScanMutateMock.mockReset()
    deleteFileMutateMock.mockReset()
  })

  it('calls delete-file mutation from confirmation dialog', async () => {
    const user = userEvent.setup()
    renderRoute(<FileConfigurePage />, {
      path: '/sources/file/:fileId/configure',
      initialEntries: ['/sources/file/file-ownergroup/configure'],
    })

    await user.click(screen.getByRole('button', { name: /remove file/i }))
    const dialog = screen.getByRole('dialog')
    await user.click(within(dialog).getByRole('button', { name: /^remove file$/i }))

    expect(deleteFileMutateMock).toHaveBeenCalledWith('file-ownergroup', expect.anything())
  })

  it('does not render an add new rule button', () => {
    renderRoute(<FileConfigurePage />, {
      path: '/sources/file/:fileId/configure',
      initialEntries: ['/sources/file/file-ownergroup/configure'],
    })

    expect(screen.queryByRole('button', { name: /add new rule/i })).toBeNull()
    expect(screen.queryByLabelText(`Edit ${fileScopedCustomRule.name}`)).toBeNull()
  })

  it('applies the padded configure panel layout classes', () => {
    renderRoute(<FileConfigurePage />, {
      path: '/sources/file/:fileId/configure',
      initialEntries: ['/sources/file/file-ownergroup/configure'],
    })

    expect(document.querySelector('.file-configure-page')).not.toBeNull()
    expect(document.querySelectorAll('.file-configure-panel')).toHaveLength(2)
    expect(screen.getByRole('heading', { name: /active rules for this file/i }).closest('.file-configure-rules-panel')).not.toBeNull()
  })
})



