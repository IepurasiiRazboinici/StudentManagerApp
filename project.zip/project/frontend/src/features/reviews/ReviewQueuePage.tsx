import { useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'
import type { ClassificationTier, ReviewDecisionKind } from '@/types'
import { useCurrentUser, useReviewQueue, useSubmitReview } from '@/hooks'
import { toast } from '@/stores/toastStore'
import {
  Button,
  ConfidenceIndicator,
  EmptyState,
  ErrorState,
  EvidenceBadge,
  PageHeader,
  Panel,
  TierBadge,
} from '@/components/common'
import { ReviewQueueRail } from '@/components/reviews/ReviewQueueRail'
import { REVIEW_CATEGORY_LABEL } from '@/utils/labels'
import { normalizeReviewEvidence } from '@/utils/evidence'
import {
  readResolvedReviewIdsFromSession,
  saveResolvedReviewIdsToSession,
} from '@/utils/reviewQueueSession'

const ACTIONS: Array<{ key: ReviewDecisionKind; label: string; shortcut: string; variant: 'primary' | 'secondary' | 'ghost' | 'danger' }> = [
  { key: 'APPROVE', label: 'Approve', shortcut: 'A', variant: 'primary' },
  { key: 'OVERRIDE', label: 'Request Changes', shortcut: 'O', variant: 'secondary' },
  { key: 'REJECT_USAGE', label: 'Reject', shortcut: 'R', variant: 'ghost' },
]

const KEY_TO_ACTION: Record<string, ReviewDecisionKind> = {
  a: 'APPROVE',
  o: 'OVERRIDE',
  r: 'REJECT_USAGE',
}

const TIERS: ClassificationTier[] = ['PUBLIC', 'CORPORATE', 'RESTRICTED', 'HIGHLY_RESTRICTED']

function shouldIgnoreShortcutTarget(target: EventTarget | null): boolean {
  if (!(target instanceof HTMLElement)) return false
  if (target.isContentEditable) return true
  const tag = target.tagName.toLowerCase()
  return tag === 'input' || tag === 'textarea' || tag === 'select'
}

export function ReviewQueuePage() {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const { data, isLoading, isError, refetch } = useReviewQueue()
  const submit = useSubmitReview()
  const currentUser = useCurrentUser()
  const [chosenId, setChosenId] = useState<string | undefined>(undefined)
  const [resolvedIds, setResolvedIds] = useState<Set<string>>(() => readResolvedReviewIdsFromSession())
  const [highlightedId, setHighlightedId] = useState<string | undefined>(undefined)
  const [notesByReviewId, setNotesByReviewId] = useState<Record<string, string>>({})
  const [overrideTierByReviewId, setOverrideTierByReviewId] = useState<Record<string, ClassificationTier | ''>>({})
  const shortcutActionRef = useRef<(decision: ReviewDecisionKind) => void>(() => {})
  const submitPendingRef = useRef(false)
  const highlightAppliedRef = useRef(false)

  const queueItems = useMemo(() => (data ?? []).filter((item) => !resolvedIds.has(item.id)), [data, resolvedIds])

  // Derive the active item so we never call setState from an effect on load.
  const selectedId = chosenId && queueItems.some((i) => i.id === chosenId) ? chosenId : queueItems[0]?.id
  const selected = queueItems.find((i) => i.id === selectedId)
  const selectedEvidence = useMemo(() => normalizeReviewEvidence(selected?.evidence ?? []), [selected?.evidence])
  const selectedNote = selected ? notesByReviewId[selected.id] ?? '' : ''
  const selectedOverrideTier = selected ? overrideTierByReviewId[selected.id] ?? '' : ''

  const overrideOptions = useMemo(
    () => TIERS.filter((tier) => tier !== selected?.currentClassification),
    [selected?.currentClassification],
  )

  const selectNextUnresolved = (currentReviewId: string, resolvedSet: Set<string>) => {
    if (!data || data.length === 0) return
    const next = data.find((item) => item.id !== currentReviewId && !resolvedSet.has(item.id))
    if (next) {
      setChosenId(next.id)
      return
    }
    const fallback = data.find((item) => item.id !== currentReviewId)
    if (fallback) setChosenId(fallback.id)
  }

  const act = (decision: ReviewDecisionKind) => {
    if (!selected) return
    const note = selectedNote.trim()
    const overrideTier = selectedOverrideTier || undefined
    if (decision === 'OVERRIDE') {
      if (!overrideTier || overrideTier === selected.currentClassification) {
        toast.error('Select a different target tier before requesting changes.')
        return
      }
    }

    submit.mutate(
      {
        classificationId: selected.classificationId,
        req: {
          decision,
          note: note || undefined,
          overrideTier,
          reviewItemId: selected.id,
          datasetId: selected.datasetId,
          fileId: selected.datasetId,
          reviewerId: currentUser.id,
          reviewerName: currentUser.displayName,
        },
      },
      {
        onSuccess: () => {
          setResolvedIds((prev) => {
            const next = new Set(prev)
            next.add(selected.id)
            saveResolvedReviewIdsToSession(next)
            selectNextUnresolved(selected.id, next)
            return next
          })
          setNotesByReviewId((prev) => ({ ...prev, [selected.id]: '' }))
          setOverrideTierByReviewId((prev) => ({ ...prev, [selected.id]: '' }))
          toast.success(`${selected.datasetName}: decision recorded.`)
        },
        onError: () => toast.error('Could not submit the decision.'),
      },
    )
  }

  shortcutActionRef.current = act
  submitPendingRef.current = submit.isPending

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if (event.defaultPrevented) return
      if (submitPendingRef.current) return
      if (shouldIgnoreShortcutTarget(event.target)) return

      const action = KEY_TO_ACTION[event.key.toLowerCase()]
      if (!action) return

      event.preventDefault()
      shortcutActionRef.current(action)
    }

    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [])

  useEffect(() => {
    const highlightId = searchParams.get('highlight')
    if (!highlightId || !data || highlightAppliedRef.current) return
    const match = data.find((item) => item.id === highlightId)
    if (!match) return

    highlightAppliedRef.current = true
    setChosenId(match.id)
    setHighlightedId(match.id)
    requestAnimationFrame(() => {
      const selector = match.id.replace(/"/g, '\\"')
      const element = document.querySelector<HTMLElement>(`[data-review-id="${selector}"]`)
      element?.scrollIntoView({ behavior: 'smooth', block: 'center' })
      element?.focus()
    })
    const timer = window.setTimeout(() => setHighlightedId(undefined), 2600)
    return () => window.clearTimeout(timer)
  }, [data, searchParams])

  if (isLoading) {
    return (
      <div className="page-stack">
        <PageHeader title="Review Queue" />
        <Panel>Loading review queue…</Panel>
      </div>
    )
  }
  if (isError) {
    return (
      <div className="page-stack">
        <PageHeader title="Review Queue" />
        <ErrorState description="The review queue could not be loaded." onRetry={() => void refetch()} />
      </div>
    )
  }

  if (!data || data.length === 0) {
    return (
      <div className="page-stack">
        <PageHeader title="Review Queue" description="Uncertain and high-risk decisions that need a human." />
        <EmptyState title="Nothing to review" description="All classifications are confirmed. New items will appear here after scans and rule changes." />
      </div>
    )
  }

  if (queueItems.length === 0) {
    return (
      <div className="page-stack">
        <PageHeader title="Review Queue" description="Uncertain and high-risk decisions that need a human data steward." />
        <EmptyState
          title="All queued reviews resolved for this session"
          description="New reviews will appear automatically. You can also clear session state to show resolved entries again."
          action={
            <Button
              variant="secondary"
              onClick={() => {
                setResolvedIds(new Set())
                saveResolvedReviewIdsToSession(new Set())
              }}
            >
              Show resolved entries
            </Button>
          }
        />
      </div>
    )
  }

  return (
    <div className="page-stack review-page">
      <PageHeader title="Review Queue" description="Uncertain and high-risk decisions that need a human data steward." />

      <div className="review-layout">
        <ReviewQueueRail
          items={queueItems}
          selectedId={selectedId}
          resolvedIds={resolvedIds}
          highlightedId={highlightedId}
          onSelect={setChosenId}
        />

        <div className="review-main">
          {selected ? (
            <Panel>
              <div className="review-head">
                <div>
                  <span className="eyebrow">{REVIEW_CATEGORY_LABEL[selected.category]}</span>
                  <h2 className="mono">{selected.datasetName}</h2>
                </div>
                <div className="review-head-badges">
                  <TierBadge tier={selected.currentClassification} />
                  {selected.proposedClassification ? (
                    <>
                      <ArrowRight size={16} aria-hidden />
                      <TierBadge tier={selected.proposedClassification} />
                    </>
                  ) : null}
                  <ConfidenceIndicator value={selected.confidence} size="sm" />
                </div>
              </div>

              <p className="review-reason">{selected.reason}</p>
              {selected.intendedUse ? (
                <p className="muted">Intended use: {selected.intendedUse}</p>
              ) : null}

              <div className="drawer-section">
                <span className="eyebrow">Evidence</span>
                <ul className="review-evidence">
                  {selectedEvidence.map((e) => (
                    <li key={e.id}>
                      <EvidenceBadge kind={e.kind} />
                      <div>
                        <strong>{e.label}</strong>
                        <p>{e.explanation}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="drawer-section">
                <span className="eyebrow">System recommendation</span>
                <p>
                  <strong>AI recommendation:</strong> {selected.recommendedAction}
                </p>
                <p className="muted">Confidence: {selected.confidence}%</p>
                <p className="muted">Rationale: {selected.reason}</p>
              </div>

              <div className="drawer-section">
                <span className="eyebrow">Reviewer decision</span>
                <p className="muted">Reviewer: {currentUser.displayName}</p>
                <label className="cf-field">
                  <span className="cf-label">Request changes target tier</span>
                  <select
                    className="cf-input"
                    value={selectedOverrideTier}
                    onChange={(e) =>
                      setOverrideTierByReviewId((prev) => ({
                        ...prev,
                        [selected.id]: e.target.value as ClassificationTier | '',
                      }))
                    }
                    aria-label="Request changes target tier"
                  >
                    <option value="">Choose tier for request changes…</option>
                    {overrideOptions.map((tier) => (
                      <option key={tier} value={tier}>
                        {tier}
                      </option>
                    ))}
                  </select>
                </label>

                <label className="cf-field">
                  <span className="cf-label">Reviewer note</span>
                <textarea
                  className="cf-input"
                  value={selectedNote}
                  onChange={(e) =>
                    setNotesByReviewId((prev) => ({
                      ...prev,
                      [selected.id]: e.target.value,
                    }))
                  }
                  placeholder="Add review context for the selected decision..."
                  aria-label="Reviewer note"
                />
                </label>
              </div>

              <div className="review-actions">
                {ACTIONS.map((a) => (
                  <Button key={a.key} variant={a.variant} onClick={() => act(a.key)} disabled={submit.isPending}>
                    {a.label} <kbd>{a.shortcut}</kbd>
                  </Button>
                ))}
                <Button variant="secondary" onClick={() => navigate(`/data-passport/${selected.datasetId}`)}>
                  View Data Passport
                </Button>
              </div>

              <p className="shortcut-hint muted">Shortcuts: A approve · O request changes · R reject</p>
            </Panel>
          ) : null}
        </div>
      </div>
    </div>
  )
}
