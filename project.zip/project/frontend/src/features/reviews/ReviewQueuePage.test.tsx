import { describe, expect, it, vi, beforeEach } from 'vitest'
import { screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import type { ReviewItem } from '@/types'
import { renderWithProviders } from '@/test/utils'
import { ReviewQueuePage } from './ReviewQueuePage'

const { submitMock, queueItemsMock } = vi.hoisted(() => ({
  submitMock: vi.fn(),
  queueItemsMock: [] as ReviewItem[],
}))

const item: ReviewItem = {
  id: 'rev-1',
  classificationId: 'cls-ownergroup',
  datasetId: 'ownergroup_mapping',
  datasetName: 'ownergroup_mapping.csv',
  category: 'LOW_CONFIDENCE',
  confidence: 72,
  currentClassification: 'RESTRICTED',
  reason: 'Undocumented provenance.',
  evidence: [{ id: 'e1', kind: 'CONTEXT', label: 'Provenance', explanation: 'Undocumented.', weight: 0.5 }],
  recommendedAction: 'Confirm or override.',
  policyReferences: [],
}

const backendConflictEvidence = `Rule=Restricted, LLM=Public. LLM evidence: {'signal': 'sample_dataset_label', 'detail': "Header explicitly states 'Sample / Hackathon Dataset', indicating intentional public/educational use with no proprietary or sensitive content.", 'severity': 'LOW'}; {'signal': 'market_data_field_definitions', 'detail': 'Content contains generic FID definitions (TRDPRC_1, HIGH_1) with no actual trade data, account info, or PII — purely structural metadata.', 'severity': 'LOW'}`

const itemWithVerboseEvidence: ReviewItem = {
  ...item,
  id: 'rev-2',
  classificationId: 'cls-sample-dataset',
  datasetId: 'sample-dataset',
  datasetName: 'sample_dataset.csv',
  evidence: [
    { id: 'e-conflict', kind: 'DETECTOR', label: 'rule llm conflict', explanation: backendConflictEvidence, weight: 0.5 },
    {
      id: 'e-detail-1',
      kind: 'DETECTOR',
      label: 'sample dataset label',
      explanation: "Header explicitly states 'Sample / Hackathon Dataset', indicating intentional public/educational use with no proprietary or sensitive content.",
      weight: 0.4,
    },
    {
      id: 'e-detail-2',
      kind: 'DETECTOR',
      label: 'market data field definitions',
      explanation: 'Content contains generic FID definitions (TRDPRC_1, HIGH_1) with no actual trade data, account info, or PII — purely structural metadata.',
      weight: 0.4,
    },
  ],
}

vi.mock('@/hooks', () => ({
  useReviewQueue: () => ({ data: queueItemsMock, isLoading: false, isError: false, refetch: () => {} }),
  useSubmitReview: () => ({ mutate: submitMock, isPending: false }),
  useCurrentUser: () => ({ id: 'reviewer-you', displayName: 'You' }),
}))

describe('ReviewQueuePage actions', () => {
  beforeEach(() => {
    submitMock.mockReset()
    queueItemsMock.splice(0, queueItemsMock.length, item)
  })

  it('does not show Confirm, Escalate, or Add Rule actions', () => {
    renderWithProviders(<ReviewQueuePage />)
    expect(screen.queryByRole('button', { name: /confirm/i })).not.toBeInTheDocument()
    expect(screen.queryByRole('button', { name: /escalate/i })).not.toBeInTheDocument()
    expect(screen.queryByRole('button', { name: /add rule/i })).not.toBeInTheDocument()
  })

  it('shows the selected review item', () => {
    renderWithProviders(<ReviewQueuePage />)
    expect(screen.getAllByText('ownergroup_mapping.csv').length).toBeGreaterThanOrEqual(1)
    expect(screen.getByText('Undocumented provenance.')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: /view data passport/i })).toBeInTheDocument()
  })

  it('submits an Approve decision through the backend mutation', async () => {
    renderWithProviders(<ReviewQueuePage />)
    await userEvent.click(screen.getByRole('button', { name: /approve/i }))
    expect(submitMock).toHaveBeenCalledWith(
      expect.objectContaining({
        classificationId: 'cls-ownergroup',
        req: expect.objectContaining({ decision: 'APPROVE', reviewItemId: 'rev-1' }),
      }),
      expect.anything(),
    )
  })

  it('submits a Request Changes decision through the backend mutation', async () => {
    renderWithProviders(<ReviewQueuePage />)
    await userEvent.selectOptions(screen.getByLabelText('Request changes target tier'), 'PUBLIC')
    await userEvent.click(screen.getByRole('button', { name: /request changes/i }))
    expect(submitMock).toHaveBeenCalledWith(
      expect.objectContaining({
        classificationId: 'cls-ownergroup',
        req: expect.objectContaining({ decision: 'OVERRIDE', overrideTier: 'PUBLIC' }),
      }),
      expect.anything(),
    )
  })

  it('shows only readable detail evidence for backend conflict items', () => {
    queueItemsMock.splice(0, queueItemsMock.length, itemWithVerboseEvidence)

    renderWithProviders(<ReviewQueuePage />)

    expect(screen.queryByText(/Rule=Restricted, LLM=Public/i)).not.toBeInTheDocument()
    expect(
      screen.getByText(/Header explicitly states 'Sample \/ Hackathon Dataset', indicating intentional public\/educational use/i),
    ).toBeInTheDocument()
    expect(screen.getByText(/Content contains generic FID definitions/i)).toBeInTheDocument()
    expect(screen.queryByText('rule llm conflict')).not.toBeInTheDocument()
  })
})
