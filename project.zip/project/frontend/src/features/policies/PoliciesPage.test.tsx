import { describe, expect, it, vi } from 'vitest'
import { screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import type { PolicyDocument } from '@/types'
import { renderWithProviders } from '@/test/utils'
import { PoliciesPage } from './PoliciesPage'

const openPolicy = vi.fn()

const policies: PolicyDocument[] = [
  {
    id: 'pol-ai-01',
    name: 'LSEG Responsible AI Principles',
    version: '2026.3',
    status: 'ACTIVE',
    classificationsUsing: 5,
    ingestedAt: '2026-07-01T09:00:00Z',
    coverage: 90,
    sections: [
      {
        id: 'AI-01-1.1',
        reference: 'AI-01 §1.1',
        title: 'Human oversight and accountability',
        body: 'AI decisions must be reviewable.',
        datasetsUsing: ['ownergroup_mapping'],
      },
    ],
  },
  {
    id: 'pol-draft-01',
    name: 'Draft policy should not appear',
    version: 'draft',
    status: 'DRAFT',
    classificationsUsing: 0,
    ingestedAt: '2026-07-02T09:00:00Z',
    coverage: 20,
    sections: [
      {
        id: 'draft-1',
        reference: 'DRAFT §1',
        title: 'Draft content',
        body: 'Hidden from adopted list.',
        datasetsUsing: [],
      },
    ],
  },
]

vi.mock('@/hooks', () => ({
  usePolicies: () => ({ data: policies, isLoading: false, isError: false, refetch: () => {} }),
}))

vi.mock('@/stores/uiStore', () => ({
  useUiStore: (selector: (state: { openPolicy: typeof openPolicy }) => unknown) => selector({ openPolicy }),
}))

describe('PoliciesPage', () => {
  it('shows adopted active policies only and hides upload actions', () => {
    renderWithProviders(<PoliciesPage />)
    expect(screen.getByText('LSEG Responsible AI Principles')).toBeInTheDocument()
    expect(screen.queryByText('Draft policy should not appear')).toBeNull()
    expect(screen.queryByRole('button', { name: /upload policy/i })).toBeNull()
  })

  it('opens the policy drawer from a row click', async () => {
    renderWithProviders(<PoliciesPage />)
    await userEvent.click(screen.getByRole('button', { name: /open lseg responsible ai principles/i }))
    expect(openPolicy).toHaveBeenCalledWith('pol-ai-01')
  })
})

