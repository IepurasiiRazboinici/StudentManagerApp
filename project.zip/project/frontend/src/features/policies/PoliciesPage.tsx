import { useMemo } from 'react'
import { BookOpenText } from 'lucide-react'
import { usePolicies } from '@/hooks'
import { useUiStore } from '@/stores/uiStore'
import { EmptyState, ErrorState, PageHeader, Panel, StatusBadge, TableSkeleton } from '@/components/common'
import { formatDate } from '@/utils/format'
import { POLICY_STATUS_LABEL, POLICY_STATUS_TONE } from '@/utils/labels'

function coverageTone(coverage: number): 'green' | 'amber' | 'red' {
  if (coverage >= 85) return 'green'
  if (coverage >= 60) return 'amber'
  return 'red'
}

export function PoliciesPage() {
  const { data, isLoading, isError, refetch } = usePolicies()
  const openPolicy = useUiStore((s) => s.openPolicy)

  const adoptedPolicies = useMemo(() => (data ?? []).filter((policy) => policy.status === 'ACTIVE'), [data])

  return (
    <div className="page-stack">
      <PageHeader
        title="Adopted Policies"
        description="Read-only governance policies currently adopted in this prototype. Open a policy to inspect the sections cited by classifications, intended-use checks, and reviews."
      />

      <Panel style={{ padding: 16 }}>
        <div className="panel-head" style={{ gap: 16, paddingBottom: 8 }}>
          <div>
            <h2>Adopted policy library</h2>
            <p className="muted">Only active, adopted policies are listed here. New policy uploads are intentionally disabled in this prototype.</p>
          </div>
          <StatusBadge tone="blue" icon={<BookOpenText size={14} aria-hidden />}>
            {adoptedPolicies.length} adopted
          </StatusBadge>
        </div>

        {isLoading ? (
          <TableSkeleton rows={4} cols={6} />
        ) : isError ? (
          <ErrorState description="Policies could not be loaded." onRetry={() => void refetch()} />
        ) : adoptedPolicies.length === 0 ? (
          <EmptyState title="No adopted policies" description="There are no active policies configured for this prototype." />
        ) : (
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Policy</th>
                  <th>Version</th>
                  <th>Status</th>
                  <th>Coverage</th>
                  <th className="num">Classifications</th>
                  <th>Adopted</th>
                </tr>
              </thead>
              <tbody>
                {adoptedPolicies.map((policy) => (
                  <tr
                    key={policy.id}
                    className="clickable-row"
                    tabIndex={0}
                    role="button"
                    aria-label={`Open ${policy.name}`}
                    onClick={() => openPolicy(policy.id)}
                    onKeyDown={(event) => {
                      if (event.key === 'Enter' || event.key === ' ') {
                        event.preventDefault()
                        openPolicy(policy.id)
                      }
                    }}
                  >
                    <td>
                      <div style={{ display: 'grid', gap: 8 }}>
                        <strong>{policy.name}</strong>
                        <span className="muted">{policy.sections.length} key principle{policy.sections.length === 1 ? '' : 's'}</span>
                      </div>
                    </td>
                    <td className="mono">{policy.version}</td>
                    <td>
                      <StatusBadge tone={POLICY_STATUS_TONE[policy.status]}>{POLICY_STATUS_LABEL[policy.status]}</StatusBadge>
                    </td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span className={`badge badge-${coverageTone(policy.coverage)}`}>{policy.coverage}%</span>
                        <span className="muted">coverage</span>
                      </div>
                    </td>
                    <td className="num">{policy.classificationsUsing}</td>
                    <td className="muted">{formatDate(policy.ingestedAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
    </div>
  )
}

