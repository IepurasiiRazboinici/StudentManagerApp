export interface CurrentUser {
  id: string
  displayName: string
}

// Demo identity for reviewer attribution; backend-backed identity can replace this later.
export function useCurrentUser(): CurrentUser {
  return {
	id: 'reviewer-you',
	displayName: 'You',
  }
}

