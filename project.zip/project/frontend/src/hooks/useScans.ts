import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { scansApi } from '@/api'
import type { StartScanInput } from '@/api/scansApi'
import { qk } from './queryKeys'

export function useScanStatus(scanId: string | undefined, opts?: { polling?: boolean; intervalMs?: number }) {
  return useQuery({
    queryKey: scanId ? qk.scan(scanId) : ['scan', 'none'],
    queryFn: () => scansApi.getScan(scanId as string),
    enabled: Boolean(scanId),
    refetchInterval: (query) => {
      if (!opts?.polling) return false
      const state = query.state.data?.state
      return state === 'RUNNING' ? (opts.intervalMs ?? 200) : false
    },
  })
}

export function useStartScan() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (input: StartScanInput) => scansApi.startScan(input),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: qk.reviews })
      void qc.invalidateQueries({ queryKey: qk.datasets })
      void qc.invalidateQueries({ queryKey: qk.sourceFiles })
      void qc.invalidateQueries({ queryKey: qk.audit })
      void qc.invalidateQueries({ queryKey: qk.dashboard })
    },
  })
}

/** Starts a single batch scan job covering every connected data source. */
export function useStartBatchScan() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: () => scansApi.startBatchScan(),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: qk.audit })
      void qc.invalidateQueries({ queryKey: qk.dashboard })
    },
  })
}

export function useCancelScan() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (scanId: string) => scansApi.cancelScan(scanId),
    onSuccess: (_res, scanId) => {
      void qc.invalidateQueries({ queryKey: qk.scan(scanId) })
      void qc.invalidateQueries({ queryKey: qk.sources })
      void qc.invalidateQueries({ queryKey: qk.audit })
    },
  })
}

