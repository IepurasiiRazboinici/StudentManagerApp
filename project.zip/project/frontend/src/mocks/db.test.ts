import { beforeEach, describe, expect, it } from 'vitest'
import { mockDb } from './db'

describe('mockDb.previewRemediation', () => {
  beforeEach(() => {
    mockDb.reset()
  })

  it('returns richer and different safe preview rows for different transformation selections', () => {
    const noneSelected = mockDb.previewRemediation('plan-mixed', [])
    const recommendedSelected = mockDb.previewRemediation('plan-mixed', [
      'tr-remove-client',
      'tr-remove-account',
      'tr-remove-position',
    ])
    const mixedSelection = mockDb.previewRemediation('plan-mixed', [
      'tr-remove-client',
      'tr-bucket-position',
      'tr-aggregate',
    ])

    expect(noneSelected.maskedPreview.length).toBeGreaterThanOrEqual(3)
    expect(recommendedSelected.maskedPreview.length).toBeGreaterThan(noneSelected.maskedPreview.length)
    expect(mixedSelection.maskedPreview.length).toBe(recommendedSelected.maskedPreview.length)

    const baseFirstRow = noneSelected.maskedPreview[0]
    const recommendedFirstRow = recommendedSelected.maskedPreview[0]
    const mixedFirstRow = mixedSelection.maskedPreview[0]

    expect(baseFirstRow.cells.some((cell) => cell.changed)).toBe(false)
    expect(recommendedFirstRow.cells.some((cell) => cell.changed)).toBe(true)
    expect(mixedFirstRow.cells.some((cell) => cell.changed)).toBe(true)

    const baseSymbol = baseFirstRow.cells.find((cell) => cell.field === 'symbol')
    const mixedSymbol = mixedFirstRow.cells.find((cell) => cell.field === 'symbol')
    const recommendedClient = recommendedFirstRow.cells.find((cell) => cell.field === 'client_id')
    const mixedPosition = mixedFirstRow.cells.find((cell) => cell.field === 'position_size')

    expect(baseSymbol?.transformed).toBe('VOD.L')
    expect(mixedSymbol?.transformed).toBe('FTSE basket')
    expect(recommendedClient?.transformed).toBe('—')
    expect(mixedPosition?.transformed).toBe('avg 9.4k')

    expect(recommendedSelected.maskedPreview[0].cells).not.toEqual(mixedSelection.maskedPreview[0].cells)
  })
})

describe('mockDb.submitReview', () => {
  beforeEach(() => {
    mockDb.reset()
  })

  it('updates dataset status when requesting changes from the review queue', () => {
    const reviewItem = mockDb.listReviews()[0]

    mockDb.submitReview(reviewItem.id, {
      decision: 'OVERRIDE',
      overrideTier: 'PUBLIC',
      datasetId: reviewItem.datasetId,
      reviewerName: 'You',
      note: 'Please rework this classification for public release.',
    })

    const updated = mockDb.getDataset(reviewItem.datasetId)
    expect(updated.reviewStatus).toBe('OVERRIDDEN')
    expect(updated.classification).toBe('PUBLIC')
    expect(updated.reviewHistory[0]?.action).toBe('OVERRIDE')
  })
})

describe('mockDb.ingestBackendClassification', () => {
  beforeEach(() => {
    mockDb.reset()
  })

  it('adds files to the review queue when AI and deterministic classifications conflict', () => {
    const file = mockDb.uploadFile({
      filename: 'conflict-sample.csv',
      fileType: 'CSV',
      sizeBytes: 2048,
    })

    mockDb.ingestBackendClassification(file.id, {
      results: [
        {
          review_key: 'review-conflict-1',
          asset_path: file.filename,
          classification: 'Restricted',
          confidence: 0.82,
          evidence: [
            {
              signal: 'detector_match',
              detail: 'Found identifiers in multiple columns.',
              source: 'rules-engine',
            },
          ],
          guidance_references: ['Policy 4.2'],
          explanation: 'Deterministic rules classified this file as Restricted.',
          human_review: { required: false },
          classification_source: 'conflict',
        },
      ],
    })

    const dataset = mockDb.getDataset(`dataset-${file.id}`)
    const reviewItem = mockDb.listReviews().find((item) => item.datasetId === dataset.id)

    expect(dataset.reviewStatus).toBe('REVIEW_REQUIRED')
    expect(dataset.attentionReason).toContain('AI classification disagreed')
    expect(reviewItem).toBeDefined()
    expect(reviewItem?.category).toBe('MARKER_CONFLICT')
  })
})


