/**
 * In-memory mock database.
 *
 * Holds mutable copies of the seed fixtures and implements the *stateful* demo
 * behaviour (create custom rule -> request reclassification -> updated dataset +
 * audit entries). This is deliberately kept out of the UI and the typed API
 * modules: it is the only place the mock "backend" keeps state.
 *
 * Nothing here infers a classification from data. Reclassification simply applies
 * the *declared* target tier of a saved rule — exactly the predefined behaviour
 * the brief permits for the mock backend.
 */

import type {
  AuditEvent,
  ClassificationRule,
  CreateRuleRequest,
  DataPassport,
  DataSource,
  DatasetDetails,
  DatasetSummary,
  EvidenceSignal,
  MatchedRule,
  MaskedPreviewRow,
  RemediationMetrics,
  RemediationPlan,
  RemediationPreview,
  ReviewDecision,
  ReviewItem,
  RulePreviewRequest,
  RulePreviewResult,
  RulePriority,
  RuleTrigger,
  SubmitReviewRequest,
  TransformationKind,
  UpdateRuleRequest,
  UploadedFile,
} from '@/types'
import {
  auditEvents as seedAudit,
  buildDashboard,
  dataPassports as seedPassports,
  dataSources as seedSources,
  datasetDetailSeeds,
  policyDocuments,
  remediationPlans as seedPlans,
  reviewDecisions as seedDecisions,
  reviewItems as seedReviews,
  scanStageTemplate,
  seedCustomRules,
  systemRules,
  uploadedFiles as seedFiles,
} from './data'
import { clampIsoDateStringToBounds } from '@/utils/dateBounds'
import { formatEvidenceExplanation, normalizeReviewEvidence } from '@/utils/evidence'

const clone = <T>(value: T): T => structuredClone(value)

const DATE_KEYS = new Set([
  'timestamp',
  'updatedAt',
  'lastAnalysed',
  'ingestedAt',
  'approvedAt',
  'lastScan',
  'createdAt',
])

function clampSeedDates<T>(value: T): T {
  if (Array.isArray(value)) {
    return value.map((item) => clampSeedDates(item)) as T
  }

  if (value && typeof value === 'object') {
    const copy: Record<string, unknown> = { ...(value as Record<string, unknown>) }
    for (const [key, current] of Object.entries(copy)) {
      if (typeof current === 'string' && DATE_KEYS.has(key)) {
        copy[key] = clampIsoDateStringToBounds(current)
      } else {
        copy[key] = clampSeedDates(current)
      }
    }
    return copy as T
  }

  return value
}

const TIER_ORDER: Record<DatasetSummary['classification'], number> = {
  PUBLIC: 0,
  CORPORATE: 1,
  RESTRICTED: 2,
  UNKNOWN: 2,
  HIGHLY_RESTRICTED: 3,
}

const PRIORITY_ORDER = { NORMAL: 0, HIGH: 1, CRITICAL: 2 } as const

interface MockState {
  details: DatasetDetails[]
  rules: ClassificationRule[]
  sources: DataSource[]
  files: UploadedFile[]
  scans: Record<string, import('@/types').ScanStatus>
  reviews: ReviewItem[]
  decisions: ReviewDecision[]
  audit: AuditEvent[]
  plans: RemediationPlan[]
  policies: import('@/types').PolicyDocument[]
  passports: Record<string, DataPassport>
}

interface BackendEvidenceItem {
  signal: string
  detail: string
  source: string
}

interface BackendHumanReview {
  required: boolean
  reason?: string | null
}

interface BackendSourceClassification {
  classification: string
  confidence: number
  explanation: string
  confidence_reasoning?: string | null
  evidence: BackendEvidenceItem[]
}

interface BackendRemediationSuggestion {
  field_name: string
  transformation: string
  reason: string
  impact?: string | null
}

interface BackendCustomRuleMatch {
  rule_id: string
  rule_name: string
  target_classification: string
  confidence: number
  priority: string
  require_human_review: boolean
  matched_fields: string[]
  explanation: string
}

interface BackendAssetClassification {
  review_key?: string | null
  asset_path: string
  classification: string
  confidence: number
  evidence: BackendEvidenceItem[]
  guidance_references: string[]
  explanation: string
  human_review: BackendHumanReview
  field_overrides?: Array<Record<string, unknown>>
  remediation_suggestions?: BackendRemediationSuggestion[]
  rule_classification?: BackendSourceClassification | null
  ai_classification?: BackendSourceClassification | null
  ai_attempted?: boolean
  ai_used?: boolean
  classification_source?: 'rules' | 'agreement' | 'conflict'
  ai_raw_output?: string | null
  ai_error?: string | null
  custom_rule_matches?: BackendCustomRuleMatch[]
}

interface BackendClassifyResponse {
  results: BackendAssetClassification[]
}

function seed(): MockState {
  return {
    details: clampSeedDates(clone(datasetDetailSeeds)),
    rules: clampSeedDates([...clone(systemRules), ...clone(seedCustomRules)]),
    sources: clampSeedDates(clone(seedSources)),
    files: clone(seedFiles),
    scans: {},
    reviews: clampSeedDates(clone(seedReviews)),
    decisions: clampSeedDates(clone(seedDecisions)),
    audit: clampSeedDates(clone(seedAudit)),
    plans: clone(seedPlans),
    policies: clampSeedDates(clone(policyDocuments)),
    passports: clampSeedDates(clone(seedPassports)),
  }
}

let state: MockState = seed()

let idSeq = 1000
function nextId(prefix: string): string {
  idSeq += 1
  return `${prefix}-${idSeq}`
}

function now(): string {
  return new Date().toISOString()
}

function stageIndexFromProgress(progress: number, stages: import('@/types').ScanStatus['stages']): number {
  if (stages.length === 0) return 0
  const idx = Math.floor((Math.max(0, Math.min(progress, 100)) / 100) * stages.length)
  return Math.min(stages.length - 1, idx)
}

function nextProgress(current: number): number {
  if (current >= 100) return 100
  if (current >= 85) return 100
  // Random increment between 8-20% for faster progression
  const randomIncrement = Math.floor(Math.random() * 13) + 8
  return Math.min(100, current + randomIncrement)
}

function backendTierToFrontendTier(label: string): DatasetSummary['classification'] {
  const normalized = label.trim().toLowerCase()
  if (normalized === 'public') return 'PUBLIC'
  if (normalized === 'corporate' || normalized === 'internal') return 'CORPORATE'
  if (normalized === 'restricted' || normalized === 'confidential') return 'RESTRICTED'
  if (normalized === 'highly restricted' || normalized === 'highly confidential') return 'HIGHLY_RESTRICTED'
  return 'UNKNOWN'
}

function toClassificationOpinion(
  source: BackendSourceClassification,
  confidencePctOverride?: number,
): import('@/types').ClassificationOpinion {
  const confidencePct = confidencePctOverride ?? Math.max(0, Math.min(100, Math.round(source.confidence * 100)))
  const evidence = normalizeReviewEvidence(
    source.evidence.map((ev) => ({
      id: nextId('ev'),
      kind: signalToEvidenceKind(ev.signal),
      label: ev.signal.replace(/_/g, ' '),
      explanation: formatEvidenceExplanation(ev.detail),
      weight: 0.3,
      reference: ev.source,
      confidence: confidencePct,
    })),
  )

  return {
    classification: backendTierToFrontendTier(source.classification),
    confidence: confidencePct,
    explanation: source.explanation,
    confidenceReasoning: source.confidence_reasoning ?? undefined,
    evidence,
  }
}

function buildAiClassificationBreakdown(
  result: BackendAssetClassification,
): import('@/types').AiClassificationBreakdown | undefined {
  if (!result.rule_classification) return undefined
  return {
    attempted: Boolean(result.ai_attempted),
    used: Boolean(result.ai_used),
    source: result.classification_source ?? 'rules',
    rule: toClassificationOpinion(result.rule_classification),
    ai: result.ai_classification ? toClassificationOpinion(result.ai_classification) : undefined,
    rawOutput: result.ai_raw_output ?? undefined,
    error: result.ai_error ?? undefined,
  }
}

function defaultUsageForTier(tier: DatasetSummary['classification']): DatasetSummary['usageStatus'] {
  if (tier === 'HIGHLY_RESTRICTED') return 'BLOCKED'
  if (tier === 'RESTRICTED') return 'REVIEW_REQUIRED'
  if (tier === 'CORPORATE') return 'CONDITIONALLY_ALLOWED'
  return 'ALLOWED'
}

function signalToEvidenceKind(signal: string): EvidenceSignal['kind'] {
  const normalized = signal.toLowerCase()
  if (normalized.includes('policy')) return 'POLICY'
  if (normalized.includes('marker')) return 'EXPLICIT_MARKER'
  if (normalized.includes('human')) return 'HUMAN'
  return 'DETECTOR'
}

function toSummary(detail: DatasetDetails): DatasetSummary {
  return {
    id: detail.id,
    name: detail.name,
    sourceKind: detail.sourceKind,
    sourceName: detail.sourceName,
    sourceLocation: detail.sourceLocation,
    rowCount: detail.rowCount,
    fieldCount: detail.fieldCount,
    classification: detail.classification,
    confidence: detail.confidence,
    reviewStatus: detail.reviewStatus,
    usageStatus: detail.usageStatus,
    matchedRuleCount: detail.matchedRuleCount,
    hasCustomRule: detail.hasCustomRule,
    canBeMadeSafe: detail.canBeMadeSafe,
    lastAnalysed: detail.lastAnalysed,
    attentionReason: detail.attentionReason,
  }
}

function pushAudit(event: Omit<AuditEvent, 'id' | 'timestamp'>): void {
  state.audit = [{ id: nextId('aud'), timestamp: now(), ...event }, ...state.audit]
}

/** Whether a rule's trigger matches a dataset, and which fields matched. */
function ruleMatchesDataset(
  trigger: RuleTrigger | undefined,
  detail: DatasetDetails,
): { matches: boolean; matchedFields: string[] } {
  const fieldNames = detail.fields.map((f) => f.name)
  if (!trigger) return { matches: false, matchedFields: [] }

  switch (trigger.type) {
    case 'FIELD_COMBINATION': {
      const matchedFields = trigger.fields.filter((f) => fieldNames.includes(f))
      return { matches: trigger.fields.length > 0 && matchedFields.length === trigger.fields.length, matchedFields }
    }
    case 'FIELD_NAME': {
      const matchedFields = fieldNames.filter((name) => trigger.aliases.includes(name))
      return { matches: matchedFields.length > 0, matchedFields }
    }
    case 'FILE_NAME': {
      const name = detail.name.toLowerCase()
      const value = trigger.value.toLowerCase()
      const matches =
        trigger.operator === 'contains'
          ? name.includes(value)
          : trigger.operator === 'starts_with'
            ? name.startsWith(value)
            : trigger.operator === 'ends_with'
              ? name.endsWith(value)
              : trigger.operator === 'equals'
                ? name === value
                : value.length > 0 && name.includes(value)
      return { matches, matchedFields: [] }
    }
    case 'EXPLICIT_MARKER': {
      const matches = detail.explicitMarkers.some((m) =>
        m.marker.toLowerCase().includes(trigger.markerText.toLowerCase()),
      )
      return { matches, matchedFields: [] }
    }
    default:
      // CONTENT_PATTERN / DOCUMENT_TYPE / METADATA_STATUS — the mock cannot inspect
      // raw content, so it reports "no local match" and defers to the backend.
      return { matches: false, matchedFields: [] }
  }
}

function previewSeriesForField(field: DatasetDetails['fields'][number]): string[] {
  const name = field.name.toLowerCase()
  const type = field.dataType.toLowerCase()
  const codePrefix = field.name.replace(/[^a-z0-9]/gi, '').slice(0, 5).toUpperCase() || 'VAL'

  if (/symbol|instrument/.test(name)) {
    return ['VOD.L', 'BARC.L', 'LSEG.L', 'BP.L', 'RIO.L', 'NWG.L', 'HSBA.L']
  }

  if (/client|account|counterparty|ownergroup|alias|code|ref|identifier|\bid\b/.test(name)) {
    return Array.from({ length: 7 }, (_, index) => `${codePrefix}-${String(207 + index * 17).padStart(3, '0')}`)
  }

  if (type === 'date' || name.includes('date')) {
    return ['2026-07-14', '2026-07-15', '2026-07-16', '2026-07-17', '2026-07-18', '2026-07-21', '2026-07-22']
  }

  if (type === 'timestamp' || /time|stamp|_ts$|^ts_/.test(name)) {
    return [
      '2026-07-22T08:10:00Z',
      '2026-07-22T08:25:00Z',
      '2026-07-22T08:40:00Z',
      '2026-07-22T08:55:00Z',
      '2026-07-22T09:10:00Z',
      '2026-07-22T09:25:00Z',
      '2026-07-22T09:40:00Z',
    ]
  }

  if (/region/.test(name)) {
    return ['EMEA', 'APAC', 'Americas', 'UK', 'EU', 'Nordics', 'Global']
  }

  if (/status|scenario|owner|desk|family|publication|runbook|window/.test(name)) {
    return ['baseline', 'elevated', 'review', 'validated', 'monitor', 'approved', 'release-ready']
  }

  if (/score|index|ratio/.test(name)) {
    return ['0.12', '0.24', '0.31', '0.47', '0.58', '0.73', '0.84']
  }

  if (/price|bid|ask|last|eps/.test(name)) {
    return ['71.24', '84.11', '103.08', '118.42', '132.77', '149.30', '166.05']
  }

  if (/value|notional|size|allocation|bucket|amount|volume|exposure|revenue|threshold/.test(name) || /(number|integer|float|decimal)/.test(type)) {
    return ['12,500', '19,800', '27,400', '34,600', '48,900', '63,250', '88,400']
  }

  return Array.from({ length: 7 }, (_, index) => `${field.maskedSample || field.name} · sample ${index + 1}`)
}

function previewOriginalValue(field: DatasetDetails['fields'][number], rowIndex: number): string {
  const series = previewSeriesForField(field)
  return series[rowIndex % series.length]
}

function pseudonymisedPreviewValue(field: DatasetDetails['fields'][number], rowIndex: number): string {
  const prefix = field.name.replace(/[^a-z0-9]/gi, '').slice(0, 4).toUpperCase() || 'SAFE'
  return `${prefix}-SAFE-${String(rowIndex + 1).padStart(2, '0')}`
}

function maskedPreviewValue(field: DatasetDetails['fields'][number], rowIndex: number): string {
  const suffix = String(rowIndex + 1).padStart(2, '0')
  const name = field.name.toLowerCase()
  if (/date|time|stamp/.test(name) || /date|timestamp/.test(field.dataType.toLowerCase())) {
    return `masked-window-${suffix}`
  }
  if (/score|index|ratio/.test(name)) {
    return `0.██-${suffix}`
  }
  return `██-masked-${suffix}`
}

function bucketedPreviewValue(field: DatasetDetails['fields'][number], rowIndex: number): string {
  const name = field.name.toLowerCase()
  if (/score|index|ratio/.test(name)) {
    return ['0.10–0.20', '0.20–0.35', '0.35–0.50', '0.50–0.65', '0.65–0.80'][rowIndex % 5]
  }
  if (/price|bid|ask|last|eps/.test(name)) {
    return ['50–75', '75–100', '100–125', '125–150', '150–175'][rowIndex % 5]
  }
  return ['0–10k', '10k–25k', '25k–50k', '50k–75k', '75k–100k'][rowIndex % 5]
}

function aggregatedPreviewValue(field: DatasetDetails['fields'][number], rowIndex: number): string {
  const name = field.name.toLowerCase()
  const type = field.dataType.toLowerCase()
  if (/symbol|instrument/.test(name)) {
    return ['FTSE basket', 'Banks basket', 'Energy basket', 'Index blend', 'Utilities basket'][rowIndex % 5]
  }
  if (/client|account|counterparty|ownergroup|alias|code|ref|identifier|\bid\b/.test(name)) {
    return ['cohort-A', 'cohort-B', 'cohort-C', 'cohort-D', 'cohort-E'][rowIndex % 5]
  }
  if (type === 'date' || type === 'timestamp' || /date|time|stamp/.test(name)) {
    return ['2026-W29', '2026-W30', '2026-W31', '2026-W32', '2026-W33'][rowIndex % 5]
  }
  if (/score|index|ratio/.test(name)) {
    return ['avg 0.18', 'avg 0.27', 'avg 0.39', 'avg 0.52', 'avg 0.68'][rowIndex % 5]
  }
  if (/value|notional|size|allocation|bucket|amount|volume|exposure|revenue|threshold|price|bid|ask|last/.test(name) || /(number|integer|float|decimal)/.test(type)) {
    return ['avg 9.4k', 'avg 15.1k', 'avg 22.8k', 'avg 34.2k', 'avg 49.6k'][rowIndex % 5]
  }
  return ['grouped sample A', 'grouped sample B', 'grouped sample C', 'grouped sample D', 'grouped sample E'][rowIndex % 5]
}

function applyPreviewTransformation(
  kind: TransformationKind,
  field: DatasetDetails['fields'][number],
  currentValue: string,
  rowIndex: number,
): string {
  if (currentValue === '—') return currentValue

  switch (kind) {
    case 'REMOVE_FIELD':
      return '—'
    case 'MASK_VALUE':
      return maskedPreviewValue(field, rowIndex)
    case 'PSEUDONYMISE':
      return pseudonymisedPreviewValue(field, rowIndex)
    case 'BUCKET_NUMERIC':
      return bucketedPreviewValue(field, rowIndex)
    case 'AGGREGATE_RECORDS':
      return aggregatedPreviewValue(field, rowIndex)
    case 'REMOVE_LICENSED_DERIVED':
      return `licensed-field-removed-${String(rowIndex + 1).padStart(2, '0')}`
    case 'STRIP_UNPUBLISHED':
      return ['released summary only', 'publication-safe extract', 'post-release bundle'][rowIndex % 3]
    case 'VERIFY_ANONYMISATION':
      return `verified-anon-${String(rowIndex + 1).padStart(2, '0')}`
    case 'REQUEST_OWNER_CONFIRMATION':
      return `pending-owner-check-${String(rowIndex + 1).padStart(2, '0')}`
  }
}

/* ------------------------------------------------------------------ */
/* Public mock operations                                             */
/* ------------------------------------------------------------------ */

export const mockDb = {
  reset(): void {
    state = seed()
    idSeq = 1000
  },

  /* datasets */
  listDatasets(): DatasetSummary[] {
    return state.details.map(toSummary)
  },
  getDataset(id: string): DatasetDetails {
    const detail = state.details.find((d) => d.id === id)
    if (!detail) throw new Error(`Dataset ${id} not found`)
    return clone(detail)
  },
  getFields(id: string): DatasetDetails['fields'] {
    return clone(this.getDataset(id).fields)
  },
  sendDatasetForHumanReview(datasetId: string): { queued: boolean; reviewItemId?: string } {
    const detail = state.details.find((d) => d.id === datasetId)
    if (!detail) throw new Error(`Dataset ${datasetId} not found`)

    const existing = state.reviews.find((review) => review.datasetId === datasetId)
    if (existing) {
      return { queued: false, reviewItemId: existing.id }
    }

    const reviewItem: ReviewItem = {
      id: nextId('rev'),
      classificationId: nextId('cls'),
      datasetId,
      datasetName: detail.name,
      category: 'CUSTOM_RULE_CHANGE',
      confidence: detail.confidence,
      currentClassification: detail.classification,
      reason: 'Manually sent for human review from the Data Catalogue.',
      evidence: [],
      recommendedAction: 'Review the current classification and confirm or override it.',
      policyReferences: detail.policyReferences,
    }

    detail.reviewStatus = 'REVIEW_REQUIRED'
    state.reviews = [reviewItem, ...state.reviews]

    return { queued: true, reviewItemId: reviewItem.id }
  },

  /* rules */
  listRules(): ClassificationRule[] {
    return clone(state.rules)
  },
  createRule(req: CreateRuleRequest): ClassificationRule {
    const rule: ClassificationRule = {
      id: nextId('custom'),
      name: req.name,
      description: req.description,
      source: 'CUSTOM',
      scope: req.scope,
      scopeFileId: req.scopeFileId,
      scopeLabel: req.scope === 'THIS_FILE' ? 'This file' : 'All files',
      triggerType: req.triggerType,
      triggerSummary: summariseTrigger(req.trigger),
      trigger: req.trigger,
      targetTier: req.targetTier,
      confidence: req.confidence,
      priority: req.priority,
      requireHumanReview: req.requireHumanReview,
      explanationTemplate: req.explanationTemplate,
      enabled: req.enabled,
      protected: false,
      matchedFiles: 0,
      matchStatus: 'UNKNOWN',
      updatedAt: now(),
    }
    state.rules = [rule, ...state.rules]
    pushAudit({
      type: 'CUSTOM_RULE_CREATED',
      summary: `Custom rule "${rule.name}" created`,
      detail: `Target tier ${rule.targetTier}, confidence ${rule.confidence}%.`,
      actor: 'You',
      reference: rule.id,
      datasetId: req.datasetId,
    })
    return clone(rule)
  },
  updateRule(id: string, patch: UpdateRuleRequest): ClassificationRule {
    const rule = state.rules.find((r) => r.id === id)
    if (!rule) throw new Error(`Rule ${id} not found`)
    if (rule.protected) throw new Error('System rules are read-only')
    Object.assign(rule, patch, { updatedAt: now() })
    pushAudit({
      type: patch.enabled === false ? 'CUSTOM_RULE_DISABLED' : 'CUSTOM_RULE_UPDATED',
      summary: `Custom rule "${rule.name}" ${patch.enabled === false ? 'disabled' : 'updated'}`,
      detail: 'Rule state changed via the console.',
      actor: 'You',
      reference: rule.id,
    })
    return clone(rule)
  },
  deleteRule(id: string): void {
    const rule = state.rules.find((r) => r.id === id)
    if (rule?.protected) throw new Error('System rules cannot be deleted')
    state.rules = state.rules.filter((r) => r.id !== id)
  },
  previewRule(req: RulePreviewRequest): RulePreviewResult {
    const detail = req.datasetId ? state.details.find((d) => d.id === req.datasetId) : undefined
    const match = detail ? ruleMatchesDataset(req.trigger, detail) : { matches: true, matchedFields: [] }
    return {
      matches: match.matches,
      matchedFields: match.matchedFields,
      currentClassification: detail?.classification ?? 'UNKNOWN',
      currentConfidence: detail?.confidence ?? 0,
      predictedClassification: match.matches ? req.targetTier : detail?.classification ?? 'UNKNOWN',
      predictedConfidence: match.matches ? req.confidence : detail?.confidence ?? 0,
      requiresHumanReview: req.requireHumanReview,
      explanation:
        req.explanationTemplate ||
        'The backend evaluated the draft rule against the current dataset profile.',
    }
  },

  /* reclassification */
  reclassify(datasetId: string): DatasetDetails {
    const detail = state.details.find((d) => d.id === datasetId)
    if (!detail) throw new Error(`Dataset ${datasetId} not found`)

    pushAudit({
      type: 'RECLASSIFICATION_REQUESTED',
      summary: `Reclassification requested for ${detail.name}`,
      detail: 'Custom rule change triggered reclassification.',
      actor: 'You',
      datasetId,
    })

    const applicable = state.rules
      .filter((r) => r.source === 'CUSTOM' && r.enabled)
      .map((r) => ({ rule: r, ...ruleMatchesDataset(r.trigger, detail) }))
      .filter((r) => r.matches)
      .sort((a, b) => {
        const p = PRIORITY_ORDER[b.rule.priority] - PRIORITY_ORDER[a.rule.priority]
        if (p !== 0) return p
        return TIER_ORDER[b.rule.targetTier] - TIER_ORDER[a.rule.targetTier]
      })

    const top = applicable[0]
    if (top && TIER_ORDER[top.rule.targetTier] >= TIER_ORDER[detail.classification]) {
      detail.classification = top.rule.targetTier
      detail.confidence = top.rule.confidence
      detail.hasCustomRule = true
      detail.matchedRuleCount = detail.matchedRules.length + 1
      detail.reviewStatus = top.rule.requireHumanReview ? 'REVIEW_REQUIRED' : 'CONFIRMED'
      detail.usageStatus = top.rule.targetTier === 'HIGHLY_RESTRICTED' ? 'BLOCKED' : detail.usageStatus
      detail.canBeMadeSafe = true

      const matchedRule: MatchedRule = {
        ruleId: top.rule.id,
        name: top.rule.name,
        source: 'CUSTOM',
        targetTier: top.rule.targetTier,
        priority: top.rule.priority,
        explanation: top.rule.explanationTemplate,
        matchedFields: top.matchedFields,
      }
      if (!detail.matchedRules.some((m) => m.ruleId === top.rule.id)) {
        detail.matchedRules = [matchedRule, ...detail.matchedRules]
      }

      const customEvidence: EvidenceSignal = {
        id: nextId('ev'),
        kind: 'CUSTOM_RULE',
        label: top.rule.name,
        explanation: top.rule.explanationTemplate,
        weight: top.rule.confidence / 100,
        reference: top.rule.id,
        confidence: top.rule.confidence,
      }
      for (const f of detail.fields) {
        if (top.matchedFields.includes(f.name)) {
          f.classification = top.rule.targetTier
          f.confidence = top.rule.confidence
          f.reviewStatus = top.rule.requireHumanReview ? 'REVIEW_REQUIRED' : f.reviewStatus
          f.matchedRuleIds = [...new Set([top.rule.id, ...f.matchedRuleIds])]
          f.matchedRuleNames = [...new Set([top.rule.name, ...f.matchedRuleNames])]
          f.evidence = [customEvidence, ...f.evidence]
          f.whatReducesTier = 'Remove or pseudonymise the fields that trigger the custom rule.'
        }
      }
      detail.protectionSummary = `${detail.protectionSummary} A custom rule ("${top.rule.name}") now applies and raised the tier to ${top.rule.targetTier}.`
      detail.reviewHistory = [
        {
          id: nextId('rh'),
          action: `Reclassified ${detail.name} to ${top.rule.targetTier} by custom rule`,
          actor: 'System',
          note: `${top.rule.name}${top.matchedFields.length ? ` · Fields: ${top.matchedFields.join(', ')}` : ''}`,
          timestamp: now(),
        },
        ...detail.reviewHistory,
      ]

      if (top.rule.requireHumanReview && !state.reviews.some((r) => r.datasetId === datasetId && r.category === 'CUSTOM_RULE_CHANGE')) {
        state.reviews = [
          {
            id: nextId('rev'),
            classificationId: nextId('cls'),
            datasetId,
            datasetName: detail.name,
            category: 'CUSTOM_RULE_CHANGE',
            confidence: top.rule.confidence,
            currentClassification: top.rule.targetTier,
            reason: `Custom rule "${top.rule.name}" raised the tier and requires human review.`,
            evidence: [customEvidence],
            recommendedAction: 'Confirm the new classification or override.',
            policyReferences: detail.policyReferences,
          },
          ...state.reviews,
        ]
      }
    }

    detail.lastAnalysed = now()
    pushAudit({
      type: 'CLASSIFICATION_COMPLETED',
      summary: `${detail.name} classified ${detail.classification}`,
      detail: `Confidence ${detail.confidence}% after reclassification.`,
      actor: 'System',
      datasetId,
    })

    return clone(detail)
  },

  /* usage & remediation */
  getRemediationPlan(datasetId: string): RemediationPlan {
    const existing = state.plans.find((p) => p.datasetId === datasetId)
    if (existing) return clone(existing)
    const detail = this.getDataset(datasetId)
    const plan: RemediationPlan = {
      id: nextId('plan'),
      datasetId,
      datasetName: detail.name,
      riskContributors: detail.fields
        .filter((f) => f.classification === 'HIGHLY_RESTRICTED' || f.classification === 'RESTRICTED')
        .map((f, i) => ({ id: `rc-${datasetId}-${i}`, field: f.name, severity: f.classification === 'HIGHLY_RESTRICTED' ? 'CRITICAL' : 'HIGH', reason: f.whyThisTier, relatedRuleOrPolicy: f.matchedRuleNames[0] ?? 'System rules' })),
      transformations: detail.fields
        .filter((f) => f.classification === 'HIGHLY_RESTRICTED' || f.classification === 'RESTRICTED')
        .map((f, i) => ({ id: `tr-${datasetId}-${i}`, kind: 'REMOVE_FIELD', title: `Remove ${f.name}`, field: f.name, description: `Drop ${f.name} for lower-tier use.`, recommended: f.classification === 'HIGHLY_RESTRICTED' })),
      original: { classification: detail.classification, riskScore: 70, usageStatus: detail.usageStatus, remainingSensitiveFields: detail.fields.filter((f) => f.classification === 'HIGHLY_RESTRICTED').map((f) => f.name), utilityRetained: 100 },
      proposed: { classification: 'CORPORATE', riskScore: 24, usageStatus: 'CONDITIONALLY_ALLOWED', remainingSensitiveFields: [], utilityRetained: 70 },
      createdAt: now(),
    }
    state.plans = [plan, ...state.plans]
    pushAudit({ type: 'REMEDIATION_PLAN_GENERATED', summary: `Remediation plan generated for ${detail.name}`, detail: 'Backend produced recommended transformations.', actor: 'System', datasetId })
    return clone(plan)
  },
  previewRemediation(planId: string, transformationIds: string[]): RemediationPreview {
    const plan = state.plans.find((p) => p.id === planId)
    if (!plan) throw new Error(`Plan ${planId} not found`)
    const detail = state.details.find((d) => d.id === plan.datasetId)

    const recommended = plan.transformations.filter((t) => t.recommended).map((t) => t.id)
    const selected = plan.transformations.filter((t) => transformationIds.includes(t.id))
    const selectedRecommended = recommended.filter((id) => transformationIds.includes(id))
    const fraction = recommended.length ? selectedRecommended.length / recommended.length : transformationIds.length ? 1 : 0

    const addressedFields = new Set(selected.map((t) => t.field))
    const remaining = plan.original.remainingSensitiveFields.filter((f) => !addressedFields.has(f))

    const round = (a: number, b: number) => Math.round(a - (a - b) * fraction)
    const proposed: RemediationMetrics = {
      classification: remaining.length === 0 && fraction >= 1 ? plan.proposed.classification : fraction > 0 ? 'CORPORATE' : plan.original.classification,
      riskScore: round(plan.original.riskScore, plan.proposed.riskScore),
      usageStatus: remaining.length === 0 && fraction >= 1 ? plan.proposed.usageStatus : fraction > 0 ? 'CONDITIONALLY_ALLOWED' : plan.original.usageStatus,
      remainingSensitiveFields: remaining,
      utilityRetained: round(plan.original.utilityRetained, plan.proposed.utilityRetained),
    }

    const fields = detail?.fields ?? []
    const rowCount = Math.min(7, Math.max(3, 2 + selected.length))
    const selectionSignature = transformationIds.slice().sort().join('-') || 'base'
    const maskedPreview: MaskedPreviewRow[] = Array.from({ length: rowCount }, (_, rowIndex) => ({
      id: `prev-${selectionSignature}-${rowIndex}`,
      cells: fields.map((field) => {
        const original = previewOriginalValue(field, rowIndex)
        const applicableTransforms = selected.filter((transformation) => transformation.field === '*' || transformation.field === field.name)
        const transformed = applicableTransforms.reduce(
          (current, transformation) => applyPreviewTransformation(transformation.kind, field, current, rowIndex),
          original,
        )

        return {
          field: field.name,
          original,
          transformed,
          changed: transformed !== original,
        }
      }),
    }))

    return { planId, selectedTransformationIds: transformationIds, proposed, maskedPreview }
  },
  submitPlanReview(planId: string, req: SubmitReviewRequest): ReviewDecision {
    const plan = state.plans.find((p) => p.id === planId)
    const decision: ReviewDecision = {
      id: nextId('dec'),
      reviewItemId: planId,
      datasetName: plan ? `${plan.datasetName} (safe)` : 'Safe version',
      decision: req.decision,
      reviewer: 'You',
      note: req.note,
      timestamp: now(),
    }
    state.decisions = [decision, ...state.decisions]
    if (plan && !state.reviews.some((r) => r.datasetId === plan.datasetId && r.category === 'PROPOSED_SAFE_VERSION')) {
      state.reviews = [
        {
          id: nextId('rev'),
          classificationId: nextId('cls'),
          datasetId: plan.datasetId,
          datasetName: `${plan.datasetName} (safe)`,
          category: 'PROPOSED_SAFE_VERSION',
          confidence: 92,
          currentClassification: plan.original.classification,
          proposedClassification: plan.proposed.classification,
          reason: 'Proposed safe version submitted for approval.',
          evidence: [{ id: nextId('ev'), kind: 'HUMAN', label: 'Remediation plan submitted', explanation: 'Analyst submitted a safe version for approval.', weight: 0.4, actor: 'You' }],
          recommendedAction: 'Approve the safe version to generate a Data Passport.',
          policyReferences: [],
        },
        ...state.reviews,
      ]
    }
    pushAudit({ type: 'REMEDIATION_PLAN_GENERATED', summary: `Safe version submitted for review`, detail: plan ? plan.datasetName : planId, actor: 'You', datasetId: plan?.datasetId })
    return clone(decision)
  },

  /* reviews */
  listReviews(): ReviewItem[] {
    return clone(state.reviews)
  },
  /** Best-effort lookup used by the backend review-decision bridge (does not mutate state). */
  findReviewItem(reviewItemId: string): ReviewItem | undefined {
    const found = state.reviews.find((r) => r.id === reviewItemId)
    return found ? clone(found) : undefined
  },
  listReviewDecisions(): ReviewDecision[] {
    return clone(state.decisions)
  },
  submitReview(reviewItemId: string, req: SubmitReviewRequest): ReviewDecision {
    const item = state.reviews.find((r) => r.id === reviewItemId)
    const decisionTimestamp = now()
    const decision: ReviewDecision = {
      id: nextId('dec'),
      reviewItemId,
      datasetName: item?.datasetName ?? 'Unknown dataset',
      decision: req.decision,
      reviewer: 'You',
      note: req.note,
      timestamp: decisionTimestamp,
    }

    const datasetId = req.datasetId ?? item?.datasetId
    const detail = datasetId ? state.details.find((d) => d.id === datasetId) : undefined

    if (detail) {
      if (req.decision === 'APPROVE') {
        detail.reviewStatus = 'CONFIRMED'
      } else if (req.decision === 'OVERRIDE' || req.decision === 'REQUEST_CHANGES' || req.decision === 'REJECT_USAGE') {
        detail.reviewStatus = 'OVERRIDDEN'
      }

      if ((req.decision === 'OVERRIDE' || req.decision === 'REQUEST_CHANGES') && req.overrideTier) {
        detail.classification = req.overrideTier
        detail.usageStatus = defaultUsageForTier(req.overrideTier)
        detail.whyThisTier = `Reviewer requested changes and set target tier to ${req.overrideTier}.`
      }

      if (req.decision === 'REJECT_USAGE') {
        detail.usageStatus = 'BLOCKED'
      }

      const fieldReviewStatus = detail.reviewStatus === 'CONFIRMED' ? 'CONFIRMED' : 'OVERRIDDEN'
      detail.fields = detail.fields.map((field) => ({
        ...field,
        reviewStatus: fieldReviewStatus,
        classification:
          (req.decision === 'OVERRIDE' || req.decision === 'REQUEST_CHANGES') && req.overrideTier
            ? req.overrideTier
            : field.classification,
      }))

      detail.reviewHistory = [
        {
          id: nextId('rh'),
          action: req.decision,
          actor: req.reviewerName ?? 'You',
          note: req.note,
          timestamp: decisionTimestamp,
        },
        ...detail.reviewHistory,
      ]
      detail.lastAnalysed = decisionTimestamp
    }

    state.decisions = [decision, ...state.decisions]
    state.reviews = state.reviews.filter((r) => r.id !== reviewItemId)
    if (req.decision === 'OVERRIDE' || req.decision === 'REQUEST_CHANGES') {
      pushAudit({ type: 'CLASSIFICATION_OVERRIDDEN', summary: `Classification overridden for ${decision.datasetName}`, detail: req.note ?? 'Reviewer override.', actor: 'You', datasetId: item?.datasetId })
    } else if (req.decision === 'APPROVE' && item?.category === 'PROPOSED_SAFE_VERSION') {
      pushAudit({ type: 'SAFE_VERSION_APPROVED', summary: `Safe version approved for ${decision.datasetName}`, detail: 'Reviewer approved the proposed safe version.', actor: 'You', datasetId: item?.datasetId })
    }
    return clone(decision)
  },
  approveSafeVersion(datasetId: string): DataPassport {
    const detail = this.getDataset(datasetId)
    const plan = state.plans.find((p) => p.datasetId === datasetId)
    const passport: DataPassport = state.passports[datasetId]
      ? clone(state.passports[datasetId])
      : {
          reference: nextId('CF-PASS'),
          originalDatasetId: datasetId,
          originalDatasetName: detail.name,
          safeDatasetName: detail.name.replace(/\.(\w+)$/, '.safe.$1'),
          originalClassification: detail.classification,
          approvedClassification: plan?.proposed.classification ?? 'CORPORATE',
          intendedUse: 'Share with an external partner',
          appliedTransformations: plan?.transformations.filter((t) => t.recommended).map((t) => t.title) ?? [],
          systemRulesApplied: detail.matchedRules.filter((m) => m.source === 'SYSTEM').map((m) => m.name),
          customRulesApplied: detail.matchedRules.filter((m) => m.source === 'CUSTOM').map((m) => m.name),
          remainingConditions: plan?.proposed.remainingSensitiveFields.length ? ['Residual fields require review.'] : [],
          reviewer: 'You',
          approvedAt: now(),
          auditReference: nextId('aud-ref'),
        }
    state.passports[datasetId] = passport
    pushAudit({ type: 'SAFE_VERSION_APPROVED', summary: `Safe version approved for ${detail.name}`, detail: `Approved as ${passport.approvedClassification}.`, actor: 'You', datasetId })
    pushAudit({ type: 'DATA_PASSPORT_GENERATED', summary: `Data Passport ${passport.reference} generated`, detail: `For ${passport.safeDatasetName}.`, actor: 'System', datasetId, reference: passport.reference })
    return clone(passport)
  },
  getPassport(datasetId: string): DataPassport | null {
    return state.passports[datasetId] ? clone(state.passports[datasetId]) : null
  },

  /* sources, files, scans */
  listSources(): DataSource[] {
    return clone(state.sources)
  },
  createSource(input: { name: string; kind: DataSource['kind']; locator: string }): DataSource {
    const source: DataSource = { id: nextId('src'), name: input.name, kind: input.kind, locator: input.locator, status: 'CONNECTED', datasetsDiscovered: 0, lastScan: null, createdAt: now() }
    state.sources = [source, ...state.sources]
    pushAudit({ type: 'SOURCE_CREATED', summary: `${input.name} source created`, detail: `${input.kind} source connected.`, actor: 'You', reference: source.id })
    return clone(source)
  },
  uploadFile(input: { filename: string; fileType: UploadedFile['fileType']; sizeBytes: number }): UploadedFile {
    const file: UploadedFile = {
      id: nextId('file'),
      filename: input.filename,
      fileType: input.fileType,
      sizeBytes: input.sizeBytes,
      estimatedRows: 640,
      detectedFields: ['ownergroup', 'internal_code', 'entity_alias'],
      explicitMarkers: [],
      activeRuleIds: ['sys-8', 'sys-9'],
      uploadStatus: 'PROFILED',
      sourceId: 'src-uploads',
    }
    state.files = [file, ...state.files]
    pushAudit({ type: 'FILE_UPLOADED', summary: `${input.filename} uploaded`, detail: `${file.detectedFields.length} fields detected.`, actor: 'You' })
    return clone(file)
  },
  listFiles(): UploadedFile[] {
    return clone(state.files)
  },
  deleteFile(fileId: string): void {
    const file = state.files.find((f) => f.id === fileId)
    if (!file) throw new Error(`File ${fileId} not found`)
    state.files = state.files.filter((f) => f.id !== fileId)
    pushAudit({
      type: 'FILE_UPLOADED',
      summary: `${file.filename} removed`,
      detail: 'Uploaded file removed from configured sources.',
      actor: 'You',
      reference: fileId,
    })
  },
  deleteSource(sourceId: string): void {
    const source = state.sources.find((s) => s.id === sourceId)
    if (!source) throw new Error(`Source ${sourceId} not found`)
    state.sources = state.sources.filter((s) => s.id !== sourceId)
    state.files = state.files.filter((f) => f.sourceId !== sourceId)
    pushAudit({
      type: 'SOURCE_CREATED',
      summary: `${source.name} source removed`,
      detail: 'Source connection and related uploaded files were removed.',
      actor: 'You',
      reference: sourceId,
    })
  },
  getFile(id: string): UploadedFile {
    const file = state.files.find((f) => f.id === id) ?? state.files[0]
    if (!file) throw new Error('No uploaded files')
    return clone(file)
  },
  startScan(input: { sourceId?: string; fileId?: string }): { scanId: string } {
    const file = input.fileId
      ? state.files.find((f) => f.id === input.fileId)
      : input.sourceId
        ? state.files.find((f) => f.sourceId === input.sourceId)
        : state.files[0]
    const sourceId = input.sourceId ?? file?.sourceId
    const source = sourceId ? state.sources.find((s) => s.id === sourceId) : undefined
    if (source) source.status = 'SCANNING'

    const scanId = nextId('scan')
    const stages = clone(scanStageTemplate).map((stage, index) => ({
      ...stage,
      status: index === 0 ? ('ACTIVE' as const) : ('PENDING' as const),
    }))
    state.scans[scanId] = {
      id: scanId,
      state: 'RUNNING',
      progress: 15,
      currentStageKey: stages[0]?.key ?? 'received',
      fileName: file?.filename ?? source?.name ?? 'source scan',
      fieldsAnalysed: file?.detectedFields.length ?? 0,
      matchedRuleCount: file?.activeRuleIds.length ?? 0,
      stages,
      events: [
        {
          id: nextId('se'),
          timestamp: now(),
          stageKey: 'received',
          message: `Scan started for ${file?.filename ?? source?.name ?? 'selected source'}.`,
        },
      ],
      provisionalResult: null,
    }
    pushAudit({
      type: 'SCAN_STARTED',
      summary: `Scan started for ${file?.filename ?? source?.name ?? 'selected source'}`,
      detail: 'Live polling now tracks scan progress from the backend.',
      actor: 'You',
      reference: scanId,
    })
    return { scanId }
  },
  cancelScan(scanId: string): void {
    const scan = state.scans[scanId]
    if (!scan) throw new Error(`Scan ${scanId} not found`)
    scan.state = 'FAILED'
    scan.currentStageKey = scan.currentStageKey || 'review'
    scan.events = [
      ...scan.events,
      {
        id: nextId('se'),
        timestamp: now(),
        stageKey: scan.currentStageKey,
        message: 'Scan cancelled by user.',
      },
    ]
    for (const source of state.sources) {
      if (source.status === 'SCANNING') source.status = 'CONNECTED'
    }
    pushAudit({
      type: 'SCAN_STARTED',
      summary: `Scan cancelled (${scanId})`,
      detail: 'User cancelled the scan before completion.',
      actor: 'You',
      reference: scanId,
    })
  },
  ingestBackendClassification(fileId: string, response: BackendClassifyResponse): { scanId: string } {
    const result = response.results[0]
    if (!result) return { scanId: 'scan-2026-07-22' }

    const file = state.files.find((f) => f.id === fileId)
    const classification = backendTierToFrontendTier(result.classification)
    const confidencePct = Math.max(0, Math.min(100, Math.round(result.confidence * 100)))
    const aiRuleConflict = result.classification_source === 'conflict'
    const needsReviewQueue = result.human_review.required || aiRuleConflict
    const reviewReason =
      result.human_review.reason ??
      (aiRuleConflict
        ? 'AI classification disagreed with deterministic rules. Human review required.'
        : 'Backend requested human review.')
    const fieldReviewStatus: DatasetDetails['reviewStatus'] = needsReviewQueue ? 'REVIEW_REQUIRED' : 'AUTO'
    const datasetId = `dataset-${fileId}`

    const baseEvidence: EvidenceSignal[] = normalizeReviewEvidence(
      result.evidence.map((ev) => ({
        id: nextId('ev'),
        kind: signalToEvidenceKind(ev.signal),
        label: ev.signal.replace(/_/g, ' '),
        explanation: formatEvidenceExplanation(ev.detail),
        weight: 0.3,
        reference: ev.source,
        confidence: confidencePct,
      })),
    )

    const overrideFields = Array.isArray(result.field_overrides) ? result.field_overrides : []
    const fields =
      overrideFields.length > 0
        ? overrideFields.map((override, index) => {
            const name = String(override.field_name ?? override.field ?? override.name ?? `field_${index + 1}`)
            const tier = backendTierToFrontendTier(String(override.classification ?? result.classification))
            const fieldConfidence = Math.max(0, Math.min(100, Math.round(Number(override.confidence ?? result.confidence) * 100)))
            return {
              id: `${datasetId}-field-${index + 1}`,
              name,
              dataType: String(override.data_type ?? 'string'),
              classification: tier,
              confidence: fieldConfidence,
              matchedRuleIds: [],
              matchedRuleNames: [],
              maskedSample: '***',
              reviewStatus: fieldReviewStatus,
              evidence: baseEvidence,
              whyThisTier: result.explanation,
              whatReducesTier: 'Apply masking, tokenisation, or removal to lower exposure.',
            }
          })
        : [
            {
              id: `${datasetId}-field-1`,
              name: 'content',
              dataType: 'string',
              classification,
              confidence: confidencePct,
              matchedRuleIds: [],
              matchedRuleNames: [],
              maskedSample: '***',
              reviewStatus: fieldReviewStatus,
              evidence: baseEvidence,
              whyThisTier: result.explanation,
              whatReducesTier: 'Apply masking, tokenisation, or removal to lower exposure.',
            },
          ]

    const policyReferences = result.guidance_references.map((ref, index) => ({
      policyId: `policy-${index + 1}`,
      code: `POL-${index + 1}`,
      section: 'N/A',
      title: ref,
    }))

    const aiClassification = buildAiClassificationBreakdown(result)
    const remediationSuggestions = (result.remediation_suggestions ?? []).map((suggestion) => ({
      fieldName: suggestion.field_name,
      transformation: suggestion.transformation,
      reason: suggestion.reason,
      impact: suggestion.impact ?? undefined,
    }))

    // User-defined rules (from /api/classification-rules) that the backend matched
    // against this asset and folded into the final classification — surfaced here so
    // the "Matched rules" panel reflects reality instead of always showing empty.
    const matchedRules: MatchedRule[] = (result.custom_rule_matches ?? []).map((match) => ({
      ruleId: match.rule_id,
      name: match.rule_name,
      source: 'CUSTOM',
      targetTier: backendTierToFrontendTier(match.target_classification),
      priority: (match.priority as RulePriority) ?? 'NORMAL',
      explanation: match.explanation,
      matchedFields: match.matched_fields ?? [],
    }))

    const detail: DatasetDetails = {
      id: datasetId,
      name: file?.filename ?? result.asset_path,
      sourceKind: 'FILE',
      sourceName: 'Uploaded Files',
      sourceLocation: file?.filename ?? result.asset_path,
      rowCount: file?.estimatedRows ?? 0,
      fieldCount: fields.length,
      classification,
      confidence: confidencePct,
      reviewStatus: fieldReviewStatus,
      usageStatus: defaultUsageForTier(classification),
      matchedRuleCount: matchedRules.length || baseEvidence.length,
      hasCustomRule: matchedRules.length > 0,
      canBeMadeSafe: classification === 'RESTRICTED' || classification === 'HIGHLY_RESTRICTED',
      lastAnalysed: now(),
      attentionReason: needsReviewQueue ? reviewReason : undefined,
      protectionSummary: result.explanation,
      whyThisTier: result.explanation,
      owner: 'Data Steward Team',
      retention: '12 months',
      explicitMarkers: [],
      matchedRules,
      fields,
      aiClassification,
      remediationSuggestions,
      reviewHistory: [
        {
          id: nextId('rh'),
          action: `Classified as ${classification}`,
          actor: 'System',
          note: result.explanation,
          timestamp: now(),
        },
      ],
      policyReferences,
    }

    const existingDetailIndex = state.details.findIndex((d) => d.id === datasetId)
    if (existingDetailIndex >= 0) {
      state.details[existingDetailIndex] = detail
    } else {
      state.details = [detail, ...state.details]
    }

    if (file) {
      file.detectedFields = fields.map((f) => f.name)
      file.estimatedRows = Math.max(file.estimatedRows, 1)
      file.uploadStatus = 'READY'
    }

    if (needsReviewQueue) {
      const reviewId = result.review_key || nextId('review-key')
      const review: ReviewItem = {
        id: reviewId,
        classificationId: reviewId,
        datasetId,
        datasetName: detail.name,
        category: aiRuleConflict
          ? 'MARKER_CONFLICT'
          : classification === 'HIGHLY_RESTRICTED'
            ? 'HIGHLY_RESTRICTED_AUTO'
            : 'LOW_CONFIDENCE',
        confidence: confidencePct,
        currentClassification: classification,
        reason: reviewReason,
        evidence: baseEvidence,
        recommendedAction: 'Validate the classification or override with a reviewer decision.',
        policyReferences,
      }
      state.reviews = [review, ...state.reviews.filter((r) => r.id !== review.id)]
    }

    const scanId = nextId('scan')
    const stages = clone(scanStageTemplate).map((stage, index) => ({
      ...stage,
      status: index === 0 ? ('ACTIVE' as const) : ('PENDING' as const),
    }))
    const scan: import('@/types').ScanStatus = {
      id: scanId,
      state: 'RUNNING',
      progress: 15,
      currentStageKey: stages[0]?.key ?? 'received',
      fileName: file?.filename ?? result.asset_path,
      fieldsAnalysed: fields.length,
      matchedRuleCount: detail.matchedRuleCount,
      stages,
      events: [
        { id: nextId('se'), timestamp: now(), stageKey: 'received', message: `File received: ${file?.filename ?? result.asset_path}.` },
        { id: nextId('se'), timestamp: now(), stageKey: 'classification', message: `Classification completed: ${classification} (${confidencePct}%).` },
        { id: nextId('se'), timestamp: now(), stageKey: 'completed', message: 'Scan completed.' },
      ],
      provisionalResult: {
        datasetId,
        datasetName: detail.name,
        classification,
        confidence: confidencePct,
        reviewStatus: detail.reviewStatus,
      },
    }
    state.scans[scanId] = scan

    pushAudit({
      type: 'SCAN_STARTED',
      summary: `Scan started for ${detail.name}`,
      detail: 'Frontend triggered backend classifier bridge.',
      actor: 'You',
      datasetId,
    })
    pushAudit({
      type: 'CLASSIFICATION_COMPLETED',
      summary: `${detail.name} classified ${classification}`,
      detail: `Confidence ${confidencePct}%.`,
      actor: 'System',
      datasetId,
    })

    return { scanId }
  },
  getScan(scanId: string): import('@/types').ScanStatus {
    const scan = state.scans[scanId]
    if (!scan) return clone(this.buildScan(scanId))
    if (scan.state === 'RUNNING') {
      const progressed = nextProgress(scan.progress)
      scan.progress = progressed
      const idx = stageIndexFromProgress(progressed, scan.stages)
      scan.currentStageKey = scan.stages[idx]?.key ?? scan.currentStageKey
      scan.stages = scan.stages.map((stage, index) => ({
        ...stage,
        status: index < idx ? 'COMPLETE' : index === idx ? 'ACTIVE' : 'PENDING',
      }))
      if (scan.events.length < idx + 2) {
        scan.events = [
          ...scan.events,
          {
            id: nextId('se'),
            timestamp: now(),
            stageKey: scan.currentStageKey,
            message: `${scan.stages[idx]?.label ?? 'Stage'} in progress (${progressed}%).`,
          },
        ]
      }

      if (progressed >= 100) {
        scan.state = 'COMPLETE'
        scan.stages = scan.stages.map((stage) => ({ ...stage, status: 'COMPLETE' }))
        scan.currentStageKey = 'completed'
        if (!scan.provisionalResult) {
          scan.provisionalResult = {
            datasetId: 'mixed_market_client_log',
            datasetName: scan.fileName,
            classification: 'HIGHLY_RESTRICTED',
            confidence: 96,
            reviewStatus: 'AUTO',
          }
        }
        scan.events = [
          ...scan.events,
          {
            id: nextId('se'),
            timestamp: now(),
            stageKey: 'completed',
            message: 'Scan completed.',
          },
        ]
        for (const source of state.sources) {
          if (source.status === 'SCANNING') {
            source.status = 'CONNECTED'
            source.lastScan = now()
          }
        }
      }
    }
    return clone(scan)
  },
  buildScan(scanId: string): import('@/types').ScanStatus {
    if (state.scans[scanId]) {
      return clone(state.scans[scanId])
    }
    // A fully-progressed, backend-shaped scan snapshot for the mock.
    const stages = clone(scanStageTemplate).map((s) => ({ ...s, status: 'COMPLETE' as const }))
    return {
      id: scanId,
      state: 'COMPLETE',
      progress: 100,
      currentStageKey: 'completed',
      fileName: 'mixed_market_client_log.csv',
      fieldsAnalysed: 8,
      matchedRuleCount: 2,
      stages,
      events: [
        { id: 'se-1', timestamp: '2026-07-21T16:59:00Z', stageKey: 'received', message: 'File received: mixed_market_client_log.csv (8.7 MB).' },
        { id: 'se-2', timestamp: '2026-07-21T16:59:04Z', stageKey: 'structure', message: 'Structure profiled: 8 fields, ~88,400 rows.' },
        { id: 'se-3', timestamp: '2026-07-21T16:59:07Z', stageKey: 'markers', message: 'Explicit markers checked: none found.' },
        { id: 'se-4', timestamp: '2026-07-21T16:59:12Z', stageKey: 'fields', message: 'Fields analysed: client_id, account_number flagged.' },
        { id: 'se-5', timestamp: '2026-07-21T16:59:16Z', stageKey: 'system_rules', message: 'System rules evaluated: 2 matched (highest-sensitivity, account identifiers).' },
        { id: 'se-6', timestamp: '2026-07-21T16:59:18Z', stageKey: 'custom_rules', message: 'Custom rules evaluated: 0 matched.' },
        { id: 'se-7', timestamp: '2026-07-21T16:59:20Z', stageKey: 'classification', message: 'Classification created: Highly Restricted (96%).' },
        { id: 'se-8', timestamp: '2026-07-21T16:59:22Z', stageKey: 'review', message: 'Review requirements evaluated: automated Highly Restricted flagged.' },
        { id: 'se-9', timestamp: '2026-07-21T16:59:25Z', stageKey: 'remediation', message: 'Remediation opportunities generated: 3 fields recommended for removal.' },
        { id: 'se-10', timestamp: '2026-07-21T16:59:26Z', stageKey: 'completed', message: 'Scan completed.' },
      ],
      provisionalResult: { datasetId: 'mixed_market_client_log', datasetName: 'mixed_market_client_log.csv', classification: 'HIGHLY_RESTRICTED', confidence: 96, reviewStatus: 'AUTO' },
    }
  },

  /* policies, audit, dashboard */
  listPolicies() {
    return clone(state.policies)
  },
  getPolicy(id: string) {
    return clone(state.policies.find((p) => p.id === id) ?? state.policies[0])
  },
  uploadPolicyDocument(file: File) {
    const name = file.name.replace(/\.[^.]+$/, '')
    const ext = file.name.toLowerCase().endsWith('.pdf') ? '.pdf' : '.txt'
    const policyId = nextId('pol')
    const policy: import('@/types').PolicyDocument = {
      id: policyId,
      name: `Uploaded Policy: ${name}`,
      version: 'draft-upload',
      status: 'DRAFT',
      classificationsUsing: 0,
      ingestedAt: now(),
      coverage: 35,
      sections: [
        {
          id: `${policyId}-1`,
          reference: `UPLOAD ${ext.toUpperCase()}`,
          title: 'Imported policy content',
          body: {
            en: `Policy file \"${file.name}\" uploaded and queued for parsing.`,
            fr: `Le fichier de politique \"${file.name}\" a ete telecharge et mis en file d'attente pour analyse.`,
          },
          datasetsUsing: [],
        },
      ],
    }
    state.policies = [policy, ...state.policies]
    pushAudit({
      type: 'SOURCE_CREATED',
      summary: `Policy uploaded: ${file.name}`,
      detail: 'Policy document queued for governance indexing.',
      actor: 'You',
      reference: policy.id,
    })
    return clone(policy)
  },
  listAudit(): AuditEvent[] {
    return clone(state.audit)
  },
  dashboard() {
    return buildDashboard(this.listDatasets(), state.rules, state.reviews, state.audit)
  },
}

function summariseTrigger(trigger: RuleTrigger): string {
  switch (trigger.type) {
    case 'FIELD_COMBINATION':
      return `All present: ${trigger.fields.join(', ')}`
    case 'FIELD_NAME':
      return `Field name in: ${trigger.aliases.join(', ')}`
    case 'FILE_NAME':
      return `File name ${trigger.operator.replace('_', ' ')} "${trigger.value}"`
    case 'EXPLICIT_MARKER':
      return `Marker "${trigger.markerText}"`
    case 'CONTENT_PATTERN':
      return `Content ${trigger.mode} pattern "${trigger.pattern}"`
    case 'DOCUMENT_TYPE':
      return `Document type ${trigger.documentType}`
    case 'METADATA_STATUS':
      return `${trigger.key} = ${trigger.expectedValue}`
  }
}
