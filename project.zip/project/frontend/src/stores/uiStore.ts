import { create } from 'zustand'
import type { RuleScope, RuleTriggerType } from '@/types'

/**
 * Local UI state only (Zustand). No backend entities are stored here — those
 * live in TanStack Query. This holds sidebar state, which drawers/sheets are
 * open, and temporary (non-URL) filters.
 */

export interface AddRuleContext {
  ruleId?: string
  datasetId?: string
  fileId?: string
  fileName?: string
}

export interface EvidenceDrawerState {
  open: boolean
  datasetId?: string
  fieldId?: string
}

export interface RulesFilterState {
  search: string
  tier: string
  trigger: RuleTriggerType | 'ALL'
  enabled: 'ALL' | 'ENABLED' | 'DISABLED'
  scope: 'ALL' | RuleScope
}

interface UiState {
  /* sidebar */
  sidebarCollapsed: boolean
  toggleSidebar: () => void
  setSidebar: (collapsed: boolean) => void

  /* evidence drawer */
  evidence: EvidenceDrawerState
  openEvidence: (datasetId: string, fieldId: string) => void
  closeEvidence: () => void

  /* add rule drawer */
  addRuleOpen: boolean
  addRuleContext: AddRuleContext
  openAddRule: (context?: AddRuleContext) => void
  closeAddRule: () => void

  /* rule details drawer */
  ruleDetailsId: string | null
  openRuleDetails: (ruleId: string) => void
  closeRuleDetails: () => void

  /* policy side sheet */
  policySheetId: string | null
  openPolicy: (policyId: string) => void
  closePolicy: () => void

  /* temporary (non-URL) rules filters */
  rulesFilter: RulesFilterState
  setRulesFilter: (patch: Partial<RulesFilterState>) => void
  resetRulesFilter: () => void

  /* dark mode */
  darkMode: boolean
  toggleDarkMode: () => void

  /* keyboard shortcuts modal */
  shortcutsOpen: boolean
  openShortcuts: () => void
  closeShortcuts: () => void
  toggleShortcuts: () => void
}

const initialRulesFilter: RulesFilterState = {
  search: '',
  tier: 'ALL',
  trigger: 'ALL',
  enabled: 'ALL',
  scope: 'ALL',
}

export const useUiStore = create<UiState>((set) => ({
  sidebarCollapsed: false,
  toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
  setSidebar: (collapsed) => set({ sidebarCollapsed: collapsed }),

  evidence: { open: false },
  openEvidence: (datasetId, fieldId) => set({ evidence: { open: true, datasetId, fieldId } }),
  closeEvidence: () => set({ evidence: { open: false } }),

  addRuleOpen: false,
  addRuleContext: {},
  openAddRule: (context = {}) => set({ addRuleOpen: true, addRuleContext: context }),
  closeAddRule: () => set({ addRuleOpen: false }),

  ruleDetailsId: null,
  openRuleDetails: (ruleId) => set({ ruleDetailsId: ruleId }),
  closeRuleDetails: () => set({ ruleDetailsId: null }),

  policySheetId: null,
  openPolicy: (policyId) => set({ policySheetId: policyId }),
  closePolicy: () => set({ policySheetId: null }),

  rulesFilter: initialRulesFilter,
  setRulesFilter: (patch) => set((s) => ({ rulesFilter: { ...s.rulesFilter, ...patch } })),
  resetRulesFilter: () => set({ rulesFilter: initialRulesFilter }),

  darkMode: false,
  toggleDarkMode: () => set((s) => ({ darkMode: !s.darkMode })),

  shortcutsOpen: false,
  openShortcuts: () => set({ shortcutsOpen: true }),
  closeShortcuts: () => set({ shortcutsOpen: false }),
  toggleShortcuts: () => set((s) => ({ shortcutsOpen: !s.shortcutsOpen })),
}))
