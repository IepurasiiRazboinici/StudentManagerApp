import type { DataPassport, ReviewDecision, ReviewItem, SubmitReviewRequest } from '@/types'
import { mockDb } from '@/mocks/db'
import { isClassifierBridgeEnabled, mapFrontendTierToBackendLabel, submitReviewDecisionToBackend } from './backendClassifierApi'
import { request } from './apiClient'

/** Backend review_keys are generated as `rk-<hash>` (see backend/classifier/review_memory.py). */
function isBackendReviewKey(id: string): boolean {
  return id.startsWith('rk-')
}

export const reviewsApi = {
  getQueue: () =>
    request<ReviewItem[]>('/reviews/queue', {
      mock: () => mockDb.listReviews(),
    }),

  getDecisions: () =>
    request<ReviewDecision[]>('/reviews/decisions', {
      mock: () => mockDb.listReviewDecisions(),
    }),

  submitReview: async (classificationId: string, req: SubmitReviewRequest): Promise<ReviewDecision> => {
    const reviewItemId = req.reviewItemId ?? classificationId

    // Bridge straight to the real backend (bypassing the mock layer, same pattern as
    // `classifyUploadWithBackend`) whenever this review item came from a real backend
    // classification (review_key format `rk-...`) and the decision resolves to a
    // specific corrected tier. This persists the decision in
    // `backend/review_memory.json` so future classifications of similarly-shaped
    // assets reuse it, per the backend's intended human-review workflow.
    if (isClassifierBridgeEnabled() && req.overrideTier && isBackendReviewKey(reviewItemId)) {
      try {
        const item = mockDb.findReviewItem(reviewItemId)
        await submitReviewDecisionToBackend({
          review_key: reviewItemId,
          corrected_classification: mapFrontendTierToBackendLabel(req.overrideTier),
          reviewer_note: req.note ?? '',
          reviewer_id: 'frontend-reviewer',
          asset_path: item?.datasetName,
        })
      } catch (error) {
        console.warn('Backend review-decision bridge failed; continuing with local mock flow.', error)
      }
    }

    return request<ReviewDecision>(`/classifications/${classificationId}/review`, {
      method: 'POST',
      body: req,
      mock: () => mockDb.submitReview(reviewItemId, req),
      delay: 350,
    })
  },

  approveSafeVersion: (datasetId: string) =>
    request<DataPassport>(`/datasets/${datasetId}/approve-safe-version`, {
      method: 'POST',
      mock: () => mockDb.approveSafeVersion(datasetId),
      delay: 600,
    }),
}

