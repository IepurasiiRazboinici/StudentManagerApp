import type { ClassificationTier } from '@/types'

export interface BackendEvidenceItem {
  signal: string
  detail: string
  source: string
}

export interface BackendHumanReview {
  required: boolean
  reason?: string | null
  suggested_action?: string
}

/** A remediation/masking suggestion returned by the LLM for a specific field
 * (e.g. REMOVE_FIELD, MASK_VALUE, PSEUDONYMISE). Independent of which tier
 * ultimately won (rules vs. AI) — these are always worth surfacing since they
 * come directly from the model's analysis of the asset. */
export interface BackendRemediationSuggestion {
  field_name: string
  transformation: string
  reason: string
  impact?: string | null
}

/** A single classification opinion — either the deterministic rule engine or the external LLM. */
export interface BackendSourceClassification {
  classification: string
  confidence: number
  explanation: string
  confidence_reasoning?: string | null
  evidence: BackendEvidenceItem[]
}

export type BackendClassificationSource = 'rules' | 'agreement' | 'conflict'

export interface BackendAssetClassification {
  review_key?: string | null
  asset_path: string
  asset_type: string
  classification: string
  confidence: number
  confidence_reasoning?: string | null
  evidence: BackendEvidenceItem[]
  guidance_references: string[]
  explanation: string
  human_review: BackendHumanReview
  field_overrides?: Array<Record<string, unknown>>
  /** Remediation/masking suggestions produced by the LLM, e.g. "mask this field". */
  remediation_suggestions?: BackendRemediationSuggestion[]
  /** Deterministic rule-engine result, always present. */
  rule_classification?: BackendSourceClassification | null
  /** Raw AI/LLM result, present whenever the LLM call succeeded. */
  ai_classification?: BackendSourceClassification | null
  /** Whether an LLM call was configured and attempted for this asset. */
  ai_attempted?: boolean
  /** Whether the LLM call succeeded and produced a usable classification. */
  ai_used?: boolean
  /** "rules" (no AI), "agreement" (AI matched rules), or "conflict" (AI disagreed). */
  classification_source?: BackendClassificationSource
  /** Best-effort raw/unparsed text returned by the LLM, always present when the
   * LLM responded but its output could not be parsed into `ai_classification`. */
  ai_raw_output?: string | null
  /** Populated when the LLM request itself failed (network/timeout). */
  ai_error?: string | null
  /** User-defined classification rules (see Classification Rules page) that matched
   * this asset and were folded into the final classification/evidence above. */
  custom_rule_matches?: BackendCustomRuleMatch[]
}

/** A user-defined rule (created via the Classification Rules UI) that matched this
 * asset. Mirrors backend `CustomRuleMatch`. */
export interface BackendCustomRuleMatch {
  rule_id: string
  rule_name: string
  target_classification: string
  confidence: number
  priority: string
  require_human_review: boolean
  matched_fields: string[]
  explanation: string
}

export interface BackendClassifyResponse {
  generated_at: string
  taxonomy: string[]
  discovered_assets: number
  results: BackendAssetClassification[]
  distribution: Record<string, number>
}

const CLASSIFIER_BASE_URL = import.meta.env.VITE_CLASSIFIER_API_BASE_URL ?? 'http://localhost:8000/api'
const ENABLE_CLASSIFIER_BRIDGE = import.meta.env.VITE_ENABLE_CLASSIFIER_BRIDGE === 'true'

export function isClassifierBridgeEnabled(): boolean {
  return ENABLE_CLASSIFIER_BRIDGE
}

export function classifierBaseUrl(): string {
  return CLASSIFIER_BASE_URL
}

export function mapBackendTier(label: string): ClassificationTier {
  const normalized = label.trim().toLowerCase()
  if (normalized === 'public') return 'PUBLIC'
  if (normalized === 'corporate' || normalized === 'internal') return 'CORPORATE'
  if (normalized === 'restricted' || normalized === 'confidential') return 'RESTRICTED'
  if (normalized === 'highly restricted' || normalized === 'highly confidential') return 'HIGHLY_RESTRICTED'
  return 'UNKNOWN'
}

/** Inverse of `mapBackendTier` — used when sending a reviewer-corrected tier to the backend. */
export function mapFrontendTierToBackendLabel(tier: ClassificationTier): string {
  const labels: Record<ClassificationTier, string> = {
    PUBLIC: 'Public',
    CORPORATE: 'Corporate',
    RESTRICTED: 'Restricted',
    HIGHLY_RESTRICTED: 'Highly Restricted',
    UNKNOWN: 'Corporate',
  }
  return labels[tier]
}

export async function classifyUploadWithBackend(file: File): Promise<BackendClassifyResponse> {
  const formData = new FormData()
  formData.set('file', file)
  // Always request the AI/LLM classification alongside the deterministic rules
  // so the frontend can display both. The backend's `use_llm` still needs an
  // `llm_endpoint` to actually be configured — it falls back to the hardcoded
  // default endpoint/token in `backend/classifier/constants.py` when none is
  // supplied, so no extra config is required here.
  formData.set('use_llm', 'true')

  const response = await fetch(`${CLASSIFIER_BASE_URL}/classify/upload`, {
    method: 'POST',
    body: formData,
  })

  if (!response.ok) {
    throw new Error(`Classifier upload failed with status ${response.status}`)
  }

  return (await response.json()) as BackendClassifyResponse
}

export interface BackendReviewDecisionRequest {
  review_key: string
  corrected_classification: string
  reviewer_note?: string
  reviewer_id?: string
  asset_type?: string
  asset_path?: string
}

export interface BackendReviewDecisionResponse {
  saved: boolean
  review_key: string
  corrected_classification: string
}

/**
 * Persist a human reviewer decision directly against the real backend, bypassing
 * the mock API layer entirely (same pattern as `classifyUploadWithBackend`). The
 * backend stores this in `backend/review_memory.json` and reuses it as guidance
 * for future classifications of similarly-shaped assets.
 */
export async function submitReviewDecisionToBackend(
  req: BackendReviewDecisionRequest,
): Promise<BackendReviewDecisionResponse> {
  const response = await fetch(`${CLASSIFIER_BASE_URL}/reviews/decision`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req),
  })

  if (!response.ok) {
    throw new Error(`Review decision submission failed with status ${response.status}`)
  }

  return (await response.json()) as BackendReviewDecisionResponse
}

