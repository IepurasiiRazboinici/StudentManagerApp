import type { DataPassport } from '@/types'
import { mockDb } from '@/mocks/db'
import { apiBaseUrl, isMockApi, request } from './apiClient'

export const dataPassportApi = {
  getPassport: (datasetId: string) =>
    request<DataPassport | null>(`/datasets/${datasetId}/data-passport`, {
      mock: () => mockDb.getPassport(datasetId),
    }),

  downloadPassportPdf: async (datasetId: string): Promise<Blob | null> => {
    if (isMockApi()) return null

    const response = await fetch(`${apiBaseUrl()}/datasets/${datasetId}/data-passport/pdf`)
    if (!response.ok) {
      throw new Error(`PDF download failed with status ${response.status}`)
    }

    const contentType = response.headers.get('content-type')?.toLowerCase() ?? ''
    if (!contentType.includes('application/pdf')) {
      throw new Error('Backend did not return application/pdf')
    }

    const blob = await response.blob()
    if (blob.type && !blob.type.toLowerCase().includes('application/pdf')) {
      throw new Error('Invalid PDF payload received from backend')
    }

    return blob
  },
}
