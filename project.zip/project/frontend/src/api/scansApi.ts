import type { ScanStatus } from '@/types'
import { mockDb } from '@/mocks/db'
import { consumePendingClassification } from './backendBridgeStore'
import { request } from './apiClient'

export interface StartScanInput {
  sourceId?: string
  fileId?: string
}

export const scansApi = {
  startScan: (input: StartScanInput) =>
    request<{ scanId: string }>('/scans', {
      method: 'POST',
      body: input,
      mock: () => {
        if (input.fileId) {
          const pending = consumePendingClassification(input.fileId)
          if (pending) {
            return mockDb.ingestBackendClassification(input.fileId, pending)
          }
        }
        return mockDb.startScan(input)
      },
    }),

  getScan: (scanId: string) =>
    request<ScanStatus>(`/scans/${scanId}`, {
      mock: () => mockDb.getScan(scanId),
    }),

  cancelScan: (scanId: string) =>
    request<void>(`/scans/${scanId}/cancel`, {
      method: 'POST',
      mock: () => mockDb.cancelScan(scanId),
    }),

  /** Kicks off a single scan job that sweeps every connected data source. */
  startBatchScan: () =>
    request<{ scanId: string }>('/scans/batch', {
      method: 'POST',
      mock: () => ({ scanId: 'scan-2026-07-22-all' }),
    }),
}
