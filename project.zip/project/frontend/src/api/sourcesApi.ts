import type { DataSource, FileType, UploadedFile } from '@/types'
import { mockDb } from '@/mocks/db'
import { classifyUploadWithBackend, isClassifierBridgeEnabled } from './backendClassifierApi'
import { savePendingClassification } from './backendBridgeStore'
import { request } from './apiClient'

export interface CreateSourceInput {
  name: string
  kind: DataSource['kind']
  locator: string
}

export interface UploadFileInput {
  filename: string
  fileType: FileType
  sizeBytes: number
  rawFile?: File
  onProgress?: (value: number) => void
}

export interface PostgresTestInput {
  host: string
  port: number
  database: string
  username: string
  password: string
}

export interface PostgresTestResult {
  ok: boolean
  schemas: number
  tables: number
  fields: number
}

export const sourcesApi = {
  listSources: () =>
    request<DataSource[]>('/sources', {
      mock: () => mockDb.listSources(),
    }),

  createSource: (input: CreateSourceInput) =>
    request<DataSource>('/sources/postgresql', {
      method: 'POST',
      body: input,
      mock: () => mockDb.createSource(input),
    }),

  testPostgres: (input: PostgresTestInput) =>
    request<PostgresTestResult>('/sources/postgresql/test', {
      method: 'POST',
      body: input,
      mock: () => {
        if (input.password !== '1234') {
          throw new Error('Connection refused')
        }

        return { ok: true, schemas: 3, tables: 11, fields: 86 }
      },
      delay: 500,
    }),

  uploadFile: (input: UploadFileInput) =>
    request<UploadedFile>('/sources/files', {
      method: 'POST',
      body: { filename: input.filename, fileType: input.fileType, sizeBytes: input.sizeBytes },
      mock: async () => {
        input.onProgress?.(0)
        for (const value of [18, 34, 57, 76, 91]) {
          await new Promise<void>((resolve) => setTimeout(resolve, 70))
          input.onProgress?.(value)
        }
        const created = mockDb.uploadFile(input)

        if (isClassifierBridgeEnabled() && input.rawFile) {
          try {
            const response = await classifyUploadWithBackend(input.rawFile)
            savePendingClassification(created.id, response)
          } catch (error) {
            console.warn('Classifier bridge upload failed; continuing with local mock flow.', error)
          }
        }

        input.onProgress?.(100)
        return created
      },
    }),

  getFile: (fileId: string) =>
    request<UploadedFile>(`/sources/files/${fileId}`, {
      mock: () => mockDb.getFile(fileId),
    }),

  listFiles: () =>
    request<UploadedFile[]>('/sources/files', {
      mock: () => mockDb.listFiles(),
    }),

  deleteFile: (fileId: string) =>
    request<void>(`/sources/files/${fileId}`, {
      method: 'DELETE',
      mock: () => mockDb.deleteFile(fileId),
    }),

  deleteSource: (sourceId: string) =>
    request<void>(`/sources/${sourceId}`, {
      method: 'DELETE',
      mock: () => mockDb.deleteSource(sourceId),
    }),
}
