import type { BackendClassifyResponse } from './backendClassifierApi'

const pendingByFileId = new Map<string, BackendClassifyResponse>()

export function savePendingClassification(fileId: string, response: BackendClassifyResponse): void {
  pendingByFileId.set(fileId, response)
}

export function consumePendingClassification(fileId: string): BackendClassifyResponse | undefined {
  const response = pendingByFileId.get(fileId)
  pendingByFileId.delete(fileId)
  return response
}

