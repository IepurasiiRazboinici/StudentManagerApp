import type { PolicyDocument } from '@/types'
import { mockDb } from '@/mocks/db'
import { request } from './apiClient'

export const policiesApi = {
  listPolicies: () =>
    request<PolicyDocument[]>('/policies', {
      mock: () => mockDb.listPolicies(),
    }),

  getPolicy: (policyId: string) =>
    request<PolicyDocument>(`/policies/${policyId}`, {
      mock: () => mockDb.getPolicy(policyId),
    }),

  uploadPolicyDocument: (file: File) => {
    const formData = new FormData()
    formData.append('policy', file)
    return request<PolicyDocument>('/policies/upload', {
      method: 'POST',
      body: formData,
      mock: () => mockDb.uploadPolicyDocument(file),
      delay: 450,
    })
  },
}
