import type {
  ClassificationRule,
  CreateRuleRequest,
  RulePreviewRequest,
  RulePreviewResult,
  UpdateRuleRequest,
} from '@/types'
import { mockDb } from '@/mocks/db'
import { classifierBaseUrl } from './backendClassifierApi'
import { request } from './apiClient'

/**
 * Classification rules created here are actually applied by the real backend during
 * classification (folded into the deterministic result AND forwarded to the external
 * LLM prompt — see `backend/classifier/custom_rules.py` / `service.py`), so unlike most
 * other `*Api` modules, rules are backed by the real backend whenever the classifier
 * bridge is enabled (`VITE_ENABLE_CLASSIFIER_BRIDGE=true`), even while the rest of the
 * app still runs against the in-memory mock API. Falls back to the mock DB only when
 * the bridge is disabled, so the Rules page still works in a pure-mock demo.
 */
async function backendRequest<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(`${classifierBaseUrl()}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...init,
  })
  if (!response.ok) {
    throw new Error(`Rules request to ${path} failed with status ${response.status}`)
  }
  if (response.status === 204) {
    return undefined as T
  }
  return (await response.json()) as T
}

export const rulesApi = {
  listRules: () =>
    request<ClassificationRule[]>('/classification-rules', {
      mock: () => mockDb.listRules(),
      real: () => backendRequest<ClassificationRule[]>('/classification-rules'),
    }),

  createRule: (req: CreateRuleRequest) =>
    request<ClassificationRule>('/classification-rules', {
      method: 'POST',
      body: req,
      mock: () => mockDb.createRule(req),
      real: () => backendRequest<ClassificationRule>('/classification-rules', { method: 'POST', body: JSON.stringify(req) }),
      delay: 500,
    }),

  previewRule: (req: RulePreviewRequest) =>
    request<RulePreviewResult>('/classification-rules/preview', {
      method: 'POST',
      body: req,
      mock: () => mockDb.previewRule(req),
      real: () =>
        backendRequest<RulePreviewResult>('/classification-rules/preview', { method: 'POST', body: JSON.stringify(req) }),
      delay: 650,
    }),

  updateRule: (ruleId: string, patch: UpdateRuleRequest) =>
    request<ClassificationRule>(`/classification-rules/${ruleId}`, {
      method: 'PATCH',
      body: patch,
      mock: () => mockDb.updateRule(ruleId, patch),
      real: () =>
        backendRequest<ClassificationRule>(`/classification-rules/${ruleId}`, {
          method: 'PATCH',
          body: JSON.stringify(patch),
        }),
    }),

  deleteRule: (ruleId: string) =>
    request<{ ok: true }>(`/classification-rules/${ruleId}`, {
      method: 'DELETE',
      mock: () => {
        mockDb.deleteRule(ruleId)
        return { ok: true }
      },
      real: () => backendRequest<{ ok: true }>(`/classification-rules/${ruleId}`, { method: 'DELETE' }),
    }),
}

