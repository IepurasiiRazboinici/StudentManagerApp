/** First letter of up to two words in a display name, e.g. "Jordan Ellis" -> "JE". */
export function initialsOf(name: string): string {
  const initials = name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join('')

  return initials || name.slice(0, 2).toUpperCase()
}
