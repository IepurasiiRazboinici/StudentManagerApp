import { describe, expect, it } from 'vitest'
import {
  clampDateInput,
  clampIsoDateStringToBounds,
  getMaxAllowedDate,
  getMinAllowedDate,
  isWithinDateWindow,
} from './dateBounds'

describe('dateBounds', () => {
  const fixedNow = new Date('2026-07-23T12:00:00Z')

  it('returns configured min and computed max date bounds', () => {
    expect(getMinAllowedDate()).toBe('2026-07-22')
    expect(getMaxAllowedDate(fixedNow)).toBe('2026-07-23')
  })

  it('clamps date input to the supported range', () => {
    expect(clampDateInput('2026-07-01', fixedNow)).toBe('2026-07-22')
    expect(clampDateInput('2026-07-24', fixedNow)).toBe('2026-07-23')
    expect(clampDateInput('2026-07-23', fixedNow)).toBe('2026-07-23')
  })

  it('clamps ISO timestamps to the supported range', () => {
    expect(clampIsoDateStringToBounds('2026-07-01T10:00:00Z', fixedNow)).toBe('2026-07-22T12:00:00Z')
    expect(clampIsoDateStringToBounds('2026-08-01T10:00:00Z', fixedNow)).toBe('2026-07-23T18:00:00Z')
    expect(clampIsoDateStringToBounds('2026-07-23T08:00:00Z', fixedNow)).toBe('2026-07-23T12:00:00Z')
    expect(clampIsoDateStringToBounds('2026-07-23T18:30:00Z', fixedNow)).toBe('2026-07-23T18:00:00Z')
    expect(clampIsoDateStringToBounds('2026-07-23T15:15:00Z', fixedNow)).toBe('2026-07-23T15:15:00Z')
  })

  it('filters timestamps correctly for bounded date windows', () => {
    expect(isWithinDateWindow('2026-07-22T10:00:00Z', '2026-07-22', '2026-07-23')).toBe(true)
    expect(isWithinDateWindow('2026-07-20T10:00:00Z', '2026-07-22', '2026-07-23')).toBe(false)
    expect(isWithinDateWindow('2026-07-24T00:00:00Z', '2026-07-22', '2026-07-23')).toBe(false)
  })
})


