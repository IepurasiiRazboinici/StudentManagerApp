const RESOLVED_SESSION_KEY = 'review-queue-resolved-ids'
const REVIEW_SESSION_EVENT = 'review-queue-session-updated'

function isBrowser(): boolean {
  return typeof window !== 'undefined'
}

export function readResolvedReviewIdsFromSession(): Set<string> {
  if (!isBrowser()) return new Set()
  try {
    const raw = window.sessionStorage.getItem(RESOLVED_SESSION_KEY)
    if (!raw) return new Set()
    const parsed = JSON.parse(raw)
    if (!Array.isArray(parsed)) return new Set()
    return new Set(parsed.filter((value): value is string => typeof value === 'string'))
  } catch {
    return new Set()
  }
}

export function saveResolvedReviewIdsToSession(ids: Set<string>): void {
  if (!isBrowser()) return
  try {
    window.sessionStorage.setItem(RESOLVED_SESSION_KEY, JSON.stringify(Array.from(ids)))
    window.dispatchEvent(new Event(REVIEW_SESSION_EVENT))
  } catch {
    // best-effort session persistence
  }
}

export function onResolvedReviewIdsSessionChange(listener: () => void): () => void {
  if (!isBrowser()) return () => {}
  const handler = () => listener()
  window.addEventListener(REVIEW_SESSION_EVENT, handler)
  window.addEventListener('storage', handler)
  return () => {
    window.removeEventListener(REVIEW_SESSION_EVENT, handler)
    window.removeEventListener('storage', handler)
  }
}

