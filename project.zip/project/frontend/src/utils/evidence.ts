import type { EvidenceSignal } from '@/types'

function normalizeWhitespace(value: string): string {
  return value.replace(/\s+/g, ' ').trim()
}

function normalizeForCompare(value: string): string {
  return normalizeWhitespace(value)
    .toLowerCase()
    .replace(/[“”"'`]/g, '')
}

function uniqueStrings(values: string[]): string[] {
  const seen = new Set<string>()
  const items: string[] = []
  for (const value of values) {
    const normalized = normalizeForCompare(value)
    if (!normalized || seen.has(normalized)) continue
    seen.add(normalized)
    items.push(normalizeWhitespace(value))
  }
  return items
}

function extractStructuredDetailParts(explanation: string): string[] {
  const matches = explanation.matchAll(/["']detail["']:\s*(["'])(.*?)\1/gs)
  return uniqueStrings(Array.from(matches, (match) => match[2]))
}

export function formatEvidenceExplanation(explanation: string): string {
  const normalized = normalizeWhitespace(explanation)
  if (!normalized) return normalized

  const detailParts = extractStructuredDetailParts(normalized)
  if (detailParts.length === 0) return normalized
  return detailParts.join(' ')
}

export function normalizeReviewEvidence(evidence: EvidenceSignal[]): EvidenceSignal[] {
  const parsed = evidence.map((item) => {
    const detailParts = extractStructuredDetailParts(item.explanation)
    const explanation = detailParts.length > 0 ? detailParts.join(' ') : normalizeWhitespace(item.explanation)
    return {
      item: { ...item, explanation },
      detailParts,
      normalizedExplanation: normalizeForCompare(explanation),
    }
  })

  const standaloneDetails = new Set(
    parsed
      .filter((entry) => entry.detailParts.length === 0 && entry.normalizedExplanation)
      .map((entry) => entry.normalizedExplanation),
  )

  const seenExplanations = new Set<string>()

  return parsed.flatMap((entry) => {
    const isRedundantConflictSummary =
      entry.detailParts.length > 1 &&
      entry.detailParts.every((part) => standaloneDetails.has(normalizeForCompare(part)))

    if (isRedundantConflictSummary) return []
    if (!entry.normalizedExplanation || seenExplanations.has(entry.normalizedExplanation)) return []

    seenExplanations.add(entry.normalizedExplanation)
    return [entry.item]
  })
}

