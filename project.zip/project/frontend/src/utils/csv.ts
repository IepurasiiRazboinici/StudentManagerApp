/**
 * Minimal, dependency-free CSV parsing used purely to power the "Make it Safe"
 * before/after preview in the mock layer. Handles quoted fields (including
 * embedded commas and escaped `""` quotes) well enough for demo-quality sample
 * data — it is not a full RFC4180 implementation.
 */
export interface ParsedCsv {
  columns: string[]
  rows: Record<string, string>[]
}

function parseCsvLine(line: string): string[] {
  const cells: string[] = []
  let current = ''
  let inQuotes = false

  for (let i = 0; i < line.length; i += 1) {
    const char = line[i]
    if (inQuotes) {
      if (char === '"') {
        if (line[i + 1] === '"') {
          current += '"'
          i += 1
        } else {
          inQuotes = false
        }
      } else {
        current += char
      }
    } else if (char === '"') {
      inQuotes = true
    } else if (char === ',') {
      cells.push(current)
      current = ''
    } else {
      current += char
    }
  }
  cells.push(current)
  return cells
}

export function parseCsv(text: string, maxRows = 8): ParsedCsv {
  const lines = text.split(/\r\n|\n|\r/).filter((line) => line.trim().length > 0)
  if (lines.length === 0) return { columns: [], rows: [] }

  const columns = parseCsvLine(lines[0]).map((col) => col.trim())
  const rows: Record<string, string>[] = []

  for (let i = 1; i < lines.length && rows.length < maxRows; i += 1) {
    const cells = parseCsvLine(lines[i])
    const row: Record<string, string> = {}
    columns.forEach((col, index) => {
      row[col] = cells[index] ?? ''
    })
    rows.push(row)
  }

  return { columns, rows }
}
