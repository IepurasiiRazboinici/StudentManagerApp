import { describe, expect, it } from 'vitest'
import type { EvidenceSignal } from '@/types'
import { formatEvidenceExplanation, normalizeReviewEvidence } from './evidence'

const backendConflictEvidence = `Rule=Restricted, LLM=Public. LLM evidence: {'signal': 'sample_dataset_label', 'detail': "Header explicitly states 'Sample / Hackathon Dataset', indicating intentional public/educational use with no proprietary or sensitive content.", 'severity': 'LOW'}; {'signal': 'market_data_field_definitions', 'detail': 'Content contains generic FID definitions (TRDPRC_1, HIGH_1) with no actual trade data, account info, or PII — purely structural metadata.', 'severity': 'LOW'}`

describe('evidence formatting', () => {
  it('extracts only detail sentences from structured backend conflict evidence', () => {
    expect(formatEvidenceExplanation(backendConflictEvidence)).toBe(
      "Header explicitly states 'Sample / Hackathon Dataset', indicating intentional public/educational use with no proprietary or sensitive content. Content contains generic FID definitions (TRDPRC_1, HIGH_1) with no actual trade data, account info, or PII — purely structural metadata.",
    )
  })

  it('removes redundant conflict summaries when standalone evidence already covers the same details', () => {
    const evidence: EvidenceSignal[] = [
      { id: 'e-conflict', kind: 'DETECTOR', label: 'rule llm conflict', explanation: backendConflictEvidence, weight: 0.5 },
      {
        id: 'e-detail-1',
        kind: 'DETECTOR',
        label: 'sample dataset label',
        explanation: "Header explicitly states 'Sample / Hackathon Dataset', indicating intentional public/educational use with no proprietary or sensitive content.",
        weight: 0.4,
      },
      {
        id: 'e-detail-2',
        kind: 'DETECTOR',
        label: 'market data field definitions',
        explanation: 'Content contains generic FID definitions (TRDPRC_1, HIGH_1) with no actual trade data, account info, or PII — purely structural metadata.',
        weight: 0.4,
      },
    ]

    expect(normalizeReviewEvidence(evidence)).toEqual([evidence[1], evidence[2]])
  })
})

