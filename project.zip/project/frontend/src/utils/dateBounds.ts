const MIN_ALLOWED_DATE = '2026-07-22'
const MIN_ALLOWED_HOUR_UTC = 12
const MAX_ALLOWED_HOUR_UTC = 18

function toDateInputValueLocal(date: Date): string {
  const yyyy = date.getFullYear()
  const mm = `${date.getMonth() + 1}`.padStart(2, '0')
  const dd = `${date.getDate()}`.padStart(2, '0')
  return `${yyyy}-${mm}-${dd}`
}

function fromDateInputLocal(value: string, endOfDay = false): Date | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return null
  const [yearRaw, monthRaw, dayRaw] = value.split('-')
  const year = Number(yearRaw)
  const month = Number(monthRaw)
  const day = Number(dayRaw)
  if (!Number.isInteger(year) || !Number.isInteger(month) || !Number.isInteger(day)) return null

  const date = endOfDay
    ? new Date(year, month - 1, day, 23, 59, 59, 999)
    : new Date(year, month - 1, day, 0, 0, 0, 0)
  if (Number.isNaN(date.getTime())) return null
  if (toDateInputValueLocal(date) !== value) return null
  return date
}

function toIsoSecondsUtc(value: Date): string {
  return value.toISOString().replace(/\.\d{3}Z$/, 'Z')
}

export function getMinAllowedDate(): string {
  return MIN_ALLOWED_DATE
}

export function getMaxAllowedDate(now: Date = new Date()): string {
  return toDateInputValueLocal(now)
}

export function clampDateInput(value: string, now: Date = new Date()): string {
  if (!value) return ''
  const parsed = fromDateInputLocal(value)
  if (!parsed) return ''

  const max = getMaxAllowedDate(now)
  if (value < MIN_ALLOWED_DATE) return MIN_ALLOWED_DATE
  if (value > max) return max
  return value
}

export function clampIsoDateStringToBounds(iso: string, now: Date = new Date()): string {
  const parsed = new Date(iso)
  if (Number.isNaN(parsed.getTime())) return iso

  const minStamp = getMinAllowedDate()
  const maxStamp = getMaxAllowedDate(now)
  const currentStamp = toDateInputValueLocal(parsed)

  if (currentStamp < minStamp) return `${minStamp}T12:00:00Z`
  if (currentStamp > maxStamp) return `${maxStamp}T18:00:00Z`

  const hour = parsed.getUTCHours()
  const minute = parsed.getUTCMinutes()
  const second = parsed.getUTCSeconds()
  const millisecond = parsed.getUTCMilliseconds()

  if (hour < MIN_ALLOWED_HOUR_UTC) {
    const clamped = new Date(parsed)
    clamped.setUTCHours(MIN_ALLOWED_HOUR_UTC, 0, 0, 0)
    return toIsoSecondsUtc(clamped)
  }

  if (hour > MAX_ALLOWED_HOUR_UTC || (hour === MAX_ALLOWED_HOUR_UTC && (minute > 0 || second > 0 || millisecond > 0))) {
    const clamped = new Date(parsed)
    clamped.setUTCHours(MAX_ALLOWED_HOUR_UTC, 0, 0, 0)
    return toIsoSecondsUtc(clamped)
  }

  return iso
}

export function isWithinDateWindow(timestamp: string, since: string, until: string): boolean {
  const value = new Date(timestamp)
  if (Number.isNaN(value.getTime())) return false

  const clampedSince = clampDateInput(since)
  const clampedUntil = clampDateInput(until)

  if (clampedSince) {
    const from = fromDateInputLocal(clampedSince)
    if (from && value < from) return false
  }

  if (clampedUntil) {
    const to = fromDateInputLocal(clampedUntil, true)
    if (to && value > to) return false
  }

  return true
}

